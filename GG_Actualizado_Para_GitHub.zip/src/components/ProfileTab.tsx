import React from 'react';
import { Bookmark, Award, BookOpen, Film, Volume2, Sparkles, Trash2, Play, Sliders, Check, Shield } from 'lucide-react';
import { BookCollection, ReelShort } from '../types';
import { soundManager } from '../utils/audioEffects';

interface ProfileTabProps {
  quizPoints: number;
  collections: BookCollection[];
  savedShorts: ReelShort[];
  onSelectReel: (short: ReelShort, collectionId: string) => void;
  onRemoveSaved: (shortId: string) => void;
  isMusicPlaying: boolean;
  onToggleMusic: () => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  quizPoints,
  collections,
  savedShorts,
  onSelectReel,
  onRemoveSaved,
  isMusicPlaying,
  onToggleMusic,
}) => {
  const totalReels = collections.reduce((acc, c) => acc + c.shorts.length, 0);

  // Gamification rank based on XP
  const getRankTitle = (xp: number) => {
    if (xp >= 100) return 'Maestro de Sabiduría';
    if (xp >= 50) return 'Pensador Estratégico';
    if (xp >= 20) return 'Sabiduría Práctica';
    return 'Lector Principiante';
  };

  const handlePlay = (short: ReelShort) => {
    soundManager.playPop();
    const parent = collections.find((c) => c.shorts.some((s) => s.id === short.id));
    onSelectReel(short, parent ? parent.id : 'all');
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 pt-6 pb-28 text-white animate-fade-in">
      {/* Profile Header Card */}
      <div className="flex items-center gap-4 mb-6">
        {/* Avatar con fondo anaranjado y cruz */}
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-400 via-orange-500 to-orange-600 flex items-center justify-center text-white font-black text-lg shadow-lg shadow-orange-500/30 border-2 border-orange-300/40 select-none">
            <span>GG</span>
            <span className="font-serif ml-0.5 text-2xl leading-none">✝</span>
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-orange-400 text-zinc-950 flex items-center justify-center text-xs font-bold shadow">
            🏅
          </div>
        </div>

        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-1.5">
            Lector GG <span className="text-amber-400 font-serif font-bold text-base">✝</span>
          </h2>
          <p className="text-xs text-zinc-400 font-medium">
            Desarrollo Personal & Finanzas
          </p>
          <div className="inline-flex items-center gap-1.5 mt-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-[11px] font-bold text-amber-300">
            <span>🌟 Nivel: {getRankTitle(quizPoints)}</span>
          </div>
        </div>
      </div>

      {/* Stats Counter Row (4 columns) */}
      <div className="grid grid-cols-4 gap-2.5 p-3.5 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 text-center mb-6 shadow-inner">
        <div>
          <p className="text-base sm:text-lg font-black text-amber-400">{quizPoints}</p>
          <p className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">XP Puntos</p>
        </div>
        <div>
          <p className="text-base sm:text-lg font-black text-zinc-200">{collections.length}</p>
          <p className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">Libros</p>
        </div>
        <div>
          <p className="text-base sm:text-lg font-black text-zinc-200">{totalReels}</p>
          <p className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">Reels</p>
        </div>
        <div>
          <p className="text-base sm:text-lg font-black text-amber-400">{savedShorts.length}</p>
          <p className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">Guardados</p>
        </div>
      </div>

      {/* Section: Tus Reels Guardados */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
            <Bookmark className="w-4 h-4 text-amber-400" />
            Tus Reels Guardados
          </h3>
          <span className="text-xs text-zinc-500">
            {savedShorts.length} {savedShorts.length === 1 ? 'guardado' : 'guardados'}
          </span>
        </div>

        {savedShorts.length === 0 ? (
          <div className="p-8 rounded-3xl border border-dashed border-zinc-800 bg-zinc-900/30 text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-zinc-800/60 text-zinc-500 mx-auto flex items-center justify-center">
              <Bookmark className="w-5 h-5" />
            </div>
            <p className="text-xs text-zinc-400 font-medium">Aún no has guardado reels.</p>
            <p className="text-[11px] text-zinc-500">Toca el icono de guardar en cualquier reel para verlo aquí.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {savedShorts.map((short) => (
              <div
                key={short.id}
                className="p-3.5 rounded-2xl bg-zinc-900/80 border border-zinc-800 hover:border-amber-500/40 flex items-center justify-between gap-3 transition-all"
              >
                <div
                  onClick={() => handlePlay(short)}
                  className="min-w-0 flex-1 cursor-pointer"
                >
                  <p className="text-xs font-bold text-zinc-200 line-clamp-1 hover:text-amber-300">
                    {short.title}
                  </p>
                  <p className="text-[10px] text-zinc-400 truncate mt-0.5">
                    📖 {short.bookTitle} · {short.author}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => handlePlay(short)}
                    className="p-2 rounded-xl bg-amber-500 text-zinc-950 hover:bg-amber-400 transition-colors"
                    title="Reproducir"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                  </button>
                  <button
                    onClick={() => {
                      soundManager.playPop();
                      onRemoveSaved(short.id);
                    }}
                    className="p-2 rounded-xl bg-zinc-800 text-zinc-400 hover:text-red-400 transition-colors"
                    title="Eliminar de guardados"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Section: Ajustes y Audio */}
      <div className="mb-6 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-1.5 px-1">
          <Sliders className="w-4 h-4 text-amber-400" />
          Ajustes y Audio
        </h3>

        <div className="p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 space-y-4">
          {/* Background Music Toggle */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-zinc-200">Música de fondo en Reels</p>
                <p className="text-[10px] text-zinc-400">Canciones alternadas con ducking</p>
              </div>
            </div>

            <button
              onClick={() => {
                soundManager.playPop();
                onToggleMusic();
              }}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                isMusicPlaying ? 'bg-amber-500 justify-end' : 'bg-zinc-700 justify-start'
              }`}
            >
              <span className="w-5 h-5 rounded-full bg-white shadow-md transform transition-transform" />
            </button>
          </div>

          <div className="h-px bg-zinc-800/80" />

          {/* Voice Narrator Info */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-zinc-200">Voz Narradora en Español</p>
                <p className="text-[10px] text-zinc-400">Activación directa instantánea</p>
              </div>
            </div>

            <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-zinc-800 text-zinc-300">
              Activa en Reel
            </span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center pt-4 text-zinc-500 space-y-1">
        <p className="text-xs font-bold text-zinc-400">
          GG <span className="text-amber-400 font-serif">✝</span> Reels Educativos
        </p>
        <p className="text-[10px] text-zinc-600">
          Aprende de los mejores libros del mundo con down-scrolling
        </p>
      </div>
    </div>
  );
};
