import React from 'react';
import { Home, Search, PlusSquare, Film, User } from 'lucide-react';
import { soundManager } from '../utils/audioEffects';

export type NavTab = 'home' | 'search' | 'upload' | 'reels' | 'profile';

interface BottomNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  savedCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  savedCount = 0,
}) => {
  const handleTabClick = (tab: NavTab) => {
    soundManager.playPop();
    onSelectTab(tab);
  };

  const navItems = [
    { id: 'home' as NavTab, label: 'Inicio', icon: Home },
    { id: 'search' as NavTab, label: 'Buscar', icon: Search },
    { id: 'upload' as NavTab, label: 'Subir', icon: PlusSquare },
    { id: 'reels' as NavTab, label: 'Reels', icon: Film },
    { id: 'profile' as NavTab, label: 'Perfil', icon: User, badge: savedCount > 0 ? savedCount : null },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-zinc-950/95 backdrop-blur-xl border-t border-zinc-800/80 px-2 py-1.5 select-none transition-all">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 ${
                isActive
                  ? 'text-amber-400 font-bold scale-105'
                  : 'text-zinc-500 hover:text-zinc-300 font-medium'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'stroke-[2.5px] drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : 'stroke-[1.75px]'
                  }`}
                />
                {item.badge && (
                  <span className="absolute -top-1 -right-2 bg-amber-500 text-zinc-950 text-[9px] font-black w-3.5 h-3.5 rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight leading-none">
                {item.label}
              </span>
              {isActive && (
                <span className="absolute -bottom-1 w-1 h-1 rounded-full bg-amber-400 shadow-[0_0_6px_#f59e0b]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
