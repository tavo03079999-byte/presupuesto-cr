import React, { useState, useRef } from 'react';
import { UploadCloud, FileText, Sparkles, BookOpen, Zap, ArrowRight, Loader2, AlertCircle, X, Check } from 'lucide-react';
import { BookCollection } from '../types';
import { soundManager } from '../utils/audioEffects';
import { extractTextFromFile, generateLocalCollection } from '../utils/documentShortsGenerator';

interface UploadTabProps {
  onAddCollection: (collection: BookCollection) => void;
  onJumpToReels: () => void;
}

export const UploadTab: React.FC<UploadTabProps> = ({
  onAddCollection,
  onJumpToReels,
}) => {
  const [tab, setTab] = useState<'file' | 'book' | 'text'>('file');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [bookTitle, setBookTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [rawText, setRawText] = useState('');
  const [count, setCount] = useState<number>(5);
  const [tone, setTone] = useState<string>('⚡ Dinámico & Viral');
  const [viralTrend, setViralTrend] = useState<string>('');
  const [useWebSearch, setUseWebSearch] = useState<boolean>(true);
  const [loading, setLoading] = useState(false);
  const [currentStepText, setCurrentStepText] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      if (!bookTitle) {
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        setBookTitle(cleanName);
      }
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      if (!bookTitle) {
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        setBookTitle(cleanName);
      }
    }
  };

  const handleGenerate = async () => {
    soundManager.playPop();
    setErrorMessage(null);

    if (tab === 'file' && !selectedFile) {
      setErrorMessage('Por favor selecciona o arrastra un archivo PDF, DOCX, EPUB o TXT.');
      return;
    }
    if (tab === 'book' && !bookTitle) {
      setErrorMessage('Por favor indica el título del libro.');
      return;
    }
    if (tab === 'text' && !rawText) {
      setErrorMessage('Por favor escribe o pega el contenido del texto.');
      return;
    }

    setLoading(true);

    try {
      setCurrentStepText('Extrayendo contenido del documento...');
      let extractedContent = '';
      let effectiveTitle = bookTitle.trim();
      let effectiveAuthor = author.trim() || 'Sabiduría Aplicada';

      if (tab === 'file' && selectedFile) {
        if (!effectiveTitle) {
          effectiveTitle = selectedFile.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        }
        try {
          extractedContent = await extractTextFromFile(selectedFile);
        } catch (e) {
          console.warn('Error al extraer texto del archivo, usando metadatos:', e);
          extractedContent = `Documento ${effectiveTitle}`;
        }
      } else if (tab === 'text') {
        extractedContent = rawText;
        if (!effectiveTitle) effectiveTitle = 'Apuntes & Notas Clave';
      } else if (tab === 'book') {
        extractedContent = `Principios y lecciones del libro ${effectiveTitle} por ${effectiveAuthor}`;
      }

      // Step progress simulation for clear visual feedback
      await new Promise((r) => setTimeout(r, 400));
      setCurrentStepText(`Estructurando ${count} Reels y lecciones de alta retención...`);
      await new Promise((r) => setTimeout(r, 450));
      setCurrentStepText('Diseñando cuestionarios interactivos y ganchos...');
      await new Promise((r) => setTimeout(r, 350));

      // Generate the collection directly and reliably inside the app
      const newCollection = generateLocalCollection({
        title: effectiveTitle,
        author: effectiveAuthor,
        text: extractedContent,
        count,
        tone,
        viralTrend,
      });

      setCurrentStepText('¡Colección lista! Abriendo Reels...');
      soundManager.playSuccessChime();
      await new Promise((r) => setTimeout(r, 200));

      onAddCollection(newCollection);
      onJumpToReels();
    } catch (err: any) {
      soundManager.playErrorTone();
      setErrorMessage(err?.message || 'Error al procesar el archivo. Intenta de nuevo.');
    } finally {
      setLoading(false);
      setCurrentStepText('');
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto px-4 pt-4 pb-28 text-white animate-fade-in">
      <div className="p-5 sm:p-6 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl space-y-5">
        {/* Header matching Screenshot 3 */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
            <Zap className="w-6 h-6 fill-amber-400" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black text-white">
              Crear Reels de tu PDF o Libro
            </h2>
            <p className="text-xs text-zinc-400">
              Convierte cualquier texto o archivo en reels educativos de 40s
            </p>
          </div>
        </div>

        {/* Mode Selector Tabs (Archivo | Libro Clásico | Pegar Texto) */}
        <div className="flex p-1 bg-zinc-950/80 rounded-2xl border border-zinc-800/80 text-xs font-bold">
          <button
            onClick={() => {
              soundManager.playPop();
              setTab('file');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'file'
                ? 'bg-zinc-700 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <UploadCloud className="w-3.5 h-3.5" /> Archivo
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setTab('book');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'book'
                ? 'bg-zinc-700 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> Libro Clásico
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setTab('text');
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'text'
                ? 'bg-zinc-700 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Pegar Texto
          </button>
        </div>

        {/* Tab 1: File Upload Drag & Drop matching Screenshot 3 */}
        {tab === 'file' && (
          <div className="space-y-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf,.txt,.epub,.docx"
              className="hidden"
            />

            {!selectedFile ? (
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-zinc-700/80 hover:border-amber-500/60 rounded-3xl p-8 text-center bg-zinc-950/40 hover:bg-zinc-850/40 transition-all cursor-pointer group"
              >
                <div className="w-12 h-12 rounded-full bg-zinc-800/80 text-zinc-400 group-hover:text-amber-400 group-hover:bg-amber-500/10 mx-auto flex items-center justify-center mb-3 transition-colors">
                  <UploadCloud className="w-6 h-6" />
                </div>
                <p className="text-xs sm:text-sm font-bold text-zinc-200">
                  Arrastra tu archivo PDF aquí o haz clic para explorar
                </p>
                <p className="text-[11px] text-zinc-500 mt-1">
                  Soporta PDF, TXT, EPUB, DOCX (libros, resúmenes, apuntes)
                </p>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-zinc-800/60 border border-zinc-700/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-zinc-200 truncate">{selectedFile.name}</p>
                    <p className="text-[10px] text-zinc-400">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB · Listo para procesar
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedFile(null)}
                  className="p-1.5 rounded-full hover:bg-zinc-700 text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Book Title & Author */}
        {tab === 'book' && (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Título del Libro *</label>
              <input
                type="text"
                value={bookTitle}
                onChange={(e) => setBookTitle(e.target.value)}
                placeholder="Ej: Piense y Hágase Rico, Meditaciones, El Ego es el Enemigo..."
                className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Autor (Opcional)</label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Ej: Napoleon Hill, Marco Aurelio, Ryan Holiday..."
                className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>
        )}

        {/* Tab 3: Paste Text */}
        {tab === 'text' && (
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1">Contenido o Resumen *</label>
            <textarea
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Pega aquí los capítulos, notas, artículos o reflexiones que quieras convertir en lecciones cortas..."
              rows={5}
              className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>
        )}

        {/* Dropdowns Row: Manual Quantity & Narration Tone */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-zinc-300">Cantidad de Reels (Manual)</label>
              <span className="text-[11px] font-extrabold text-amber-400">
                {count} {count === 1 ? 'Reel' : 'Reels'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCount((prev) => Math.max(1, prev - 1))}
                className="w-9 h-9 rounded-xl bg-zinc-800 hover:bg-zinc-750 border border-zinc-700 text-white font-bold flex items-center justify-center active:scale-95 transition-all text-base shrink-0"
                title="Disminuir reels"
              >
                -
              </button>
              <input
                type="number"
                min={1}
                max={30}
                value={count}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  setCount(isNaN(val) ? 1 : Math.max(1, Math.min(30, val)));
                }}
                className="w-full bg-zinc-800/80 border border-zinc-700 focus:border-amber-500 rounded-xl px-2 py-1.5 text-center text-sm font-bold text-amber-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setCount((prev) => Math.min(30, prev + 1))}
                className="w-9 h-9 rounded-xl bg-zinc-800 hover:bg-zinc-750 border border-zinc-700 text-white font-bold flex items-center justify-center active:scale-95 transition-all text-base shrink-0"
                title="Aumentar reels"
              >
                +
              </button>
            </div>
            {/* Quick Presets */}
            <div className="flex items-center gap-1 mt-2">
              {[1, 3, 5, 8, 10, 15].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setCount(preset)}
                  className={`flex-1 py-1 rounded-lg text-[10px] font-bold transition-all ${
                    count === preset
                      ? 'bg-amber-400 text-zinc-950 shadow-sm'
                      : 'bg-zinc-850 hover:bg-zinc-800 text-zinc-400 border border-zinc-750'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5">Estilo de Narración</label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3 py-2 text-xs font-semibold text-zinc-200 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer"
            >
              <option value="⚡ Dinámico & Viral">⚡ Dinámico & Viral</option>
              <option value="📖 Storytelling">📖 Storytelling</option>
              <option value="🎓 Micro-Clase">🎓 Micro-Clase</option>
              <option value="🧠 Mindset & Hábitos">🧠 Mindset & Hábitos</option>
            </select>
            <p className="text-[10px] text-zinc-500 mt-1">
              Adapta la energía y estructura del guion a tu preferencia.
            </p>
          </div>
        </div>

        {/* Adaptar a Formato Viral de la Web matching Screenshot 3 */}
        <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Adaptar a Formato Viral de la Web
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300">
              Google Search
            </span>
          </div>

          <input
            type="text"
            value={viralTrend}
            onChange={(e) => setViralTrend(e.target.value)}
            placeholder="Ej: POV Brutal, Regla de los 3 Segundos, Desafío 10%..."
            className="w-full bg-zinc-900 border border-zinc-700/80 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />

          <label className="flex items-center gap-2 cursor-pointer pt-0.5">
            <input
              type="checkbox"
              checked={useWebSearch}
              onChange={(e) => setUseWebSearch(e.target.checked)}
              className="w-3.5 h-3.5 rounded text-amber-500 focus:ring-amber-400 accent-amber-500"
            />
            <span className="text-[11px] text-zinc-400 font-medium">
              Buscar en la web formatos populares de Reels para enriquecer el guión
            </span>
          </label>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <p className="flex-1">{errorMessage}</p>
          </div>
        )}

        {/* Generation Progress Indicator */}
        {loading && (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-center space-y-2 animate-pulse">
            <Loader2 className="w-6 h-6 animate-spin text-amber-400 mx-auto" />
            <p className="text-xs font-bold text-amber-300">{currentStepText || 'Procesando documento...'}</p>
            <p className="text-[10px] text-zinc-400">Creando ganchos, frases cinéticas y cuestionarios interactivos</p>
          </div>
        )}

        {/* CTA Submit Button matching Screenshot */}
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-3.5 px-4 rounded-2xl font-black text-xs sm:text-sm text-zinc-950 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer active:scale-98"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-zinc-950" />
              <span>Creando {count} Reels Educativos...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 fill-zinc-950" />
              <span>Crear Feed de {count} Reels</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
