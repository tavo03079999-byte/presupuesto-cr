package com.presupuesto.cr.domain.usecase

import android.content.Context
import android.net.Uri
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.presupuesto.cr.PresupuestoApp
import com.presupuesto.cr.data.local.AppDatabase
import com.presupuesto.cr.ui.auth.UserAuthManager
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class RestoreSummary(
    val transactionCount: Int,
    val message: String
)

data class BackupValidationResult(
    val isValid: Boolean,
    val transactionCount: Int,
    val errorMessage: String? = null
)

class GoogleDriveBackupUseCase(
    private val context: Context
) {
    companion object {
        const val TARGET_ACCOUNT_EMAIL = "tavo03079999@gmail.com"
        private const val DB_FILE_NAME = "presupuesto_cr_encrypted.db"
    }

    fun getGoogleSignInClient(): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getLastSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && account.email.equals(TARGET_ACCOUNT_EMAIL, ignoreCase = true)) {
            account
        } else {
            account
        }
    }

    fun createBackupFileForSharing(): Result<File> {
        try {
            AppDatabase.checkpoint()
            val dbFile = context.getDatabasePath(DB_FILE_NAME)
            if (!dbFile.exists()) {
                return Result.failure(IllegalStateException("No se encontró el archivo de base de datos local"))
            }
            val backupDir = File(context.cacheDir, "backups").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val targetFile = File(backupDir, "SaldoX_Respaldo_${timeStamp}.db")
            dbFile.copyTo(targetFile, overwrite = true)
            return Result.success(targetFile)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    private fun validateAndPrepareBackupFile(backupFile: File): BackupValidationResult {
        val prefs = context.getSharedPreferences("security_prefs_cr", Context.MODE_PRIVATE)
        val storedKey = prefs.getString("db_sec_key", null)

        val candidateKeys = mutableListOf<ByteArray>()
        candidateKeys.add(AppDatabase.MASTER_DB_PASSPHRASE.toByteArray(Charsets.UTF_8))
        if (!storedKey.isNullOrBlank()) {
            candidateKeys.add(storedKey.toByteArray(Charsets.UTF_8))
        }
        candidateKeys.add("SaldoX-CR-SQLCipher-Master-SecureKey-2024#CR".toByteArray(Charsets.UTF_8))
        candidateKeys.add(ByteArray(0))

        var workingDb: net.sqlcipher.database.SQLiteDatabase? = null
        var workingKey: ByteArray? = null

        for (candidate in candidateKeys) {
            try {
                val db = net.sqlcipher.database.SQLiteDatabase.openDatabase(
                    backupFile.absolutePath,
                    candidate,
                    null,
                    net.sqlcipher.database.SQLiteDatabase.OPEN_READWRITE
                )
                val cursor = db.rawQuery("SELECT count(*) FROM sqlite_master", null)
                if (cursor.moveToFirst()) {
                    cursor.close()
                    workingDb = db
                    workingKey = candidate
                    break
                }
                cursor.close()
                db.close()
            } catch (_: Exception) {
            }
        }

        if (workingDb == null || workingKey == null) {
            return BackupValidationResult(
                isValid = false,
                transactionCount = 0,
                errorMessage = "El archivo seleccionado no es una copia de seguridad válida de SaldoX o no se pudo descifrar."
            )
        }

        try {
            var txCount = 0
            val cursorTx = workingDb.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='transactions'", null)
            val hasTxTable = if (cursorTx.moveToFirst()) cursorTx.getInt(0) > 0 else false
            cursorTx.close()

            if (hasTxTable) {
                val countCursor = workingDb.rawQuery("SELECT count(*) FROM transactions", null)
                if (countCursor.moveToFirst()) {
                    txCount = countCursor.getInt(0)
                }
                countCursor.close()
            }

            val masterBytes = AppDatabase.MASTER_DB_PASSPHRASE.toByteArray(Charsets.UTF_8)
            if (!workingKey.contentEquals(masterBytes)) {
                workingDb.changePassword(masterBytes)
            }

            workingDb.close()

            return BackupValidationResult(
                isValid = true,
                transactionCount = txCount
            )
        } catch (e: Exception) {
            try { workingDb.close() } catch (_: Exception) {}
            return BackupValidationResult(
                isValid = false,
                transactionCount = 0,
                errorMessage = "Error al leer los datos de la copia: ${e.localizedMessage}"
            )
        }
    }

    suspend fun restoreDatabaseFromUri(uri: Uri): Result<RestoreSummary> = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.cacheDir, "temp_incoming_restore.db")
            if (tempFile.exists()) tempFile.delete()

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("No se pudo leer el archivo de respaldo seleccionado"))

            val validation = validateAndPrepareBackupFile(tempFile)
            if (!validation.isValid) {
                tempFile.delete()
                return@withContext Result.failure(IllegalStateException(validation.errorMessage ?: "Respaldo no válido"))
            }

            AppDatabase.closeInstance()

            val destinationDb = context.getDatabasePath(DB_FILE_NAME)
            val walFile = File(destinationDb.path + "-wal")
            val shmFile = File(destinationDb.path + "-shm")

            if (walFile.exists()) walFile.delete()
            if (shmFile.exists()) shmFile.delete()

            tempFile.copyTo(destinationDb, overwrite = true)
            tempFile.delete()

            AppDatabase.ensureMasterPassphrase(context)
            val db = AppDatabase.getInstance(context)

            val userProfile = db.userProfileDao().getUserProfile()
            if (userProfile != null) {
                val authManager = UserAuthManager(context)
                authManager.syncUserFromRestoredProfile(
                    name = userProfile.name,
                    email = userProfile.email,
                    passwordHash = userProfile.passwordHash,
                    passwordSalt = userProfile.passwordSalt
                )
            }

            (context.applicationContext as? PresupuestoApp)?.refreshDatabase()

            val summary = RestoreSummary(
                transactionCount = validation.transactionCount,
                message = "¡Copia de seguridad restaurada con éxito! Se verificaron ${validation.transactionCount} transacciones en tus movimientos."
            )

            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(Exception("Error al restaurar archivo: ${e.localizedMessage}"))
        }
    }

    suspend fun uploadDatabaseBackup(account: GoogleSignInAccount): Result<String> = withContext(Dispatchers.IO) {
        try {
            AppDatabase.checkpoint()

            val credential = GoogleAccountCredential.usingOAuth2(
                context,
                Collections.singleton(DriveScopes.DRIVE_FILE)
            ).apply {
                selectedAccount = account.account
            }

            val driveService = Drive.Builder(
                NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                credential
            ).setApplicationName("SaldoX").build()

            val dbFile = context.getDatabasePath(DB_FILE_NAME)
            if (!dbFile.exists()) {
                return@withContext Result.failure(IllegalStateException("No se encontró el archivo de base de datos local"))
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val metadata = DriveFile().apply {
                name = "Backup_SaldoX_${timeStamp}.db"
                description = "Respaldo seguro cifrado de SaldoX para ${account.email ?: TARGET_ACCOUNT_EMAIL}"
            }

            val mediaContent = FileContent("application/x-sqlite3", dbFile)
            val uploadedFile = driveService.files().create(metadata, mediaContent)
                .setFields("id, name, createdTime")
                .execute()

            Result.success("Respaldo exitoso en Google Drive: ${uploadedFile.name}")
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: e.message ?: "Verifica tu conexión"
            Result.failure(Exception("No fue posible completar el respaldo en Google Drive: $msg"))
        }
    }

    suspend fun restoreDatabaseBackup(account: GoogleSignInAccount, driveFileId: String): Result<RestoreSummary> = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.cacheDir, "temp_drive_download.db")
            if (tempFile.exists()) tempFile.delete()

            val credential = GoogleAccountCredential.usingOAuth2(
                context,
                Collections.singleton(DriveScopes.DRIVE_FILE)
            ).apply {
                selectedAccount = account.account
            }

            val driveService = Drive.Builder(
                NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                credential
            ).setApplicationName("SaldoX").build()

            FileOutputStream(tempFile).use { output ->
                driveService.files().get(driveFileId).executeMediaAndDownloadTo(output)
            }

            val validation = validateAndPrepareBackupFile(tempFile)
            if (!validation.isValid) {
                tempFile.delete()
                return@withContext Result.failure(IllegalStateException(validation.errorMessage ?: "Respaldo no válido"))
            }

            AppDatabase.closeInstance()

            val destinationDb = context.getDatabasePath(DB_FILE_NAME)
            val walFile = File(destinationDb.path + "-wal")
            val shmFile = File(destinationDb.path + "-shm")

            if (walFile.exists()) walFile.delete()
            if (shmFile.exists()) shmFile.delete()

            tempFile.copyTo(destinationDb, overwrite = true)
            tempFile.delete()

            AppDatabase.ensureMasterPassphrase(context)
            val db = AppDatabase.getInstance(context)

            val userProfile = db.userProfileDao().getUserProfile()
            if (userProfile != null) {
                val authManager = UserAuthManager(context)
                authManager.syncUserFromRestoredProfile(
                    name = userProfile.name,
                    email = userProfile.email,
                    passwordHash = userProfile.passwordHash,
                    passwordSalt = userProfile.passwordSalt
                )
            }

            (context.applicationContext as? PresupuestoApp)?.refreshDatabase()

            val summary = RestoreSummary(
                transactionCount = validation.transactionCount,
                message = "¡Base de datos restaurada correctamente desde Google Drive! Se encontraron ${validation.transactionCount} transacciones."
            )

            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(Exception("No fue posible restaurar la copia de seguridad desde Google Drive: ${e.localizedMessage}"))
        }
    }
}
