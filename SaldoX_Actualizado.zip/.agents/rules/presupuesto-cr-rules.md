---
trigger: always_on
description: Custom Rules para PresupuestoCR (Kotlin, Jetpack Compose, Material3, Room, ML Kit, Google Drive)
---

# Custom Rules — PresupuestoCR (Antigravity)

1. **Identidad del Proyecto**:
   - App: `PresupuestoCR` (Kotlin + Jetpack Compose + Material3 + Room Database, Gradle 8.6 / Java 17, ML Kit OCR, Google Drive API).
2. **Estructura de carpetas**:
   - Respetar siempre `data/`, `domain/`, `ui/`, `util/`, `service/`, `worker/`.
   - Seguir el patrón `Model → DAO → Repository → ViewModel → Screen`.
3. **Imports y Dependencias**:
   - NUNCA dejar imports pegados en una sola línea — cada import en su propia línea.
   - Siempre incluir TODOS los imports necesarios y verificar que existan en `build.gradle.kts` y `gradle/libs.versions.toml` con versiones estables.
4. **Compilación**:
   - Todo código DEBE compilar sin errores con `assembleDebug`.
   - No usar APIs deprecadas (ej. usar `NetHttpTransport` en lugar de `AndroidHttp`).
   - No acceder a propiedades privadas/internas de Material3 (ej. `indicatorColor`).
5. **Diseño UI**:
   - Colores principales: Verde (`#4CAF50`) ingresos, Rojo (`#F44336`) gastos, Azul (`#2196F3`) tema general.
   - Navegación inferior con 5 secciones: `Inicio`, `Transacciones`, `Reportes`, `Calendario`, `Configuración`.
   - Usar `Modifier.fillMaxWidth()`, `TextOverflow.Ellipsis`, y `LazyColumn` para listas.
6. **Base de Datos (Room)**:
   - Entidades con `@PrimaryKey(autoGenerate = true)`, tablas en `snake_case` (`transactions`, `categories`, `payment_reminders`, `accounts`, `budgets`, `bcr_pending_transactions`), y campos `created_at` y `updated_at` (`Long`).
   - DAOs con `insert()`, `update()`, `delete()`, `getAll()`, `getById()` usando `suspend` y `@Query` parametrizados.
   - Incluir `Migration` y evitar `fallbackToDestructiveMigration()` en producción.
7. **Funcionalidad y Calidad**:
   - Confirmación con diálogo antes de eliminar transacciones y soporte de edición con datos pre-cargados.
   - Gráficos interactivos con tooltip de monto y porcentaje.
   - Notificaciones programadas con `WorkManager` (1 día antes, mismo día, 1 hora antes).
   - Imágenes guardadas como URI (`String`) en Room y renderizadas con `Coil`.
   - Manejo de errores con `try/catch` y mensajes amigables al usuario.
8. **Formato de Respuesta**:
   - Indicar SIEMPRE la ruta completa del archivo.
   - Listar TODOS los archivos afectados al inicio.
   - Indicar nuevas dependencias primero antes del código.
   - Confirmar que el código compila con `assembleDebug`.
