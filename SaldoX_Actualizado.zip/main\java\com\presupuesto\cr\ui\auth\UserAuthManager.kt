package com.presupuesto.cr.ui.auth

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import com.presupuesto.cr.data.local.AppDatabase
import com.presupuesto.cr.data.local.entity.UserProfileEntity
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

enum class LoginStatus {
    SUCCESS,
    SUCCESS_WITH_TEMP_PASSWORD,
    INVALID_CREDENTIALS,
    TEMP_PASSWORD_EXPIRED,
    USER_NOT_FOUND
}

class UserAuthManager(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isUserRegistered(): Boolean {
        val email = prefs.getString(KEY_EMAIL, null)
        val hash = prefs.getString(KEY_PASSWORD_HASH, null)
        if (!email.isNullOrBlank() && !hash.isNullOrBlank()) {
            return true
        }
        return checkAndSyncFromPersistentStorage()
    }

    private fun checkAndSyncFromPersistentStorage(): Boolean {
        if (checkAndSyncFromDatabase()) return true
        return checkAndSyncFromVaultFile()
    }

    private fun checkAndSyncFromDatabase(): Boolean {
        return try {
            val user = runBlocking(Dispatchers.IO) {
                AppDatabase.getInstance(context).userProfileDao().getUserProfile()
            }
            if (user != null) {
                prefs.edit()
                    .putString(KEY_NAME, user.name)
                    .putString(KEY_EMAIL, user.email)
                    .putString(KEY_PASSWORD_HASH, user.passwordHash)
                    .putString(KEY_PASSWORD_SALT, user.passwordSalt)
                    .apply()
                saveToVaultFile(user.name, user.email, user.passwordHash, user.passwordSalt)
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun getVaultDirs(): List<File> {
        val dirs = mutableListOf<File>()
        try {
            val docs = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SaldoX")
            dirs.add(docs)
        } catch (_: Exception) {
        }
        try {
            val downloads = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "SaldoX")
            dirs.add(downloads)
        } catch (_: Exception) {
        }
        try {
            context.getExternalFilesDir(null)?.let { ext ->
                dirs.add(File(ext, "SaldoX"))
            }
        } catch (_: Exception) {
        }
        return dirs
    }

    private fun saveToVaultFile(name: String, email: String, hash: String, salt: String) {
        try {
            for (dir in getVaultDirs()) {
                if (!dir.exists()) dir.mkdirs()
                val vaultFile = File(dir, "saldox_vault.json")
                val json = """
                    {
                      "name": "${escapeJson(name)}",
                      "email": "${escapeJson(email)}",
                      "password_hash": "$hash",
                      "password_salt": "$salt",
                      "updated_at": ${System.currentTimeMillis()}
                    }
                """.trimIndent()
                vaultFile.writeText(json, Charsets.UTF_8)
            }
        } catch (_: Exception) {
        }
    }

    private fun checkAndSyncFromVaultFile(): Boolean {
        try {
            for (dir in getVaultDirs()) {
                val vaultFile = File(dir, "saldox_vault.json")
                if (vaultFile.exists() && vaultFile.canRead()) {
                    val content = vaultFile.readText(Charsets.UTF_8)
                    val name = extractJsonValue(content, "name")
                    val email = extractJsonValue(content, "email")
                    val hash = extractJsonValue(content, "password_hash")
                    val salt = extractJsonValue(content, "password_salt")

                    if (!email.isNullOrBlank() && !hash.isNullOrBlank() && !salt.isNullOrBlank()) {
                        prefs.edit()
                            .putString(KEY_NAME, name ?: "Usuario")
                            .putString(KEY_EMAIL, email)
                            .putString(KEY_PASSWORD_HASH, hash)
                            .putString(KEY_PASSWORD_SALT, salt)
                            .apply()

                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                val db = AppDatabase.getInstance(context)
                                db.userProfileDao().insert(
                                    UserProfileEntity(
                                        name = name ?: "Usuario",
                                        email = email,
                                        passwordHash = hash,
                                        passwordSalt = salt
                                    )
                                )
                                AppDatabase.checkpoint()
                            } catch (_: Exception) {
                            }
                        }
                        return true
                    }
                }
            }
        } catch (_: Exception) {
        }
        return false
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\").replace("\"", "\\\"")
    }

    private fun extractJsonValue(json: String, key: String): String? {
        val pattern = "\"$key\"\\s*:\\s*\"([^\"]+)\"".toRegex()
        return pattern.find(json)?.groupValues?.get(1)
    }

    fun syncUserFromRestoredProfile(
        name: String,
        email: String,
        passwordHash: String,
        passwordSalt: String
    ) {
        prefs.edit()
            .putString(KEY_NAME, name)
            .putString(KEY_EMAIL, email)
            .putString(KEY_PASSWORD_HASH, passwordHash)
            .putString(KEY_PASSWORD_SALT, passwordSalt)
            .remove(KEY_TEMP_HASH)
            .remove(KEY_TEMP_EXPIRY)
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .apply()

        saveToVaultFile(name, email, passwordHash, passwordSalt)
    }

    private fun persistUserProfileToDatabase(
        name: String,
        email: String,
        hash: String,
        salt: String
    ) {
        saveToVaultFile(name, email, hash, salt)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getInstance(context)
                val existing = db.userProfileDao().getUserProfile()
                if (existing != null) {
                    db.userProfileDao().update(
                        existing.copy(
                            name = name,
                            email = email,
                            passwordHash = hash,
                            passwordSalt = salt,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                } else {
                    db.userProfileDao().insert(
                        UserProfileEntity(
                            name = name,
                            email = email,
                            passwordHash = hash,
                            passwordSalt = salt
                        )
                    )
                }
                AppDatabase.checkpoint()
            } catch (_: Exception) {
            }
        }
    }

    fun isLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false) && isUserRegistered()
    }

    fun getRegisteredEmail(): String? {
        val email = prefs.getString(KEY_EMAIL, null)
        if (!email.isNullOrBlank()) return email
        checkAndSyncFromPersistentStorage()
        return prefs.getString(KEY_EMAIL, null)
    }

    fun getRegisteredName(): String? {
        val name = prefs.getString(KEY_NAME, null)
        if (!name.isNullOrBlank()) return name
        checkAndSyncFromPersistentStorage()
        return prefs.getString(KEY_NAME, null)
    }

    fun registerUser(name: String, email: String, password: String): Result<Unit> {
        val trimmedEmail = email.trim()
        val trimmedName = name.trim()

        if (trimmedEmail.isBlank() || !trimmedEmail.contains("@") || !trimmedEmail.contains(".")) {
            return Result.failure(IllegalArgumentException("Ingresa un correo electrónico válido."))
        }
        if (password.length < 6) {
            return Result.failure(IllegalArgumentException("La contraseña debe tener al menos 6 caracteres."))
        }

        val salt = generateSalt()
        val hash = hashPassword(password, salt)

        prefs.edit()
            .putString(KEY_NAME, trimmedName.ifBlank { "Usuario" })
            .putString(KEY_EMAIL, trimmedEmail)
            .putString(KEY_PASSWORD_HASH, hash)
            .putString(KEY_PASSWORD_SALT, salt)
            .remove(KEY_TEMP_HASH)
            .remove(KEY_TEMP_EXPIRY)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()

        persistUserProfileToDatabase(
            name = trimmedName.ifBlank { "Usuario" },
            email = trimmedEmail,
            hash = hash,
            salt = salt
        )

        return Result.success(Unit)
    }

    fun login(email: String, password: String): LoginStatus {
        var registeredEmail = getRegisteredEmail()
        if (registeredEmail.isNullOrBlank()) {
            checkAndSyncFromPersistentStorage()
            registeredEmail = getRegisteredEmail()
        }
        if (registeredEmail.isNullOrBlank()) {
            return LoginStatus.USER_NOT_FOUND
        }
        if (!registeredEmail.equals(email.trim(), ignoreCase = true)) {
            return LoginStatus.INVALID_CREDENTIALS
        }

        val salt = prefs.getString(KEY_PASSWORD_SALT, null) ?: return LoginStatus.INVALID_CREDENTIALS
        val regularHash = prefs.getString(KEY_PASSWORD_HASH, null)
        val computedHash = hashPassword(password, salt)

        if (regularHash != null && regularHash == computedHash) {
            prefs.edit().putBoolean(KEY_IS_LOGGED_IN, true).apply()
            return LoginStatus.SUCCESS
        }

        // Verificar si ingresó con contraseña temporal
        val tempHash = prefs.getString(KEY_TEMP_HASH, null)
        val tempExpiry = prefs.getLong(KEY_TEMP_EXPIRY, 0L)

        if (tempHash != null) {
            val computedTempHash = hashPassword(password, salt)
            if (computedTempHash == tempHash) {
                if (System.currentTimeMillis() > tempExpiry) {
                    return LoginStatus.TEMP_PASSWORD_EXPIRED
                }
                prefs.edit().putBoolean(KEY_IS_LOGGED_IN, true).apply()
                return LoginStatus.SUCCESS_WITH_TEMP_PASSWORD
            }
        }

        return LoginStatus.INVALID_CREDENTIALS
    }

    fun generateTemporaryPassword(email: String): Result<String> {
        val registeredEmail = getRegisteredEmail()
            ?: return Result.failure(IllegalStateException("No hay ninguna cuenta registrada aún en la app."))

        if (!registeredEmail.equals(email.trim(), ignoreCase = true)) {
            return Result.failure(IllegalArgumentException("El correo ingresado no coincide con el usuario registrado ($registeredEmail)."))
        }

        val salt = prefs.getString(KEY_PASSWORD_SALT, null) ?: generateSalt()
        val tempPassword = generateRandomCode(8)
        val tempHash = hashPassword(tempPassword, salt)
        val expiryTime = System.currentTimeMillis() + TimeUnit.HOURS.toMillis(24)

        prefs.edit()
            .putString(KEY_PASSWORD_SALT, salt)
            .putString(KEY_TEMP_HASH, tempHash)
            .putLong(KEY_TEMP_EXPIRY, expiryTime)
            .apply()

        // Copiar al portapapeles del dispositivo
        copyToClipboard(tempPassword)

        // Preparar y abrir cliente de correo del dispositivo
        dispatchEmailIntent(email.trim(), tempPassword)

        return Result.success(tempPassword)
    }

    fun changePassword(currentPassword: String, newPassword: String): Result<Unit> {
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("La nueva contraseña debe tener al menos 6 caracteres."))
        }

        val salt = prefs.getString(KEY_PASSWORD_SALT, null)
            ?: return Result.failure(IllegalStateException("Error de credenciales internas."))
        val storedHash = prefs.getString(KEY_PASSWORD_HASH, null)
        val currentHash = hashPassword(currentPassword, salt)

        val tempHash = prefs.getString(KEY_TEMP_HASH, null)
        val isCurrentRegularMatch = storedHash != null && storedHash == currentHash
        val isCurrentTempMatch = tempHash != null && tempHash == currentHash

        if (!isCurrentRegularMatch && !isCurrentTempMatch) {
            return Result.failure(IllegalArgumentException("La contraseña actual no es correcta."))
        }

        val newSalt = generateSalt()
        val newHash = hashPassword(newPassword, newSalt)

        prefs.edit()
            .putString(KEY_PASSWORD_SALT, newSalt)
            .putString(KEY_PASSWORD_HASH, newHash)
            .remove(KEY_TEMP_HASH)
            .remove(KEY_TEMP_EXPIRY)
            .apply()

        persistUserProfileToDatabase(
            name = getRegisteredName() ?: "Usuario",
            email = getRegisteredEmail() ?: "",
            hash = newHash,
            salt = newSalt
        )

        return Result.success(Unit)
    }

    fun setNewPasswordDirectly(newPassword: String): Result<Unit> {
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("La nueva contraseña debe tener al menos 6 caracteres."))
        }

        val newSalt = generateSalt()
        val newHash = hashPassword(newPassword, newSalt)

        prefs.edit()
            .putString(KEY_PASSWORD_SALT, newSalt)
            .putString(KEY_PASSWORD_HASH, newHash)
            .remove(KEY_TEMP_HASH)
            .remove(KEY_TEMP_EXPIRY)
            .apply()

        persistUserProfileToDatabase(
            name = getRegisteredName() ?: "Usuario",
            email = getRegisteredEmail() ?: "",
            hash = newHash,
            salt = newSalt
        )

        return Result.success(Unit)
    }

    fun logout() {
        prefs.edit().putBoolean(KEY_IS_LOGGED_IN, false).apply()
    }

    private fun copyToClipboard(text: String) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Contraseña Temporal SaldoX", text)
            clipboard.setPrimaryClip(clip)
        } catch (_: Exception) {
        }
    }

    private fun dispatchEmailIntent(toEmail: String, tempPassword: String) {
        try {
            val subject = "SaldoX - Tu contraseña temporal"
            val body = """
                Hola,
                
                Has solicitado restablecer tu contraseña en SaldoX.
                
                Tu contraseña temporal es:
                $tempPassword
                
                Esta contraseña tiene una validez de 24 horas. Al ingresar con ella, podrás definir tu nueva contraseña.
                
                Atentamente,
                Equipo SaldoX
            """.trimIndent()

            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$toEmail")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(toEmail))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Enviar correo con contraseña temporal").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Exception) {
        }
    }

    private fun hashPassword(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val combined = "$salt:$password"
        val bytes = digest.digest(combined.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun generateSalt(): String {
        val random = SecureRandom()
        val saltBytes = ByteArray(16)
        random.nextBytes(saltBytes)
        return saltBytes.joinToString("") { "%02x".format(it) }
    }

    private fun generateRandomCode(length: Int): String {
        val alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
        val random = SecureRandom()
        val sb = StringBuilder()
        for (i in 0 until length) {
            val idx = random.nextInt(alphabet.length)
            sb.append(alphabet[idx])
        }
        return "SX-" + sb.toString()
    }

    companion object {
        private const val PREFS_NAME = "saldox_user_auth_prefs"
        private const val KEY_NAME = "user_registered_name"
        private const val KEY_EMAIL = "user_registered_email"
        private const val KEY_PASSWORD_HASH = "user_password_hash"
        private const val KEY_PASSWORD_SALT = "user_password_salt"
        private const val KEY_TEMP_HASH = "user_temp_password_hash"
        private const val KEY_TEMP_EXPIRY = "user_temp_password_expiry"
        private const val KEY_IS_LOGGED_IN = "user_is_logged_in"
    }
}
