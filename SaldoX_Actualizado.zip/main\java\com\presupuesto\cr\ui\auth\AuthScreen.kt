package com.presupuesto.cr.ui.auth

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.presupuesto.cr.BuildConfig
import com.presupuesto.cr.R
import com.presupuesto.cr.domain.usecase.GoogleDriveBackupUseCase
import kotlinx.coroutines.launch
import com.presupuesto.cr.ui.theme.BackgroundDark
import com.presupuesto.cr.ui.theme.CyanNeon
import com.presupuesto.cr.ui.theme.EmeraldNeon
import com.presupuesto.cr.ui.theme.ExpenseRed
import com.presupuesto.cr.ui.theme.IncomeGreen
import com.presupuesto.cr.ui.theme.SurfaceDark
import com.presupuesto.cr.ui.theme.ThemeBlue

@Composable
fun AuthScreen(
    authManager: UserAuthManager,
    isBiometricAvailable: Boolean,
    onAuthSuccess: () -> Unit,
    onBiometricRequested: () -> Unit
) {
    val context = LocalContext.current
    val isRegistered = authManager.isUserRegistered()

    var isRegisterMode by remember { mutableStateOf(!isRegistered) }

    // Campos formulario
    var nameInput by remember { mutableStateOf(authManager.getRegisteredName() ?: "") }
    var emailInput by remember {
        mutableStateOf(authManager.getRegisteredEmail() ?: BuildConfig.LINKED_USER_EMAIL)
    }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Diálogo Olvidó Contraseña
    var showForgotDialog by remember { mutableStateOf(false) }
    var forgotEmailInput by remember { mutableStateOf("") }
    var forgotTempResult by remember { mutableStateOf<String?>(null) }
    var forgotError by remember { mutableStateOf<String?>(null) }

    // Diálogo Cambio obligatorio de contraseña (al ingresar con contraseña temporal)
    var showForceChangeDialog by remember { mutableStateOf(false) }
    var forceNewPassword by remember { mutableStateOf("") }
    var forceConfirmPassword by remember { mutableStateOf("") }
    var forcePasswordVisible by remember { mutableStateOf(false) }
    var forceError by remember { mutableStateOf<String?>(null) }

    val coroutineScope = rememberCoroutineScope()
    var isRestoringBackup by remember { mutableStateOf(false) }

    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            isRestoringBackup = true
            coroutineScope.launch {
                val backupUseCase = GoogleDriveBackupUseCase(context)
                val result = backupUseCase.restoreDatabaseFromUri(uri)
                isRestoringBackup = false
                result.fold(
                    onSuccess = { summary ->
                        Toast.makeText(context, summary.message, Toast.LENGTH_LONG).show()
                        if (authManager.isUserRegistered()) {
                            isRegisterMode = false
                            emailInput = authManager.getRegisteredEmail() ?: ""
                            nameInput = authManager.getRegisteredName() ?: ""
                            passwordInput = ""
                            errorMessage = null
                        }
                    },
                    onFailure = { ex ->
                        errorMessage = "Error al restaurar: ${ex.message}"
                    }
                )
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(BackgroundDark, SurfaceDark)
                )
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Logo SaldoX
            Image(
                painter = painterResource(id = R.drawable.saldox_logo),
                contentDescription = "Logo SaldoX",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(92.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .border(1.5.dp, CyanNeon.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Título SaldoX
            Text(
                text = buildAnnotatedString {
                    withStyle(
                        style = SpanStyle(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    ) {
                        append("Saldo")
                    }
                    withStyle(
                        style = SpanStyle(
                            color = Color(0xFF00E5B8),
                            fontWeight = FontWeight.ExtraBold
                        )
                    ) {
                        append("X")
                    }
                },
                fontSize = 30.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "Tu dinero, en perspectiva",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Píldoras de selector: Iniciar Sesión / Registrarse
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            onClick = {
                                isRegisterMode = false
                                errorMessage = null
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = if (!isRegisterMode) ThemeBlue.copy(alpha = 0.22f) else Color.Transparent,
                            border = if (!isRegisterMode) BorderStroke(1.dp, ThemeBlue) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Iniciar Sesión",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (!isRegisterMode) CyanNeon else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            onClick = {
                                isRegisterMode = true
                                errorMessage = null
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isRegisterMode) EmeraldNeon.copy(alpha = 0.22f) else Color.Transparent,
                            border = if (isRegisterMode) BorderStroke(1.dp, EmeraldNeon) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Registrarse",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isRegisterMode) EmeraldNeon else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    if (isRegisterMode) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Nombre completo") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = ThemeBlue)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Correo electrónico") },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = ThemeBlue)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Contraseña") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (passwordVisible) "Ocultar" else "Mostrar",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (isRegisterMode) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = confirmPasswordInput,
                            onValueChange = { confirmPasswordInput = it },
                            label = { Text("Confirmar contraseña") },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (!isRegisterMode) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "¿Olvidaste tu contraseña?",
                                color = ThemeBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .clickable {
                                        forgotEmailInput = emailInput.ifBlank {
                                            authManager.getRegisteredEmail() ?: ""
                                        }
                                        forgotError = null
                                        forgotTempResult = null
                                        showForgotDialog = true
                                    }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }

                    errorMessage?.let { errorText ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorText,
                            color = ExpenseRed,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Botón Principal
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(ThemeBlue, CyanNeon, EmeraldNeon)
                                ),
                                shape = CircleShape
                            )
                            .clickable {
                                errorMessage = null
                                if (isRegisterMode) {
                                    if (passwordInput != confirmPasswordInput) {
                                        errorMessage = "Las contraseñas no coinciden."
                                        return@clickable
                                    }
                                    val result = authManager.registerUser(
                                        name = nameInput,
                                        email = emailInput,
                                        password = passwordInput
                                    )
                                    result.onSuccess {
                                        Toast.makeText(context, "¡Cuenta creada con éxito!", Toast.LENGTH_SHORT).show()
                                        onAuthSuccess()
                                    }.onFailure { ex ->
                                        errorMessage = ex.message ?: "Error al registrar la cuenta."
                                    }
                                } else {
                                    when (authManager.login(emailInput, passwordInput)) {
                                        LoginStatus.SUCCESS -> {
                                            onAuthSuccess()
                                        }
                                        LoginStatus.SUCCESS_WITH_TEMP_PASSWORD -> {
                                            showForceChangeDialog = true
                                        }
                                        LoginStatus.INVALID_CREDENTIALS -> {
                                            errorMessage = "Correo o contraseña incorrectos."
                                        }
                                        LoginStatus.TEMP_PASSWORD_EXPIRED -> {
                                            errorMessage = "La contraseña temporal ha expirado. Solicita una nueva."
                                        }
                                        LoginStatus.USER_NOT_FOUND -> {
                                            errorMessage = "No se encontró usuario en este dispositivo. Si tienes una copia de seguridad en Drive, pulsa 'Restaurar datos' abajo para recuperar tu cuenta y tus movimientos."
                                        }
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isRegisterMode) "Crear Cuenta" else "Iniciar Sesión",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    // Botón Biometría (si está disponible y en modo login)
                    if (!isRegisterMode && isBiometricAvailable) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = onBiometricRequested,
                            shape = CircleShape,
                            border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Acceder con Huella / Rostro",
                                color = CyanNeon,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Botón para restaurar copia de seguridad si reinstaló la app
                    TextButton(
                        onClick = {
                            restoreLauncher.launch(arrayOf("*/*"))
                        },
                        enabled = !isRestoringBackup,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRestoringBackup) "Restaurando respaldo..." else "¿Tienes un respaldo de SaldoX? Restaurar datos",
                            color = CyanNeon,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Diálogo Olvidó Contraseña
    if (showForgotDialog) {
        AlertDialog(
            onDismissRequest = {
                showForgotDialog = false
                forgotTempResult = null
                forgotError = null
            },
            title = {
                Text(
                    text = if (forgotTempResult == null) "Recuperar Contraseña" else "Contraseña Temporal Generada",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (forgotTempResult == null) {
                        Text(
                            text = "Ingresa tu correo registrado. Te enviaremos una contraseña temporal lista para enviar a tu correo y copiada a tu portapapeles.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = forgotEmailInput,
                            onValueChange = { forgotEmailInput = it },
                            label = { Text("Correo registrado") },
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = null, tint = ThemeBlue)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        forgotError?.let { err ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = err, color = ExpenseRed, fontSize = 12.sp)
                        }
                    } else {
                        Text(
                            text = "Se ha abierto tu aplicación de correo para enviar la contraseña a tu bandeja y también se copió al portapapeles:",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            color = ThemeBlue.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = forgotTempResult ?: "",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = CyanNeon
                                )
                                IconButton(
                                    onClick = {
                                        forgotTempResult?.let { code ->
                                            authManager.generateTemporaryPassword(forgotEmailInput)
                                            Toast.makeText(context, "Copiado al portapapeles", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar",
                                        tint = CyanNeon
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Válida por 24 horas. Úsala para iniciar sesión y luego define tu nueva contraseña.",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                if (forgotTempResult == null) {
                    Button(
                        onClick = {
                            forgotError = null
                            val res = authManager.generateTemporaryPassword(forgotEmailInput)
                            res.onSuccess { tempCode ->
                                forgotTempResult = tempCode
                                Toast.makeText(context, "Contraseña temporal generada y copiada", Toast.LENGTH_LONG).show()
                            }.onFailure { ex ->
                                forgotError = ex.message ?: "No fue posible generar la contraseña temporal."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue)
                    ) {
                        Text("Generar y Enviar", color = Color.White)
                    }
                } else {
                    Button(
                        onClick = {
                            emailInput = forgotEmailInput
                            passwordInput = forgotTempResult ?: ""
                            showForgotDialog = false
                            forgotTempResult = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen)
                    ) {
                        Text("Usar e Iniciar Sesión", color = Color.White)
                    }
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showForgotDialog = false
                        forgotTempResult = null
                        forgotError = null
                    }
                ) {
                    Text("Cerrar")
                }
            }
        )
    }

    // Diálogo Forzar Cambio de Contraseña (cuando ingresa con contraseña temporal)
    if (showForceChangeDialog) {
        AlertDialog(
            onDismissRequest = { /* Bloqueante hasta que defina contraseña */ },
            title = { Text("Establecer Nueva Contraseña", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Has ingresado con una contraseña temporal. Por seguridad, debes definir tu nueva contraseña permanente para SaldoX:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = forceNewPassword,
                        onValueChange = { forceNewPassword = it },
                        label = { Text("Nueva contraseña") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                        },
                        trailingIcon = {
                            IconButton(onClick = { forcePasswordVisible = !forcePasswordVisible }) {
                                Icon(
                                    imageVector = if (forcePasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null
                                )
                            }
                        },
                        visualTransformation = if (forcePasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = forceConfirmPassword,
                        onValueChange = { forceConfirmPassword = it },
                        label = { Text("Confirmar nueva contraseña") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                        },
                        visualTransformation = if (forcePasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    forceError?.let { err ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = err, color = ExpenseRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        forceError = null
                        if (forceNewPassword != forceConfirmPassword) {
                            forceError = "Las contraseñas no coinciden."
                            return@Button
                        }
                        val res = authManager.setNewPasswordDirectly(forceNewPassword)
                        res.onSuccess {
                            Toast.makeText(context, "Contraseña actualizada exitosamente", Toast.LENGTH_SHORT).show()
                            showForceChangeDialog = false
                            onAuthSuccess()
                        }.onFailure { ex ->
                            forceError = ex.message ?: "No se pudo actualizar la contraseña."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen)
                ) {
                    Text("Guardar y Continuar", color = Color.White)
                }
            }
        )
    }
}
