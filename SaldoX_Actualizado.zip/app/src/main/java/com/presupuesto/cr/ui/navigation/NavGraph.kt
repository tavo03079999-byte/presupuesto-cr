package com.presupuesto.cr.ui.navigation

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.presupuesto.cr.domain.usecase.GoogleDriveBackupUseCase
import com.presupuesto.cr.ui.activities.ActivitiesScreen
import com.presupuesto.cr.ui.activities.ActivitiesViewModel
import com.presupuesto.cr.ui.calendar.CalendarScreen
import com.presupuesto.cr.ui.calendar.CalendarViewModel
import com.presupuesto.cr.ui.home.HomeScreen
import com.presupuesto.cr.ui.home.HomeViewModel
import com.presupuesto.cr.ui.reports.ReportsScreen
import com.presupuesto.cr.ui.reports.ReportsViewModel
import com.presupuesto.cr.ui.settings.SettingsScreen
import com.presupuesto.cr.ui.settings.SettingsViewModel
import com.presupuesto.cr.ui.theme.ExpenseRed
import com.presupuesto.cr.ui.theme.ThemeBlue
import com.presupuesto.cr.ui.transactions.TransactionsScreen
import com.presupuesto.cr.ui.transactions.TransactionsViewModel

enum class AppMode {
    FINANCES,
    ACTIVITIES
}

@Composable
fun AppModeSwitch(
    currentMode: AppMode,
    onModeSelected: (AppMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Row(
            modifier = Modifier.padding(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Pill Finanzas
            val isFinances = currentMode == AppMode.FINANCES
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isFinances) ThemeBlue else Color.Transparent)
                    .clickable { onModeSelected(AppMode.FINANCES) }
                    .padding(horizontal = 16.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "💰 Finanzas",
                    fontSize = 13.sp,
                    fontWeight = if (isFinances) FontWeight.ExtraBold else FontWeight.Medium,
                    color = if (isFinances) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Pill Actividades
            val isActivities = currentMode == AppMode.ACTIVITIES
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isActivities) ThemeBlue else Color.Transparent)
                    .clickable { onModeSelected(AppMode.ACTIVITIES) }
                    .padding(horizontal = 16.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "🏋️ Actividades",
                    fontSize = 13.sp,
                    fontWeight = if (isActivities) FontWeight.ExtraBold else FontWeight.Medium,
                    color = if (isActivities) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun MainAppNavigation(
    homeViewModel: HomeViewModel,
    transactionsViewModel: TransactionsViewModel,
    reportsViewModel: ReportsViewModel,
    calendarViewModel: CalendarViewModel,
    settingsViewModel: SettingsViewModel,
    activitiesViewModel: ActivitiesViewModel,
    googleDriveBackupUseCase: GoogleDriveBackupUseCase,
    onLogout: () -> Unit = {}
) {
    var currentAppMode by rememberSaveable { mutableStateOf(AppMode.FINANCES) }

    if (currentAppMode == AppMode.ACTIVITIES) {
        ActivitiesScreen(
            viewModel = activitiesViewModel,
            headerSlot = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AppModeSwitch(
                        currentMode = currentAppMode,
                        onModeSelected = { currentAppMode = it }
                    )
                }
            }
        )
    } else {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route

        val pendingBcrCount by homeViewModel.pendingBcrCount.collectAsState()

        val screens = listOf(
            Screen.Home,
            Screen.Transactions,
            Screen.Reports,
            Screen.Calendar,
            Screen.Settings
        )

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            AppModeSwitch(
                                currentMode = currentAppMode,
                                onModeSelected = { currentAppMode = it }
                            )
                        }
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                            thickness = 1.dp
                        )
                    }
                }
            },
            bottomBar = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        thickness = 1.dp
                    )
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp
                    ) {
                        screens.forEach { screen ->
                            val isSelected = currentRoute == screen.route
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    navigateSingleTop(navController, screen.route)
                                },
                                icon = {
                                    if (screen == Screen.Transactions && pendingBcrCount > 0) {
                                        BadgedBox(
                                            badge = {
                                                Badge(containerColor = ExpenseRed) {
                                                    Text("$pendingBcrCount", color = Color.White)
                                                }
                                            }
                                        ) {
                                            Icon(screen.icon, contentDescription = screen.title)
                                        }
                                    } else {
                                        Icon(screen.icon, contentDescription = screen.title)
                                    }
                                },
                                label = {
                                    Text(
                                        text = screen.title,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ThemeBlue,
                                    selectedTextColor = ThemeBlue,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.padding(innerPadding)
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = homeViewModel,
                        onNavigateToTransactions = { type, categoryId ->
                            transactionsViewModel.applyExternalFilter(
                                type = type,
                                categoryId = categoryId
                            )
                            navigateSingleTop(navController, Screen.Transactions.route)
                        },
                        onNavigateToReports = {
                            navigateSingleTop(navController, Screen.Reports.route)
                        },
                        onNavigateToSettings = {
                            navigateSingleTop(navController, Screen.Settings.route)
                        }
                    )
                }
                composable(Screen.Transactions.route) {
                    TransactionsScreen(viewModel = transactionsViewModel)
                }
                composable(Screen.Reports.route) {
                    ReportsScreen(
                        viewModel = reportsViewModel,
                        onNavigateToFilteredTransactions = { type, categoryId, startMillis, endMillis ->
                            transactionsViewModel.applyExternalFilter(
                                type = type,
                                categoryId = categoryId,
                                startMillis = startMillis,
                                endMillis = endMillis
                            )
                            navigateSingleTop(navController, Screen.Transactions.route)
                        }
                    )
                }
                composable(Screen.Calendar.route) {
                    CalendarScreen(viewModel = calendarViewModel)
                }
                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = settingsViewModel,
                        googleDriveBackupUseCase = googleDriveBackupUseCase,
                        onLogout = onLogout
                    )
                }
            }
        }
    }
}

private fun navigateSingleTop(
    navController: NavHostController,
    route: String
) {
    navController.navigate(route) {
        popUpTo(navController.graph.findStartDestination().id) {
            saveState = true
        }
        launchSingleTop = true
        restoreState = true
    }
}
