package com.presupuesto.cr.util

import android.content.Context
import android.content.Intent
import android.os.Process
import com.presupuesto.cr.MainActivity

object AppRestartHelper {

    fun restartApp(context: Context) {
        try {
            val packageManager = context.packageManager
            val intent = packageManager.getLaunchIntentForPackage(context.packageName)
            if (intent != null) {
                val restartIntent = Intent.makeRestartActivityTask(intent.component)
                context.startActivity(restartIntent)
            } else {
                val fallbackIntent = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                context.startActivity(fallbackIntent)
            }
            Process.killProcess(Process.myPid())
            Runtime.getRuntime().exit(0)
        } catch (_: Exception) {
            val fallbackIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            context.startActivity(fallbackIntent)
            Runtime.getRuntime().exit(0)
        }
    }
}
