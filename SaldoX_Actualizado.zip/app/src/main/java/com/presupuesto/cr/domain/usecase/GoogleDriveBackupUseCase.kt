package com.presupuesto.cr.domain.usecase

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.presupuesto.cr.PresupuestoApp
import com.presupuesto.cr.data.local.AppDatabase
import com.presupuesto.cr.data.local.entity.AccountEntity
import com.presupuesto.cr.data.local.entity.AccountType
import com.presupuesto.cr.data.local.entity.BudgetEntity
import com.presupuesto.cr.data.local.entity.BudgetPeriod
import com.presupuesto.cr.data.local.entity.CategoryEntity
import com.presupuesto.cr.data.local.entity.CategoryType
import com.presupuesto.cr.data.local.entity.RecurringFrequency
import com.presupuesto.cr.data.local.entity.RecurringMovementEntity
import com.presupuesto.cr.data.local.entity.TransactionEntity
import com.presupuesto.cr.data.local.entity.TransactionSource
import com.presupuesto.cr.data.local.entity.UserProfileEntity
import com.presupuesto.cr.data.repository.FinanceRepository
import com.presupuesto.cr.ui.auth.UserAuthManager
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class RestoreSummary(
    val transactionCount: Int,
    val message: String
)

data class BackupValidationResult(
    val isValid: Boolean,
    val transactionCount: Int,
    val errorMessage: String? = null
)

data class BackupInspection(
    val tempFile: File,
    val transactionCount: Int,
    val categoryCount: Int,
    val accountCount: Int,
    val userEmail: String?,
    val backupDateMillis: Long?,
    val fileName: String
)

class GoogleDriveBackupUseCase(
    private val context: Context
) {
    companion object {
        const val TARGET_ACCOUNT_EMAIL = "tavo03079999@gmail.com"
        private const val DB_FILE_NAME = "presupuesto_cr_encrypted.db"
    }

    fun getGoogleSignInClient(): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getLastSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && account.email.equals(TARGET_ACCOUNT_EMAIL, ignoreCase = true)) {
            account
        } else {
            account
        }
    }

    fun createBackupFileForSharing(): Result<File> {
        try {
            AppDatabase.checkpoint()
            val dbFile = context.getDatabasePath(DB_FILE_NAME)
            if (!dbFile.exists()) {
                return Result.failure(IllegalStateException("No se encontró el archivo de base de datos local"))
            }
            val backupDir = File(context.cacheDir, "backups").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val targetFile = File(backupDir, "SaldoX_Respaldo_${timeStamp}.db")
            dbFile.copyTo(targetFile, overwrite = true)

            try {
                val docsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SaldoX")
                if (!docsDir.exists()) docsDir.mkdirs()
                targetFile.copyTo(File(docsDir, "SaldoX_Respaldo_Reciente.db"), overwrite = true)
            } catch (_: Exception) {
            }

            return Result.success(targetFile)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    private fun openBackupDatabase(backupFile: File): Pair<net.sqlcipher.database.SQLiteDatabase, ByteArray>? {
        val prefs = context.getSharedPreferences("security_prefs_cr", Context.MODE_PRIVATE)
        val storedKey = prefs.getString("db_sec_key", null)

        val candidateKeys = mutableListOf<ByteArray>()
        candidateKeys.add(AppDatabase.MASTER_DB_PASSPHRASE.toByteArray(Charsets.UTF_8))
        if (!storedKey.isNullOrBlank()) {
            candidateKeys.add(storedKey.toByteArray(Charsets.UTF_8))
        }
        candidateKeys.add("SaldoX-CR-SQLCipher-Master-SecureKey-2024#CR".toByteArray(Charsets.UTF_8))
        candidateKeys.add(ByteArray(0))

        for (candidate in candidateKeys) {
            try {
                val db = net.sqlcipher.database.SQLiteDatabase.openDatabase(
                    backupFile.absolutePath,
                    candidate,
                    null,
                    net.sqlcipher.database.SQLiteDatabase.OPEN_READWRITE
                )
                val cursor = db.rawQuery("SELECT count(*) FROM sqlite_master", null)
                if (cursor.moveToFirst()) {
                    cursor.close()
                    return Pair(db, candidate)
                }
                cursor.close()
                db.close()
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun validateAndPrepareBackupFile(backupFile: File): BackupValidationResult {
        val opened = openBackupDatabase(backupFile) ?: return BackupValidationResult(
            isValid = false,
            transactionCount = 0,
            errorMessage = "El archivo seleccionado no es una copia de seguridad válida de SaldoX o no se pudo descifrar."
        )

        val workingDb = opened.first
        val workingKey = opened.second

        try {
            var txCount = 0
            val cursorTx = workingDb.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='transactions'", null)
            val hasTxTable = if (cursorTx.moveToFirst()) cursorTx.getInt(0) > 0 else false
            cursorTx.close()

            if (hasTxTable) {
                val countCursor = workingDb.rawQuery("SELECT count(*) FROM transactions", null)
                if (countCursor.moveToFirst()) {
                    txCount = countCursor.getInt(0)
                }
                countCursor.close()
            }

            val masterBytes = AppDatabase.MASTER_DB_PASSPHRASE.toByteArray(Charsets.UTF_8)
            if (!workingKey.contentEquals(masterBytes)) {
                workingDb.changePassword(masterBytes)
            }

            try {
                val checkpointCursor = workingDb.rawQuery("PRAGMA wal_checkpoint(FULL)", null)
                checkpointCursor.moveToFirst()
                checkpointCursor.close()
            } catch (_: Exception) {
            }

            workingDb.close()

            return BackupValidationResult(
                isValid = true,
                transactionCount = txCount
            )
        } catch (e: Exception) {
            try { workingDb.close() } catch (_: Exception) {}
            return BackupValidationResult(
                isValid = false,
                transactionCount = 0,
                errorMessage = "Error al leer los datos de la copia: ${e.localizedMessage}"
            )
        }
    }

    suspend fun inspectBackupFile(uri: Uri): Result<BackupInspection> = withContext(Dispatchers.IO) {
        try {
            var displayName = "Respaldo_Google_Drive.db"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0) {
                        displayName = cursor.getString(nameIdx) ?: displayName
                    }
                }
            }

            val tempFile = File(context.cacheDir, "temp_inspected_backup.db")
            if (tempFile.exists()) tempFile.delete()

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("No se pudo leer el archivo de respaldo seleccionado"))

            inspectLocalFile(tempFile, displayName)
        } catch (e: Exception) {
            Result.failure(Exception("Error al inspeccionar respaldo: ${e.localizedMessage}"))
        }
    }

    suspend fun inspectLocalRecentBackup(): Result<BackupInspection> = withContext(Dispatchers.IO) {
        try {
            val candidateDirs = listOf(
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SaldoX"),
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "SaldoX"),
                File(context.cacheDir, "backups")
            )

            var bestFile: File? = null
            for (dir in candidateDirs) {
                if (dir.exists() && dir.isDirectory) {
                    val dbFiles = dir.listFiles { f -> f.isFile && f.name.endsWith(".db") }
                    if (dbFiles != null && dbFiles.isNotEmpty()) {
                        val mostRecent = dbFiles.maxByOrNull { it.lastModified() }
                        if (mostRecent != null && (bestFile == null || mostRecent.lastModified() > bestFile.lastModified())) {
                            bestFile = mostRecent
                        }
                    }
                }
            }

            if (bestFile == null || !bestFile.exists()) {
                return@withContext Result.failure(IllegalStateException("No se encontró ningún archivo de respaldo reciente en el dispositivo."))
            }

            val tempFile = File(context.cacheDir, "temp_inspected_backup.db")
            if (tempFile.exists()) tempFile.delete()
            bestFile.copyTo(tempFile, overwrite = true)

            inspectLocalFile(tempFile, bestFile.name)
        } catch (e: Exception) {
            Result.failure(Exception("Error al buscar respaldo reciente: ${e.localizedMessage}"))
        }
    }

    private fun inspectLocalFile(file: File, originalName: String): Result<BackupInspection> {
        val opened = openBackupDatabase(file) ?: return Result.failure(
            IllegalStateException("El archivo seleccionado no es un respaldo cifrado válido de SaldoX.")
        )
        val db = opened.first
        try {
            var txCount = 0
            var catCount = 0
            var accCount = 0
            var userEmail: String? = null

            // Conteo de transacciones
            val cTxCheck = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='transactions'", null)
            val hasTx = if (cTxCheck.moveToFirst()) cTxCheck.getInt(0) > 0 else false
            cTxCheck.close()
            if (hasTx) {
                val c = db.rawQuery("SELECT count(*) FROM transactions", null)
                if (c.moveToFirst()) txCount = c.getInt(0)
                c.close()
            }

            // Conteo de categorías
            val cCatCheck = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='categories'", null)
            val hasCat = if (cCatCheck.moveToFirst()) cCatCheck.getInt(0) > 0 else false
            cCatCheck.close()
            if (hasCat) {
                val c = db.rawQuery("SELECT count(*) FROM categories", null)
                if (c.moveToFirst()) catCount = c.getInt(0)
                c.close()
            }

            // Conteo de cuentas
            val cAccCheck = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='accounts'", null)
            val hasAcc = if (cAccCheck.moveToFirst()) cAccCheck.getInt(0) > 0 else false
            cAccCheck.close()
            if (hasAcc) {
                val c = db.rawQuery("SELECT count(*) FROM accounts", null)
                if (c.moveToFirst()) accCount = c.getInt(0)
                c.close()
            }

            // Usuario registrado en la copia
            val cUserCheck = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='user_profile'", null)
            val hasUser = if (cUserCheck.moveToFirst()) cUserCheck.getInt(0) > 0 else false
            cUserCheck.close()
            if (hasUser) {
                val c = db.rawQuery("SELECT email FROM user_profile ORDER BY id DESC LIMIT 1", null)
                if (c.moveToFirst()) userEmail = c.getString(0)
                c.close()
            }

            db.close()

            return Result.success(
                BackupInspection(
                    tempFile = file,
                    transactionCount = txCount,
                    categoryCount = catCount,
                    accountCount = accCount,
                    userEmail = userEmail,
                    backupDateMillis = file.lastModified(),
                    fileName = originalName
                )
            )
        } catch (e: Exception) {
            try { db.close() } catch (_: Exception) {}
            return Result.failure(Exception("Error al inspeccionar base de datos: ${e.localizedMessage}"))
        }
    }

    suspend fun restoreFromInspectedBackup(
        inspection: BackupInspection,
        repository: FinanceRepository
    ): Result<RestoreSummary> = withContext(Dispatchers.IO) {
        val file = inspection.tempFile
        val opened = openBackupDatabase(file) ?: return@withContext Result.failure(
            IllegalStateException("No fue posible abrir el archivo de respaldo para restaurar.")
        )
        val db = opened.first
        try {
            val categories = extractCategoriesFromDb(db)
            val accounts = extractAccountsFromDb(db)
            val transactions = extractTransactionsFromDb(db)
            val budgets = extractBudgetsFromDb(db)
            val reminders = extractRemindersFromDb(db)
            val userProfile = extractUserProfileFromDb(db)

            db.close()

            repository.restoreDatabaseEntities(
                categories = categories,
                accounts = accounts,
                transactions = transactions,
                budgets = budgets,
                reminders = reminders
            )

            if (userProfile != null) {
                try {
                    val localDb = AppDatabase.getInstance(context)
                    localDb.userProfileDao().insert(userProfile)
                    val authManager = UserAuthManager(context)
                    authManager.syncUserFromRestoredProfile(
                        name = userProfile.name,
                        email = userProfile.email,
                        passwordHash = userProfile.passwordHash,
                        passwordSalt = userProfile.passwordSalt
                    )
                } catch (_: Exception) {
                }
            }

            AppDatabase.checkpoint()

            try {
                val docsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SaldoX")
                if (!docsDir.exists()) docsDir.mkdirs()
                file.copyTo(File(docsDir, "SaldoX_Respaldo_Reciente.db"), overwrite = true)
            } catch (_: Exception) {
            }

            if (file.exists()) file.delete()

            (context.applicationContext as? PresupuestoApp)?.refreshDatabase()

            val summary = RestoreSummary(
                transactionCount = inspection.transactionCount,
                message = "¡Se restauraron con éxito ${inspection.transactionCount} transacciones en tu aplicación!"
            )
            Result.success(summary)
        } catch (e: Exception) {
            try { db.close() } catch (_: Exception) {}
            Result.failure(Exception("Error durante la restauración de movimientos: ${e.localizedMessage}"))
        }
    }

    private fun extractCategoriesFromDb(db: net.sqlcipher.database.SQLiteDatabase): List<CategoryEntity> {
        val list = mutableListOf<CategoryEntity>()
        val checkCursor = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='categories'", null)
        val hasTable = if (checkCursor.moveToFirst()) checkCursor.getInt(0) > 0 else false
        checkCursor.close()
        if (!hasTable) return list

        val cursor = db.rawQuery("SELECT * FROM categories", null)
        val idIdx = cursor.getColumnIndex("id")
        val nameIdx = cursor.getColumnIndex("name")
        val typeIdx = cursor.getColumnIndex("type")
        val iconNameIdx = cursor.getColumnIndex("iconName")
        val colorHexIdx = cursor.getColumnIndex("colorHex")
        val isFixedExpenseIdx = cursor.getColumnIndex("isFixedExpense")
        val isSpecialAllocationIdx = cursor.getColumnIndex("isSpecialBalanceAllocation")
        val createdAtIdx = cursor.getColumnIndex("created_at")
        val updatedAtIdx = cursor.getColumnIndex("updated_at")

        while (cursor.moveToNext()) {
            try {
                val typeStr = if (typeIdx >= 0) cursor.getString(typeIdx) else "EXPENSE"
                val catType = try { CategoryType.valueOf(typeStr) } catch (_: Exception) { CategoryType.EXPENSE }
                val item = CategoryEntity(
                    id = if (idIdx >= 0) cursor.getLong(idIdx) else 0L,
                    name = if (nameIdx >= 0) cursor.getString(nameIdx) else "Categoría",
                    type = catType,
                    iconName = if (iconNameIdx >= 0) cursor.getString(iconNameIdx) else "category",
                    colorHex = if (colorHexIdx >= 0) cursor.getString(colorHexIdx) else "#2196F3",
                    isFixedExpense = if (isFixedExpenseIdx >= 0) cursor.getInt(isFixedExpenseIdx) == 1 else false,
                    isSpecialBalanceAllocation = if (isSpecialAllocationIdx >= 0) cursor.getInt(isSpecialAllocationIdx) == 1 else false,
                    createdAt = if (createdAtIdx >= 0) cursor.getLong(createdAtIdx) else System.currentTimeMillis(),
                    updatedAt = if (updatedAtIdx >= 0) cursor.getLong(updatedAtIdx) else System.currentTimeMillis()
                )
                list.add(item)
            } catch (_: Exception) {}
        }
        cursor.close()
        return list
    }

    private fun extractAccountsFromDb(db: net.sqlcipher.database.SQLiteDatabase): List<AccountEntity> {
        val list = mutableListOf<AccountEntity>()
        val checkCursor = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='accounts'", null)
        val hasTable = if (checkCursor.moveToFirst()) checkCursor.getInt(0) > 0 else false
        checkCursor.close()
        if (!hasTable) return list

        val cursor = db.rawQuery("SELECT * FROM accounts", null)
        val idIdx = cursor.getColumnIndex("id")
        val nameIdx = cursor.getColumnIndex("name")
        val typeIdx = cursor.getColumnIndex("accountType")
        val currentBalanceIdx = cursor.getColumnIndex("currentBalance")
        val creditLimitIdx = cursor.getColumnIndex("creditLimit")
        val currencyIdx = cursor.getColumnIndex("currency")
        val accountNumberMaskedIdx = cursor.getColumnIndex("accountNumberMasked")
        val colorHexIdx = cursor.getColumnIndex("colorHex")
        val isIncludedInNetWorthIdx = cursor.getColumnIndex("isIncludedInNetWorth")
        val isIncludedInSafeToSpendIdx = cursor.getColumnIndex("isIncludedInSafeToSpend")
        val createdAtIdx = cursor.getColumnIndex("created_at")
        val updatedAtIdx = cursor.getColumnIndex("updated_at")

        while (cursor.moveToNext()) {
            try {
                val typeStr = if (typeIdx >= 0) cursor.getString(typeIdx) else "CHECKING_BCR"
                val accType = try { AccountType.valueOf(typeStr) } catch (_: Exception) { AccountType.CHECKING_BCR }
                val item = AccountEntity(
                    id = if (idIdx >= 0) cursor.getLong(idIdx) else 0L,
                    name = if (nameIdx >= 0) cursor.getString(nameIdx) else "Cuenta",
                    accountType = accType,
                    currentBalance = if (currentBalanceIdx >= 0) cursor.getDouble(currentBalanceIdx) else 0.0,
                    creditLimit = if (creditLimitIdx >= 0) cursor.getDouble(creditLimitIdx) else 0.0,
                    currency = if (currencyIdx >= 0) cursor.getString(currencyIdx) else "CRC",
                    accountNumberMasked = if (accountNumberMaskedIdx >= 0) cursor.getString(accountNumberMaskedIdx) else "",
                    colorHex = if (colorHexIdx >= 0) cursor.getString(colorHexIdx) else "#4CAF50",
                    isIncludedInNetWorth = if (isIncludedInNetWorthIdx >= 0) cursor.getInt(isIncludedInNetWorthIdx) == 1 else true,
                    isIncludedInSafeToSpend = if (isIncludedInSafeToSpendIdx >= 0) cursor.getInt(isIncludedInSafeToSpendIdx) == 1 else true,
                    createdAt = if (createdAtIdx >= 0) cursor.getLong(createdAtIdx) else System.currentTimeMillis(),
                    updatedAt = if (updatedAtIdx >= 0) cursor.getLong(updatedAtIdx) else System.currentTimeMillis()
                )
                list.add(item)
            } catch (_: Exception) {}
        }
        cursor.close()
        return list
    }

    private fun extractTransactionsFromDb(db: net.sqlcipher.database.SQLiteDatabase): List<TransactionEntity> {
        val list = mutableListOf<TransactionEntity>()
        val checkCursor = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='transactions'", null)
        val hasTable = if (checkCursor.moveToFirst()) checkCursor.getInt(0) > 0 else false
        checkCursor.close()
        if (!hasTable) return list

        val cursor = db.rawQuery("SELECT * FROM transactions", null)
        val idIdx = cursor.getColumnIndex("id")
        val accountIdIdx = cursor.getColumnIndex("accountId")
        val categoryIdIdx = cursor.getColumnIndex("categoryId")
        val amountIdx = cursor.getColumnIndex("amount")
        val typeIdx = cursor.getColumnIndex("type")
        val timestampIdx = cursor.getColumnIndex("timestamp")
        val noteIdx = cursor.getColumnIndex("note")
        val merchantIdx = cursor.getColumnIndex("merchant")
        val isRecurringIdx = cursor.getColumnIndex("isRecurring")
        val recurringMovementIdIdx = cursor.getColumnIndex("recurringMovementId")
        val sourceIdx = cursor.getColumnIndex("source")
        val receiptImagePathIdx = cursor.getColumnIndex("receiptImagePath")
        val createdAtIdx = cursor.getColumnIndex("created_at")
        val updatedAtIdx = cursor.getColumnIndex("updated_at")

        while (cursor.moveToNext()) {
            try {
                val typeStr = if (typeIdx >= 0) cursor.getString(typeIdx) else "EXPENSE"
                val txType = try { CategoryType.valueOf(typeStr) } catch (_: Exception) { CategoryType.EXPENSE }
                val sourceStr = if (sourceIdx >= 0) cursor.getString(sourceIdx) else "MANUAL"
                val txSource = try { TransactionSource.valueOf(sourceStr) } catch (_: Exception) { TransactionSource.MANUAL }
                val item = TransactionEntity(
                    id = if (idIdx >= 0) cursor.getLong(idIdx) else 0L,
                    accountId = if (accountIdIdx >= 0) cursor.getLong(accountIdIdx) else 1L,
                    categoryId = if (categoryIdIdx >= 0) cursor.getLong(categoryIdIdx) else 1L,
                    amount = if (amountIdx >= 0) cursor.getDouble(amountIdx) else 0.0,
                    type = txType,
                    timestamp = if (timestampIdx >= 0) cursor.getLong(timestampIdx) else System.currentTimeMillis(),
                    note = if (noteIdx >= 0) cursor.getString(noteIdx) else "",
                    merchant = if (merchantIdx >= 0 && !cursor.isNull(merchantIdx)) cursor.getString(merchantIdx) else null,
                    isRecurring = if (isRecurringIdx >= 0) cursor.getInt(isRecurringIdx) == 1 else false,
                    recurringMovementId = if (recurringMovementIdIdx >= 0 && !cursor.isNull(recurringMovementIdIdx)) cursor.getLong(recurringMovementIdIdx) else null,
                    source = txSource,
                    receiptImagePath = if (receiptImagePathIdx >= 0 && !cursor.isNull(receiptImagePathIdx)) cursor.getString(receiptImagePathIdx) else null,
                    createdAt = if (createdAtIdx >= 0) cursor.getLong(createdAtIdx) else System.currentTimeMillis(),
                    updatedAt = if (updatedAtIdx >= 0) cursor.getLong(updatedAtIdx) else System.currentTimeMillis()
                )
                list.add(item)
            } catch (_: Exception) {}
        }
        cursor.close()
        return list
    }

    private fun extractBudgetsFromDb(db: net.sqlcipher.database.SQLiteDatabase): List<BudgetEntity> {
        val list = mutableListOf<BudgetEntity>()
        val checkCursor = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='budgets'", null)
        val hasTable = if (checkCursor.moveToFirst()) checkCursor.getInt(0) > 0 else false
        checkCursor.close()
        if (!hasTable) return list

        val cursor = db.rawQuery("SELECT * FROM budgets", null)
        val idIdx = cursor.getColumnIndex("id")
        val categoryIdIdx = cursor.getColumnIndex("categoryId")
        val periodIdx = cursor.getColumnIndex("period")
        val limitAmountIdx = cursor.getColumnIndex("limitAmount")
        val alertThresholdPercentIdx = cursor.getColumnIndex("alertThresholdPercent")
        val startDateIdx = cursor.getColumnIndex("startDate")
        val createdAtIdx = cursor.getColumnIndex("created_at")
        val updatedAtIdx = cursor.getColumnIndex("updated_at")

        while (cursor.moveToNext()) {
            try {
                val periodStr = if (periodIdx >= 0) cursor.getString(periodIdx) else "MONTHLY"
                val bPeriod = try { BudgetPeriod.valueOf(periodStr) } catch (_: Exception) { BudgetPeriod.MONTHLY }
                val item = BudgetEntity(
                    id = if (idIdx >= 0) cursor.getLong(idIdx) else 0L,
                    categoryId = if (categoryIdIdx >= 0) cursor.getLong(categoryIdIdx) else 1L,
                    period = bPeriod,
                    limitAmount = if (limitAmountIdx >= 0) cursor.getDouble(limitAmountIdx) else 0.0,
                    alertThresholdPercent = if (alertThresholdPercentIdx >= 0) cursor.getDouble(alertThresholdPercentIdx) else 80.0,
                    startDate = if (startDateIdx >= 0) cursor.getLong(startDateIdx) else System.currentTimeMillis(),
                    createdAt = if (createdAtIdx >= 0) cursor.getLong(createdAtIdx) else System.currentTimeMillis(),
                    updatedAt = if (updatedAtIdx >= 0) cursor.getLong(updatedAtIdx) else System.currentTimeMillis()
                )
                list.add(item)
            } catch (_: Exception) {}
        }
        cursor.close()
        return list
    }

    private fun extractRemindersFromDb(db: net.sqlcipher.database.SQLiteDatabase): List<RecurringMovementEntity> {
        val list = mutableListOf<RecurringMovementEntity>()
        val checkCursor = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='payment_reminders'", null)
        val hasTable = if (checkCursor.moveToFirst()) checkCursor.getInt(0) > 0 else false
        checkCursor.close()
        if (!hasTable) return list

        val cursor = db.rawQuery("SELECT * FROM payment_reminders", null)
        val idIdx = cursor.getColumnIndex("id")
        val nameIdx = cursor.getColumnIndex("name")
        val amountIdx = cursor.getColumnIndex("amount")
        val typeIdx = cursor.getColumnIndex("type")
        val categoryIdIdx = cursor.getColumnIndex("categoryId")
        val accountIdIdx = cursor.getColumnIndex("accountId")
        val frequencyIdx = cursor.getColumnIndex("frequency")
        val dayOfMonthIdx = cursor.getColumnIndex("dayOfMonth")
        val secondDayOfMonthIdx = cursor.getColumnIndex("secondDayOfMonth")
        val nextDueDateIdx = cursor.getColumnIndex("nextDueDate")
        val isActiveIdx = cursor.getColumnIndex("isActive")
        val isPaidIdx = cursor.getColumnIndex("isPaidForCurrentPeriod")
        val autoDeductIdx = cursor.getColumnIndex("autoDeductOnDueDate")
        val reminderOffsetHoursIdx = cursor.getColumnIndex("reminderOffsetHours")
        val createdAtIdx = cursor.getColumnIndex("created_at")
        val updatedAtIdx = cursor.getColumnIndex("updated_at")

        while (cursor.moveToNext()) {
            try {
                val typeStr = if (typeIdx >= 0) cursor.getString(typeIdx) else "EXPENSE"
                val cType = try { CategoryType.valueOf(typeStr) } catch (_: Exception) { CategoryType.EXPENSE }
                val freqStr = if (frequencyIdx >= 0) cursor.getString(frequencyIdx) else "FORTNIGHTLY_15_30"
                val freq = try { RecurringFrequency.valueOf(freqStr) } catch (_: Exception) { RecurringFrequency.FORTNIGHTLY_15_30 }
                val item = RecurringMovementEntity(
                    id = if (idIdx >= 0) cursor.getLong(idIdx) else 0L,
                    name = if (nameIdx >= 0) cursor.getString(nameIdx) else "Recordatorio",
                    amount = if (amountIdx >= 0) cursor.getDouble(amountIdx) else 0.0,
                    type = cType,
                    categoryId = if (categoryIdIdx >= 0) cursor.getLong(categoryIdIdx) else 1L,
                    accountId = if (accountIdIdx >= 0) cursor.getLong(accountIdIdx) else 1L,
                    frequency = freq,
                    dayOfMonth = if (dayOfMonthIdx >= 0) cursor.getInt(dayOfMonthIdx) else 15,
                    secondDayOfMonth = if (secondDayOfMonthIdx >= 0 && !cursor.isNull(secondDayOfMonthIdx)) cursor.getInt(secondDayOfMonthIdx) else 30,
                    nextDueDate = if (nextDueDateIdx >= 0) cursor.getLong(nextDueDateIdx) else System.currentTimeMillis(),
                    isActive = if (isActiveIdx >= 0) cursor.getInt(isActiveIdx) == 1 else true,
                    isPaidForCurrentPeriod = if (isPaidIdx >= 0) cursor.getInt(isPaidIdx) == 1 else false,
                    autoDeductOnDueDate = if (autoDeductIdx >= 0) cursor.getInt(autoDeductIdx) == 1 else false,
                    reminderOffsetHours = if (reminderOffsetHoursIdx >= 0) cursor.getInt(reminderOffsetHoursIdx) else 24,
                    createdAt = if (createdAtIdx >= 0) cursor.getLong(createdAtIdx) else System.currentTimeMillis(),
                    updatedAt = if (updatedAtIdx >= 0) cursor.getLong(updatedAtIdx) else System.currentTimeMillis()
                )
                list.add(item)
            } catch (_: Exception) {}
        }
        cursor.close()
        return list
    }

    private fun extractUserProfileFromDb(db: net.sqlcipher.database.SQLiteDatabase): UserProfileEntity? {
        val checkCursor = db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='user_profile'", null)
        val hasTable = if (checkCursor.moveToFirst()) checkCursor.getInt(0) > 0 else false
        checkCursor.close()
        if (!hasTable) return null

        val cursor = db.rawQuery("SELECT * FROM user_profile ORDER BY id DESC LIMIT 1", null)
        var profile: UserProfileEntity? = null
        if (cursor.moveToFirst()) {
            try {
                val idIdx = cursor.getColumnIndex("id")
                val nameIdx = cursor.getColumnIndex("name")
                val emailIdx = cursor.getColumnIndex("email")
                val hashIdx = cursor.getColumnIndex("password_hash")
                val saltIdx = cursor.getColumnIndex("password_salt")
                val createdAtIdx = cursor.getColumnIndex("created_at")
                val updatedAtIdx = cursor.getColumnIndex("updated_at")

                profile = UserProfileEntity(
                    id = if (idIdx >= 0) cursor.getLong(idIdx) else 0L,
                    name = if (nameIdx >= 0) cursor.getString(nameIdx) else "",
                    email = if (emailIdx >= 0) cursor.getString(emailIdx) else "",
                    passwordHash = if (hashIdx >= 0) cursor.getString(hashIdx) else "",
                    passwordSalt = if (saltIdx >= 0) cursor.getString(saltIdx) else "",
                    createdAt = if (createdAtIdx >= 0) cursor.getLong(createdAtIdx) else System.currentTimeMillis(),
                    updatedAt = if (updatedAtIdx >= 0) cursor.getLong(updatedAtIdx) else System.currentTimeMillis()
                )
            } catch (_: Exception) {}
        }
        cursor.close()
        return profile
    }

    suspend fun restoreDatabaseFromUri(uri: Uri): Result<RestoreSummary> = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.cacheDir, "temp_incoming_restore.db")
            if (tempFile.exists()) tempFile.delete()

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("No se pudo leer el archivo de respaldo seleccionado"))

            val validation = validateAndPrepareBackupFile(tempFile)
            if (!validation.isValid) {
                tempFile.delete()
                return@withContext Result.failure(IllegalStateException(validation.errorMessage ?: "Respaldo no válido"))
            }

            AppDatabase.closeInstance()

            val destinationDb = context.getDatabasePath(DB_FILE_NAME)
            val walFile = File(destinationDb.path + "-wal")
            val shmFile = File(destinationDb.path + "-shm")

            if (walFile.exists()) walFile.delete()
            if (shmFile.exists()) shmFile.delete()

            tempFile.copyTo(destinationDb, overwrite = true)
            tempFile.delete()

            AppDatabase.ensureMasterPassphrase(context)
            val db = AppDatabase.getInstance(context)

            val userProfile = db.userProfileDao().getUserProfile()
            if (userProfile != null) {
                val authManager = UserAuthManager(context)
                authManager.syncUserFromRestoredProfile(
                    name = userProfile.name,
                    email = userProfile.email,
                    passwordHash = userProfile.passwordHash,
                    passwordSalt = userProfile.passwordSalt
                )
            }

            (context.applicationContext as? PresupuestoApp)?.refreshDatabase()

            val summary = RestoreSummary(
                transactionCount = validation.transactionCount,
                message = "¡Copia de seguridad restaurada con éxito! Se verificaron ${validation.transactionCount} transacciones en tus movimientos."
            )

            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(Exception("Error al restaurar archivo: ${e.localizedMessage}"))
        }
    }

    suspend fun uploadDatabaseBackup(account: GoogleSignInAccount): Result<String> = withContext(Dispatchers.IO) {
        try {
            AppDatabase.checkpoint()

            val credential = GoogleAccountCredential.usingOAuth2(
                context,
                Collections.singleton(DriveScopes.DRIVE_FILE)
            ).apply {
                selectedAccount = account.account
            }

            val driveService = Drive.Builder(
                NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                credential
            ).setApplicationName("SaldoX").build()

            val dbFile = context.getDatabasePath(DB_FILE_NAME)
            if (!dbFile.exists()) {
                return@withContext Result.failure(IllegalStateException("No se encontró el archivo de base de datos local"))
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val metadata = DriveFile().apply {
                name = "Backup_SaldoX_${timeStamp}.db"
                description = "Respaldo seguro cifrado de SaldoX para ${account.email ?: TARGET_ACCOUNT_EMAIL}"
            }

            val mediaContent = FileContent("application/x-sqlite3", dbFile)
            val uploadedFile = driveService.files().create(metadata, mediaContent)
                .setFields("id, name, createdTime")
                .execute()

            Result.success("Respaldo exitoso en Google Drive: ${uploadedFile.name}")
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: e.message ?: "Verifica tu conexión"
            Result.failure(Exception("No fue posible completar el respaldo en Google Drive: $msg"))
        }
    }

    suspend fun restoreDatabaseBackup(account: GoogleSignInAccount, driveFileId: String): Result<RestoreSummary> = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.cacheDir, "temp_drive_download.db")
            if (tempFile.exists()) tempFile.delete()

            val credential = GoogleAccountCredential.usingOAuth2(
                context,
                Collections.singleton(DriveScopes.DRIVE_FILE)
            ).apply {
                selectedAccount = account.account
            }

            val driveService = Drive.Builder(
                NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                credential
            ).setApplicationName("SaldoX").build()

            FileOutputStream(tempFile).use { output ->
                driveService.files().get(driveFileId).executeMediaAndDownloadTo(output)
            }

            val validation = validateAndPrepareBackupFile(tempFile)
            if (!validation.isValid) {
                tempFile.delete()
                return@withContext Result.failure(IllegalStateException(validation.errorMessage ?: "Respaldo no válido"))
            }

            AppDatabase.closeInstance()

            val destinationDb = context.getDatabasePath(DB_FILE_NAME)
            val walFile = File(destinationDb.path + "-wal")
            val shmFile = File(destinationDb.path + "-shm")

            if (walFile.exists()) walFile.delete()
            if (shmFile.exists()) shmFile.delete()

            tempFile.copyTo(destinationDb, overwrite = true)
            tempFile.delete()

            AppDatabase.ensureMasterPassphrase(context)
            val db = AppDatabase.getInstance(context)

            val userProfile = db.userProfileDao().getUserProfile()
            if (userProfile != null) {
                val authManager = UserAuthManager(context)
                authManager.syncUserFromRestoredProfile(
                    name = userProfile.name,
                    email = userProfile.email,
                    passwordHash = userProfile.passwordHash,
                    passwordSalt = userProfile.passwordSalt
                )
            }

            (context.applicationContext as? PresupuestoApp)?.refreshDatabase()

            val summary = RestoreSummary(
                transactionCount = validation.transactionCount,
                message = "¡Base de datos restaurada correctamente desde Google Drive! Se encontraron ${validation.transactionCount} transacciones."
            )

            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(Exception("No fue posible restaurar la copia de seguridad desde Google Drive: ${e.localizedMessage}"))
        }
    }
}
