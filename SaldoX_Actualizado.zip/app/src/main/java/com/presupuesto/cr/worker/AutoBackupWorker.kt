package com.presupuesto.cr.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.presupuesto.cr.MainActivity
import com.presupuesto.cr.R
import com.presupuesto.cr.data.local.AppDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AutoBackupWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val isEnabled = prefs.getBoolean(KEY_AUTO_BACKUP_ENABLED, false)
            if (!isEnabled) {
                return@withContext Result.success()
            }

            // 1. Forzar checkpoint de Room para vaciar WAL en el archivo .db
            AppDatabase.checkpoint()

            // 2. Localizar archivo local de la base de datos
            val dbFile = context.getDatabasePath(DB_FILE_NAME)
            if (!dbFile.exists()) {
                return@withContext Result.failure()
            }

            // 3. Crear copia en directorio de respaldos
            val backupDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "backups").apply {
                mkdirs()
            }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val targetFile = File(backupDir, "SaldoX_AutoBackup_${timeStamp}.db")
            dbFile.copyTo(targetFile, overwrite = true)

            try {
                val docsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SaldoX")
                if (!docsDir.exists()) docsDir.mkdirs()
                targetFile.copyTo(File(docsDir, "SaldoX_Respaldo_Reciente.db"), overwrite = true)
            } catch (_: Exception) {
            }

            // 4. Actualizar fecha de último respaldo exitoso
            prefs.edit()
                .putLong(KEY_LAST_BACKUP_TIMESTAMP, System.currentTimeMillis())
                .apply()

            // 5. Mostrar notificación del sistema
            showAutoBackupNotification(targetFile.name)

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun showAutoBackupNotification(fileName: String) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Respaldos Automáticos SaldoX",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notificaciones de copias de seguridad mensuales de SaldoX"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("SaldoX - Respaldo mensual completado")
            .setContentText("Tu copia de seguridad de 30 días ($fileName) fue generada exitosamente.")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "Tu copia de seguridad de 30 días ($fileName) se ha generado con éxito y tus movimientos están protegidos."
                )
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    companion object {
        private const val PREFS_NAME = "saldox_auto_backup_prefs"
        const val KEY_AUTO_BACKUP_ENABLED = "auto_backup_30_days_enabled"
        const val KEY_LAST_BACKUP_TIMESTAMP = "last_auto_backup_timestamp"
        private const val WORK_TAG = "saldox_periodic_backup_30_days"
        private const val CHANNEL_ID = "saldox_backup_notifications"
        private const val NOTIFICATION_ID = 2001
        private const val DB_FILE_NAME = "presupuesto_cr_encrypted.db"

        fun scheduleOrCancel(context: Context, enabled: Boolean) {
            val workManager = WorkManager.getInstance(context)
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_AUTO_BACKUP_ENABLED, enabled).apply()

            if (enabled) {
                val periodicWork = PeriodicWorkRequestBuilder<AutoBackupWorker>(
                    30, TimeUnit.DAYS,
                    1, TimeUnit.DAYS
                )
                    .addTag(WORK_TAG)
                    .build()

                workManager.enqueueUniquePeriodicWork(
                    WORK_TAG,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    periodicWork
                )
            } else {
                workManager.cancelUniqueWork(WORK_TAG)
            }
        }

        fun isEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_AUTO_BACKUP_ENABLED, false)
        }

        fun getLastBackupTimestamp(context: Context): Long {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getLong(KEY_LAST_BACKUP_TIMESTAMP, 0L)
        }
    }
}
