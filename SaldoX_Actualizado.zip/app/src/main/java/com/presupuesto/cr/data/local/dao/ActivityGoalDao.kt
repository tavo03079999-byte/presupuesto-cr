package com.presupuesto.cr.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.presupuesto.cr.data.local.entity.ActivityGoalEntity
import com.presupuesto.cr.data.local.entity.ActivityGoalLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityGoalDao {

    // Metas Diarias Definidas
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: ActivityGoalEntity): Long

    @Update
    suspend fun updateGoal(goal: ActivityGoalEntity)

    @Delete
    suspend fun deleteGoal(goal: ActivityGoalEntity)

    @Query("DELETE FROM activity_goals WHERE id = :id")
    suspend fun deleteGoalById(id: Long)

    @Query("SELECT * FROM activity_goals ORDER BY id ASC")
    fun getAllGoals(): Flow<List<ActivityGoalEntity>>

    @Query("SELECT * FROM activity_goals ORDER BY id ASC")
    suspend fun getAllGoalsSync(): List<ActivityGoalEntity>

    @Query("SELECT * FROM activity_goals WHERE isActive = 1 ORDER BY id ASC")
    fun getActiveGoals(): Flow<List<ActivityGoalEntity>>

    @Query("SELECT * FROM activity_goals WHERE isActive = 1 ORDER BY id ASC")
    suspend fun getActiveGoalsSync(): List<ActivityGoalEntity>

    @Query("SELECT * FROM activity_goals WHERE id = :id")
    suspend fun getGoalById(id: Long): ActivityGoalEntity?

    // Registros Diarios / Cumplimiento de Metas
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoalLog(log: ActivityGoalLogEntity): Long

    @Query("DELETE FROM activity_goal_logs WHERE goalId = :goalId AND dateKey = :dateKey")
    suspend fun deleteLogByGoalAndDate(goalId: Long, dateKey: String)

    @Query("SELECT * FROM activity_goal_logs WHERE dateKey = :dateKey")
    fun getLogsForDate(dateKey: String): Flow<List<ActivityGoalLogEntity>>

    @Query("SELECT * FROM activity_goal_logs WHERE dateKey = :dateKey")
    suspend fun getLogsForDateSync(dateKey: String): List<ActivityGoalLogEntity>

    @Query("SELECT * FROM activity_goal_logs ORDER BY dateKey DESC")
    fun getAllLogs(): Flow<List<ActivityGoalLogEntity>>

    @Query("SELECT * FROM activity_goal_logs ORDER BY dateKey DESC")
    suspend fun getAllLogsSync(): List<ActivityGoalLogEntity>

    @Query("SELECT * FROM activity_goal_logs WHERE dateKey BETWEEN :startDateKey AND :endDateKey ORDER BY dateKey ASC")
    fun getLogsBetweenDates(startDateKey: String, endDateKey: String): Flow<List<ActivityGoalLogEntity>>

    @Query("SELECT * FROM activity_goal_logs WHERE dateKey BETWEEN :startDateKey AND :endDateKey ORDER BY dateKey ASC")
    suspend fun getLogsBetweenDatesSync(startDateKey: String, endDateKey: String): List<ActivityGoalLogEntity>
}
