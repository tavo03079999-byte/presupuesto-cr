package com.presupuesto.cr.ui.activities

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.presupuesto.cr.data.local.entity.ActivityLogEntity
import com.presupuesto.cr.data.repository.FinanceRepository
import com.presupuesto.cr.domain.usecase.ExportActivityPdfUseCase
import com.presupuesto.cr.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ActivitiesViewModel(
    private val repository: FinanceRepository,
    private val exportActivityPdfUseCase: ExportActivityPdfUseCase
) : ViewModel() {

    val allActivities: StateFlow<List<ActivityLogEntity>> = repository.getAllActivityLogs()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val distinctActivityNames: StateFlow<List<String>> = repository.getDistinctActivityNames()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _selectedActivityFilter = MutableStateFlow<String?>(null)
    val selectedActivityFilter: StateFlow<String?> = _selectedActivityFilter.asStateFlow()

    private val _startDateFilter = MutableStateFlow<Long?>(null)
    val startDateFilter: StateFlow<Long?> = _startDateFilter.asStateFlow()

    private val _endDateFilter = MutableStateFlow<Long?>(null)
    val endDateFilter: StateFlow<Long?> = _endDateFilter.asStateFlow()

    private val _isExportingPdf = MutableStateFlow(false)
    val isExportingPdf: StateFlow<Boolean> = _isExportingPdf.asStateFlow()

    private val _exportedPdfFile = MutableStateFlow<File?>(null)
    val exportedPdfFile: StateFlow<File?> = _exportedPdfFile.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Lista combinada y filtrada
    val filteredActivities: StateFlow<List<ActivityLogEntity>> = combine(
        allActivities,
        _selectedActivityFilter,
        _startDateFilter,
        _endDateFilter
    ) { list, filterName, start, end ->
        list.filter { item ->
            val matchesName = filterName.isNullOrBlank() || item.activityName.equals(filterName, ignoreCase = true)
            val matchesStart = start == null || item.date >= start
            val matchesEnd = end == null || item.date <= end
            matchesName && matchesStart && matchesEnd
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Estadísticas
    val totalMinutesAll: StateFlow<Int> = allActivities.combine(filteredActivities) { _, filtered ->
        filtered.sumOf { it.durationMinutes }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val minutesByActivity: StateFlow<Map<String, Int>> = filteredActivities.combine(_selectedActivityFilter) { list, _ ->
        val map = mutableMapOf<String, Int>()
        for (item in list) {
            val key = item.activityName.trim().replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            map[key] = (map[key] ?: 0) + item.durationMinutes
        }
        map
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyMap()
    )

    val activitiesThisMonthCount: StateFlow<Int> = allActivities.combine(filteredActivities) { all, _ ->
        val (startMonth, endMonth) = DateUtils.getCurrentMonthBounds()
        all.count { it.date in startMonth..endMonth }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    fun addActivity(
        name: String,
        durationMinutes: Int,
        date: Long,
        notes: String = "",
        onSuccess: () -> Unit = {}
    ) {
        val trimmedName = name.trim()
        if (trimmedName.isBlank()) {
            _errorMessage.value = "Ingresa el nombre de la actividad."
            return
        }
        if (durationMinutes <= 0) {
            _errorMessage.value = "La duración debe ser mayor a 0 minutos."
            return
        }

        viewModelScope.launch {
            try {
                repository.insertActivityLog(
                    ActivityLogEntity(
                        activityName = trimmedName,
                        durationMinutes = durationMinutes,
                        date = date,
                        notes = notes.trim()
                    )
                )
                _errorMessage.value = null
                onSuccess()
            } catch (e: Exception) {
                _errorMessage.value = "Error al guardar: ${e.localizedMessage}"
            }
        }
    }

    fun deleteActivity(activityLog: ActivityLogEntity) {
        viewModelScope.launch {
            try {
                repository.deleteActivityLog(activityLog)
            } catch (e: Exception) {
                _errorMessage.value = "Error al eliminar: ${e.localizedMessage}"
            }
        }
    }

    fun setActivityFilter(name: String?) {
        _selectedActivityFilter.value = if (name.isNullOrBlank() || name == "Todas") null else name
    }

    fun setDateFilter(start: Long?, end: Long?) {
        _startDateFilter.value = start
        _endDateFilter.value = end
    }

    fun setDateFilterCurrentMonth() {
        val (start, end) = DateUtils.getCurrentMonthBounds()
        _startDateFilter.value = start
        _endDateFilter.value = end
    }

    fun clearFilters() {
        _selectedActivityFilter.value = null
        _startDateFilter.value = null
        _endDateFilter.value = null
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun exportPdf() {
        if (_isExportingPdf.value) return
        _isExportingPdf.value = true

        viewModelScope.launch {
            try {
                val list = filteredActivities.value
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val start = _startDateFilter.value
                val end = _endDateFilter.value

                val dateRangeLabel = if (start != null && end != null) {
                    "${dateFormat.format(Date(start))} al ${dateFormat.format(Date(end))}"
                } else if (start != null) {
                    "Desde ${dateFormat.format(Date(start))}"
                } else if (end != null) {
                    "Hasta ${dateFormat.format(Date(end))}"
                } else {
                    null
                }

                val pdfFile = exportActivityPdfUseCase.exportPdf(
                    activities = list,
                    dateRangeLabel = dateRangeLabel,
                    activityFilterLabel = _selectedActivityFilter.value
                )
                _exportedPdfFile.value = pdfFile
            } catch (e: Exception) {
                _errorMessage.value = "Error al generar PDF: ${e.localizedMessage}"
            } finally {
                _isExportingPdf.value = false
            }
        }
    }

    fun clearExportedPdfFile() {
        _exportedPdfFile.value = null
    }
}
