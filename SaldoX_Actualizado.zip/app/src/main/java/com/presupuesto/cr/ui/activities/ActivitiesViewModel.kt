package com.presupuesto.cr.ui.activities

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.presupuesto.cr.data.local.entity.ActivityGoalEntity
import com.presupuesto.cr.data.local.entity.ActivityGoalLogEntity
import com.presupuesto.cr.data.local.entity.ActivityLogEntity
import com.presupuesto.cr.data.repository.FinanceRepository
import com.presupuesto.cr.domain.usecase.ExportActivityPdfUseCase
import com.presupuesto.cr.util.DateUtils
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class GoalProgress(
    val completedCount: Int = 0,
    val totalActive: Int = 0,
    val percentage: Int = 0
)

data class StreakData(
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val days100PercentMonth: Int = 0,
    val avgComplianceMonth: Int = 0
)

data class DayCompliance(
    val dateKey: String,
    val dayOfMonth: Int,
    val totalGoals: Int,
    val completedGoals: Int,
    val percentage: Int
)

data class CyberLevelInfo(
    val currentXp: Int = 0,
    val level: Int = 1,
    val title: String = "Iniciado Kinetic",
    val currentLevelBaseXp: Int = 0,
    val nextLevelTargetXp: Int = 500,
    val progressInLevel: Float = 0f,
    val xpRemaining: Int = 500
)

class ActivitiesViewModel(
    private val repository: FinanceRepository,
    private val exportActivityPdfUseCase: ExportActivityPdfUseCase
) : ViewModel() {

    private val dateFormatKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    val todayDateKey: String
        get() = dateFormatKey.format(Date())

    // 1. Actividades Registradas
    val allActivities: StateFlow<List<ActivityLogEntity>> = repository.getAllActivityLogs()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val distinctActivityNames: StateFlow<List<String>> = repository.getDistinctActivityNames()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _selectedActivityFilter = MutableStateFlow<String?>(null)
    val selectedActivityFilter: StateFlow<String?> = _selectedActivityFilter.asStateFlow()

    private val _startDateFilter = MutableStateFlow<Long?>(null)
    val startDateFilter: StateFlow<Long?> = _startDateFilter.asStateFlow()

    private val _endDateFilter = MutableStateFlow<Long?>(null)
    val endDateFilter: StateFlow<Long?> = _endDateFilter.asStateFlow()

    private val _isExportingPdf = MutableStateFlow(false)
    val isExportingPdf: StateFlow<Boolean> = _isExportingPdf.asStateFlow()

    private val _exportedPdfFile = MutableStateFlow<File?>(null)
    val exportedPdfFile: StateFlow<File?> = _exportedPdfFile.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Lista combinada y filtrada
    val filteredActivities: StateFlow<List<ActivityLogEntity>> = combine(
        allActivities,
        _selectedActivityFilter,
        _startDateFilter,
        _endDateFilter
    ) { list, filterName, start, end ->
        list.filter { item ->
            val matchesName = filterName.isNullOrBlank() || item.activityName.equals(filterName, ignoreCase = true)
            val matchesStart = start == null || item.date >= start
            val matchesEnd = end == null || item.date <= end
            matchesName && matchesStart && matchesEnd
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Estadísticas generales y por actividad
    val totalMinutesAll: StateFlow<Int> = filteredActivities.combine(allActivities) { filtered, _ ->
        filtered.sumOf { it.durationMinutes }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val minutesByActivity: StateFlow<Map<String, Int>> = filteredActivities.combine(_selectedActivityFilter) { list, _ ->
        val map = mutableMapOf<String, Int>()
        for (item in list) {
            val key = item.activityName.trim().replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            map[key] = (map[key] ?: 0) + item.durationMinutes
        }
        map
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyMap()
    )

    val activitiesThisMonthCount: StateFlow<Int> = allActivities.combine(filteredActivities) { all, _ ->
        val (startMonth, endMonth) = DateUtils.getCurrentMonthBounds()
        all.count { it.date in startMonth..endMonth }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    // 2. Metas de Actividades Diarias (Daily Goals)
    val allGoals: StateFlow<List<ActivityGoalEntity>> = repository.getAllGoals()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeGoals: StateFlow<List<ActivityGoalEntity>> = repository.getActiveGoals()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allGoalLogs: StateFlow<List<ActivityGoalLogEntity>> = repository.getAllGoalLogs()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Checklist de hoy
    val todayCompletedGoalIds: StateFlow<Set<Long>> = allGoalLogs.combine(activeGoals) { logs, _ ->
        val today = todayDateKey
        logs.filter { it.dateKey == today && it.isCompleted }.map { it.goalId }.toSet()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptySet()
    )

    // Progreso del checklist diario
    val todayProgress: StateFlow<GoalProgress> = combine(activeGoals, todayCompletedGoalIds) { active, completedIds ->
        val total = active.size
        if (total == 0) {
            GoalProgress(0, 0, 0)
        } else {
            val completed = active.count { completedIds.contains(it.id) }
            val percent = ((completed.toFloat() / total.toFloat()) * 100f).toInt()
            GoalProgress(completed, total, percent)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = GoalProgress()
    )

    // Estadísticas de Rachas y Cumplimiento Mensual
    val streakStats: StateFlow<StreakData> = combine(allGoals, allGoalLogs) { goals, logs ->
        calculateStreaks(goals, logs)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = StreakData()
    )

    // Mapa de cumplimiento mensual para el calendario
    val monthComplianceList: StateFlow<List<DayCompliance>> = combine(allGoals, allGoalLogs) { goals, logs ->
        calculateMonthCompliance(goals, logs)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // 3. Sistema de Niveles Cyber Kinetic (XP)
    val levelInfo: StateFlow<CyberLevelInfo> = combine(allActivities, allGoalLogs, streakStats) { activities, goalLogs, stats ->
        val activityXp = activities.sumOf { it.durationMinutes * 10 }
        val goalsXp = goalLogs.count { it.isCompleted } * 50
        val streakBonusXp = stats.days100PercentMonth * 150
        val totalXp = activityXp + goalsXp + streakBonusXp
        calculateLevelInfo(totalXp)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CyberLevelInfo()
    )

    // 4. Modo Cronómetro en Vivo (Live Stopwatch)
    private val _stopwatchSeconds = MutableStateFlow(0L)
    val stopwatchSeconds: StateFlow<Long> = _stopwatchSeconds.asStateFlow()

    private val _isStopwatchRunning = MutableStateFlow(false)
    val isStopwatchRunning: StateFlow<Boolean> = _isStopwatchRunning.asStateFlow()

    private var stopwatchJob: Job? = null

    fun startStopwatch() {
        if (_isStopwatchRunning.value) return
        _isStopwatchRunning.value = true
        stopwatchJob = viewModelScope.launch {
            while (isActive && _isStopwatchRunning.value) {
                delay(1000L)
                _stopwatchSeconds.value += 1L
            }
        }
    }

    fun pauseStopwatch() {
        _isStopwatchRunning.value = false
        stopwatchJob?.cancel()
        stopwatchJob = null
    }

    fun resetStopwatch() {
        pauseStopwatch()
        _stopwatchSeconds.value = 0L
    }

    fun saveStopwatchAsActivity(
        activityName: String,
        notes: String = "",
        onSuccess: () -> Unit = {}
    ) {
        val totalSecs = _stopwatchSeconds.value
        val durationMinutes = kotlin.math.max(1, kotlin.math.round(totalSecs / 60.0).toInt())
        val nameToSave = activityName.trim().ifBlank { "Entrenamiento Kinetic" }

        addActivity(
            name = nameToSave,
            durationMinutes = durationMinutes,
            date = System.currentTimeMillis(),
            notes = notes.trim(),
            onSuccess = {
                resetStopwatch()
                onSuccess()
            }
        )
    }

    // Offset para el Heatmap (día de la semana en que inicia el mes: 0 = Lunes, 6 = Domingo)
    val currentMonthFirstDayOffset: Int
        get() {
            val cal = Calendar.getInstance()
            cal.set(Calendar.DAY_OF_MONTH, 1)
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            return when (dow) {
                Calendar.MONDAY -> 0
                Calendar.TUESDAY -> 1
                Calendar.WEDNESDAY -> 2
                Calendar.THURSDAY -> 3
                Calendar.FRIDAY -> 4
                Calendar.SATURDAY -> 5
                Calendar.SUNDAY -> 6
                else -> 0
            }
        }

    // Acciones de Actividades (CRUD)
    fun addActivity(
        name: String,
        durationMinutes: Int,
        date: Long,
        notes: String = "",
        onSuccess: () -> Unit = {}
    ) {
        val trimmedName = name.trim()
        if (trimmedName.isBlank()) {
            _errorMessage.value = "Ingresa el nombre de la actividad."
            return
        }
        if (durationMinutes <= 0) {
            _errorMessage.value = "La duración debe ser mayor a 0 minutos."
            return
        }

        viewModelScope.launch {
            try {
                repository.insertActivityLog(
                    ActivityLogEntity(
                        activityName = trimmedName,
                        durationMinutes = durationMinutes,
                        date = date,
                        notes = notes.trim()
                    )
                )
                _errorMessage.value = null
                onSuccess()
            } catch (e: Exception) {
                _errorMessage.value = "Error al guardar: ${e.localizedMessage}"
            }
        }
    }

    fun updateActivity(
        id: Long,
        name: String,
        durationMinutes: Int,
        date: Long,
        notes: String = "",
        onSuccess: () -> Unit = {}
    ) {
        val trimmedName = name.trim()
        if (trimmedName.isBlank()) {
            _errorMessage.value = "Ingresa el nombre de la actividad."
            return
        }
        if (durationMinutes <= 0) {
            _errorMessage.value = "La duración debe ser mayor a 0 minutos."
            return
        }

        viewModelScope.launch {
            try {
                repository.updateActivityLog(
                    ActivityLogEntity(
                        id = id,
                        activityName = trimmedName,
                        durationMinutes = durationMinutes,
                        date = date,
                        notes = notes.trim(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
                _errorMessage.value = null
                onSuccess()
            } catch (e: Exception) {
                _errorMessage.value = "Error al actualizar: ${e.localizedMessage}"
            }
        }
    }

    fun deleteActivity(activityLog: ActivityLogEntity) {
        viewModelScope.launch {
            try {
                repository.deleteActivityLog(activityLog)
            } catch (e: Exception) {
                _errorMessage.value = "Error al eliminar: ${e.localizedMessage}"
            }
        }
    }

    // Acciones de Metas Diarias (CRUD)
    fun addGoal(name: String, targetMinutes: Int, onSuccess: () -> Unit = {}) {
        val trimmedName = name.trim()
        if (trimmedName.isBlank()) {
            _errorMessage.value = "Ingresa el nombre de la meta."
            return
        }
        viewModelScope.launch {
            try {
                repository.insertGoal(
                    ActivityGoalEntity(
                        name = trimmedName,
                        targetMinutes = targetMinutes.coerceAtLeast(0),
                        isActive = true
                    )
                )
                _errorMessage.value = null
                onSuccess()
            } catch (e: Exception) {
                _errorMessage.value = "Error al agregar meta: ${e.localizedMessage}"
            }
        }
    }

    fun updateGoal(id: Long, name: String, targetMinutes: Int, isActive: Boolean, onSuccess: () -> Unit = {}) {
        val trimmedName = name.trim()
        if (trimmedName.isBlank()) {
            _errorMessage.value = "Ingresa el nombre de la meta."
            return
        }
        viewModelScope.launch {
            try {
                repository.updateGoal(
                    ActivityGoalEntity(
                        id = id,
                        name = trimmedName,
                        targetMinutes = targetMinutes.coerceAtLeast(0),
                        isActive = isActive,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                _errorMessage.value = null
                onSuccess()
            } catch (e: Exception) {
                _errorMessage.value = "Error al actualizar meta: ${e.localizedMessage}"
            }
        }
    }

    fun toggleGoalActive(goal: ActivityGoalEntity) {
        viewModelScope.launch {
            try {
                repository.updateGoal(goal.copy(isActive = !goal.isActive, updatedAt = System.currentTimeMillis()))
            } catch (e: Exception) {
                _errorMessage.value = "Error al cambiar estado de la meta: ${e.localizedMessage}"
            }
        }
    }

    fun deleteGoal(goal: ActivityGoalEntity) {
        viewModelScope.launch {
            try {
                repository.deleteGoal(goal)
            } catch (e: Exception) {
                _errorMessage.value = "Error al eliminar meta: ${e.localizedMessage}"
            }
        }
    }

    fun toggleGoalCompletionToday(goalId: Long, isCompleted: Boolean, actualMinutes: Int) {
        viewModelScope.launch {
            try {
                repository.toggleGoalCompletion(
                    goalId = goalId,
                    dateKey = todayDateKey,
                    isCompleted = isCompleted,
                    actualMinutes = actualMinutes
                )
            } catch (e: Exception) {
                _errorMessage.value = "Error al marcar meta: ${e.localizedMessage}"
            }
        }
    }

    // Filtros
    fun setActivityFilter(name: String?) {
        _selectedActivityFilter.value = if (name.isNullOrBlank() || name == "Todas") null else name
    }

    fun setDateFilter(start: Long?, end: Long?) {
        _startDateFilter.value = start
        _endDateFilter.value = end
    }

    fun setDateFilterCurrentMonth() {
        val (start, end) = DateUtils.getCurrentMonthBounds()
        _startDateFilter.value = start
        _endDateFilter.value = end
    }

    fun clearFilters() {
        _selectedActivityFilter.value = null
        _startDateFilter.value = null
        _endDateFilter.value = null
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    // Exportación PDF con Metas
    fun exportPdf() {
        if (_isExportingPdf.value) return
        _isExportingPdf.value = true

        viewModelScope.launch {
            try {
                val list = filteredActivities.value
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val start = _startDateFilter.value
                val end = _endDateFilter.value

                val dateRangeLabel = if (start != null && end != null) {
                    "${dateFormat.format(Date(start))} al ${dateFormat.format(Date(end))}"
                } else if (start != null) {
                    "Desde ${dateFormat.format(Date(start))}"
                } else if (end != null) {
                    "Hasta ${dateFormat.format(Date(end))}"
                } else {
                    null
                }

                val currentStats = streakStats.value

                val pdfFile = exportActivityPdfUseCase.exportPdf(
                    activities = list,
                    dateRangeLabel = dateRangeLabel,
                    activityFilterLabel = _selectedActivityFilter.value,
                    goalsComplianceAvg = currentStats.avgComplianceMonth,
                    currentStreak = currentStats.currentStreak,
                    bestStreak = currentStats.bestStreak,
                    days100Percent = currentStats.days100PercentMonth
                )
                _exportedPdfFile.value = pdfFile
            } catch (e: Exception) {
                _errorMessage.value = "Error al generar PDF: ${e.localizedMessage}"
            } finally {
                _isExportingPdf.value = false
            }
        }
    }

    fun clearExportedPdfFile() {
        _exportedPdfFile.value = null
    }

    // Cálculos internos de racha e historial
    private fun calculateStreaks(goals: List<ActivityGoalEntity>, logs: List<ActivityGoalLogEntity>): StreakData {
        val activeGoals = goals.filter { it.isActive }
        val activeCount = activeGoals.size
        if (activeCount == 0) {
            return StreakData()
        }

        // Agrupar logs por dateKey
        val logsByDate = logs.groupBy { it.dateKey }

        // Calendario hacia atrás desde hoy
        val cal = Calendar.getInstance()
        var currentStreak = 0
        var bestStreak = 0
        var tempStreak = 0

        // Verificar racha actual hacia atrás
        val todayStr = dateFormatKey.format(cal.time)
        val todayLogs = logsByDate[todayStr]?.filter { it.isCompleted }?.map { it.goalId }?.toSet() ?: emptySet()
        val todayCompletedAll = todayLogs.size >= activeCount

        if (todayCompletedAll) {
            currentStreak++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        } else {
            // Si hoy todavía no está al 100%, la racha puede seguir viva desde ayer
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }

        // Días anteriores
        for (i in 0 until 180) {
            val dateStr = dateFormatKey.format(cal.time)
            val dayLogs = logsByDate[dateStr]?.filter { it.isCompleted }?.map { it.goalId }?.toSet() ?: emptySet()
            if (dayLogs.size >= activeCount) {
                currentStreak++
                cal.add(Calendar.DAY_OF_YEAR, -1)
            } else {
                break
            }
        }

        // Mejor racha histórica: ordenar días registrados
        val allDates = logsByDate.keys.sorted()
        for (dateKey in allDates) {
            val count = logsByDate[dateKey]?.filter { it.isCompleted }?.map { it.goalId }?.toSet()?.size ?: 0
            if (count >= activeCount) {
                tempStreak++
                if (tempStreak > bestStreak) bestStreak = tempStreak
            } else {
                tempStreak = 0
            }
        }
        if (currentStreak > bestStreak) bestStreak = currentStreak

        // Estadísticas del mes actual
        val monthCal = Calendar.getInstance()
        val currentMonth = monthCal.get(Calendar.MONTH)
        val currentYear = monthCal.get(Calendar.YEAR)
        val maxDayOfMonth = monthCal.get(Calendar.DAY_OF_MONTH)

        var days100 = 0
        var sumPercentage = 0

        for (d in 1..maxDayOfMonth) {
            monthCal.set(currentYear, currentMonth, d)
            val dayKey = dateFormatKey.format(monthCal.time)
            val completed = logsByDate[dayKey]?.filter { it.isCompleted }?.map { it.goalId }?.toSet()?.size ?: 0
            val percent = ((completed.toFloat() / activeCount.toFloat()) * 100f).toInt()
            if (percent >= 100) {
                days100++
            }
            sumPercentage += percent
        }

        val avgCompliance = if (maxDayOfMonth > 0) sumPercentage / maxDayOfMonth else 0

        return StreakData(
            currentStreak = currentStreak,
            bestStreak = bestStreak,
            days100PercentMonth = days100,
            avgComplianceMonth = avgCompliance
        )
    }

    private fun calculateMonthCompliance(
        goals: List<ActivityGoalEntity>,
        logs: List<ActivityGoalLogEntity>
    ): List<DayCompliance> {
        val activeCount = goals.count { it.isActive }
        val logsByDate = logs.groupBy { it.dateKey }

        val cal = Calendar.getInstance()
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val currentMonth = cal.get(Calendar.MONTH)
        val currentYear = cal.get(Calendar.YEAR)

        val list = mutableListOf<DayCompliance>()
        val tempCal = Calendar.getInstance()

        for (day in 1..daysInMonth) {
            tempCal.set(currentYear, currentMonth, day)
            val dateKey = dateFormatKey.format(tempCal.time)
            val completedCount = logsByDate[dateKey]?.filter { it.isCompleted }?.map { it.goalId }?.toSet()?.size ?: 0
            val percentage = if (activeCount > 0) ((completedCount.toFloat() / activeCount.toFloat()) * 100f).toInt() else 0

            list.add(
                DayCompliance(
                    dateKey = dateKey,
                    dayOfMonth = day,
                    totalGoals = activeCount,
                    completedGoals = completedCount,
                    percentage = percentage
                )
            )
        }
        return list
    }

    private fun calculateLevelInfo(totalXp: Int): CyberLevelInfo {
        val thresholds = listOf(
            Pair(1, "Iniciado Kinetic") to 0,
            Pair(2, "Runner Cuántico") to 500,
            Pair(3, "Operador Cibernético") to 1200,
            Pair(4, "Titán Kinetic") to 2200,
            Pair(5, "Maestro Cyber") to 3500,
            Pair(6, "Ciber Centinela") to 5200,
            Pair(7, "Vanguardia Cuántica") to 7500,
            Pair(8, "Apex Kinetic") to 11000
        )
        var currentLvl = 1
        var currentTitle = "Iniciado Kinetic"
        var baseXp = 0
        var nextXp = 500

        for (i in thresholds.indices) {
            val (lvlTitle, xpReq) = thresholds[i]
            if (totalXp >= xpReq) {
                currentLvl = lvlTitle.first
                currentTitle = lvlTitle.second
                baseXp = xpReq
                nextXp = if (i + 1 < thresholds.size) thresholds[i + 1].second else xpReq + 5000
            } else {
                break
            }
        }

        val xpInLevel = (totalXp - baseXp).coerceAtLeast(0)
        val span = (nextXp - baseXp).coerceAtLeast(1)
        val progress = (xpInLevel.toFloat() / span.toFloat()).coerceIn(0f, 1f)
        val remaining = (nextXp - totalXp).coerceAtLeast(0)

        return CyberLevelInfo(
            currentXp = totalXp,
            level = currentLvl,
            title = currentTitle,
            currentLevelBaseXp = baseXp,
            nextLevelTargetXp = nextXp,
            progressInLevel = progress,
            xpRemaining = remaining
        )
    }
}
