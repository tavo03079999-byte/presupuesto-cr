package com.presupuesto.cr.ui.auth

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.presupuesto.cr.BuildConfig
import com.presupuesto.cr.R
import com.presupuesto.cr.data.repository.FinanceRepository
import com.presupuesto.cr.domain.usecase.GoogleDriveBackupUseCase
import com.presupuesto.cr.ui.theme.BackgroundDark
import com.presupuesto.cr.ui.theme.CyanNeon
import com.presupuesto.cr.ui.theme.EmeraldNeon
import com.presupuesto.cr.ui.theme.ExpenseRed
import com.presupuesto.cr.ui.theme.IncomeGreen
import com.presupuesto.cr.ui.theme.SurfaceDark
import com.presupuesto.cr.ui.theme.ThemeBlue
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    authManager: UserAuthManager,
    googleDriveBackupUseCase: GoogleDriveBackupUseCase,
    repository: FinanceRepository,
    isBiometricAvailable: Boolean,
    onAuthSuccess: () -> Unit,
    onBiometricRequested: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isRegisterMode by remember { mutableStateOf(false) }

    // Campos formulario
    var nameInput by remember { mutableStateOf(authManager.getRegisteredName() ?: "") }
    var emailInput by remember {
        mutableStateOf(authManager.getRegisteredEmail() ?: BuildConfig.LINKED_USER_EMAIL)
    }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isCloudSyncing by remember { mutableStateOf(false) }
    var cloudSyncStatusText by remember { mutableStateOf<String?>(null) }
    var pendingAction by remember { mutableStateOf<String?>(null) } // "LOGIN" o "REGISTER"
    var showCloudRegisterDialog by remember { mutableStateOf(false) }

    // Diálogo Confirmación de Correo con Código de 6 Dígitos
    var showVerifyEmailDialog by remember { mutableStateOf(false) }
    var verificationCodeInput by remember { mutableStateOf("") }
    var verificationError by remember { mutableStateOf<String?>(null) }

    // Diálogo Olvidó Contraseña
    var showForgotDialog by remember { mutableStateOf(false) }
    var forgotEmailInput by remember { mutableStateOf("") }
    var forgotTempResult by remember { mutableStateOf<String?>(null) }
    var forgotError by remember { mutableStateOf<String?>(null) }

    // Diálogo Cambio obligatorio de contraseña (al ingresar con contraseña temporal)
    var showForceChangeDialog by remember { mutableStateOf(false) }
    var forceNewPassword by remember { mutableStateOf("") }
    var forceConfirmPassword by remember { mutableStateOf("") }
    var forcePasswordVisible by remember { mutableStateOf(false) }
    var forceError by remember { mutableStateOf<String?>(null) }

    var isRestoringBackup by remember { mutableStateOf(false) }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            if (pendingAction == "LOGIN") {
                isCloudSyncing = true
                cloudSyncStatusText = "Sincronizando cuenta y datos desde Google Drive..."
                coroutineScope.launch {
                    val res = googleDriveBackupUseCase.loginAndSyncFromCloud(
                        account = account,
                        emailInput = emailInput,
                        passwordInput = passwordInput,
                        repository = repository,
                        authManager = authManager
                    )
                    isCloudSyncing = false
                    cloudSyncStatusText = null
                    res.fold(
                        onSuccess = { summary ->
                            Toast.makeText(context, summary.message, Toast.LENGTH_LONG).show()
                            onAuthSuccess()
                        },
                        onFailure = { ex ->
                            errorMessage = ex.message ?: "Error al sincronizar con Google Drive."
                        }
                    )
                }
            } else if (pendingAction == "REGISTER") {
                isCloudSyncing = true
                cloudSyncStatusText = "Guardando cuenta en Google Drive..."
                coroutineScope.launch {
                    val hash = authManager.getPasswordHash() ?: ""
                    val salt = authManager.getPasswordSalt() ?: ""
                    if (hash.isNotBlank() && salt.isNotBlank()) {
                        googleDriveBackupUseCase.uploadCloudVault(
                            account = account,
                            name = nameInput.ifBlank { "Usuario" },
                            email = emailInput.trim(),
                            passwordHash = hash,
                            passwordSalt = salt
                        )
                    }
                    googleDriveBackupUseCase.uploadDatabaseBackup(account)
                    isCloudSyncing = false
                    cloudSyncStatusText = null
                    Toast.makeText(context, "¡Cuenta sincronizada en Google Drive con éxito!", Toast.LENGTH_LONG).show()
                    onAuthSuccess()
                }
            }
        } catch (e: ApiException) {
            isCloudSyncing = false
            cloudSyncStatusText = null
            val msg = when (e.statusCode) {
                10 -> "Google Sign-In requiere vincular SHA-1 en Google Cloud Console."
                12500 -> "Inicio de sesión en Google cancelado o no completado."
                else -> "Error de cuenta Google (${e.statusCode}): ${e.localizedMessage}"
            }
            errorMessage = msg
            if (pendingAction == "REGISTER") {
                Toast.makeText(context, "Cuenta creada en este dispositivo.", Toast.LENGTH_SHORT).show()
                onAuthSuccess()
            }
        } catch (e: Exception) {
            isCloudSyncing = false
            cloudSyncStatusText = null
            errorMessage = "Error con Google: ${e.localizedMessage}"
            if (pendingAction == "REGISTER") {
                onAuthSuccess()
            }
        } finally {
            pendingAction = null
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            isRestoringBackup = true
            coroutineScope.launch {
                val backupUseCase = GoogleDriveBackupUseCase(context)
                val result = backupUseCase.restoreDatabaseFromUri(uri)
                isRestoringBackup = false
                result.fold(
                    onSuccess = { summary ->
                        Toast.makeText(context, summary.message, Toast.LENGTH_LONG).show()
                        if (authManager.isUserRegistered()) {
                            isRegisterMode = false
                            emailInput = authManager.getRegisteredEmail() ?: ""
                            nameInput = authManager.getRegisteredName() ?: ""
                            passwordInput = ""
                            errorMessage = null
                        }
                    },
                    onFailure = { ex ->
                        errorMessage = "Error al restaurar: ${ex.message}"
                    }
                )
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(BackgroundDark, SurfaceDark)
                )
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Logo SaldoX
            Image(
                painter = painterResource(id = R.drawable.saldox_logo),
                contentDescription = "Logo SaldoX",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(92.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .border(1.5.dp, CyanNeon.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Título SaldoX
            Text(
                text = buildAnnotatedString {
                    withStyle(
                        style = SpanStyle(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    ) {
                        append("Saldo")
                    }
                    withStyle(
                        style = SpanStyle(
                            color = Color(0xFF00E5B8),
                            fontWeight = FontWeight.ExtraBold
                        )
                    ) {
                        append("X")
                    }
                },
                fontSize = 30.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "Tu dinero, en perspectiva",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Píldoras de selector: Iniciar Sesión / Registrarse
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            onClick = {
                                isRegisterMode = false
                                errorMessage = null
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = if (!isRegisterMode) ThemeBlue.copy(alpha = 0.22f) else Color.Transparent,
                            border = if (!isRegisterMode) BorderStroke(1.dp, ThemeBlue) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Iniciar Sesión",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (!isRegisterMode) CyanNeon else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            onClick = {
                                isRegisterMode = true
                                errorMessage = null
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isRegisterMode) EmeraldNeon.copy(alpha = 0.22f) else Color.Transparent,
                            border = if (isRegisterMode) BorderStroke(1.dp, EmeraldNeon) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Registrarse",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isRegisterMode) EmeraldNeon else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    if (isRegisterMode) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Nombre completo") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = ThemeBlue)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Correo electrónico") },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = ThemeBlue)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = { Text("Contraseña") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (passwordVisible) "Ocultar" else "Mostrar",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (isRegisterMode) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = confirmPasswordInput,
                            onValueChange = { confirmPasswordInput = it },
                            label = { Text("Confirmar contraseña") },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (!isRegisterMode) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "¿Olvidaste tu contraseña?",
                                color = ThemeBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier
                                    .clickable {
                                        forgotEmailInput = emailInput.ifBlank {
                                            authManager.getRegisteredEmail() ?: ""
                                        }
                                        forgotError = null
                                        forgotTempResult = null
                                        showForgotDialog = true
                                    }
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }

                    errorMessage?.let { errorText ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorText,
                            color = ExpenseRed,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Botón Principal
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(ThemeBlue, CyanNeon, EmeraldNeon)
                                ),
                                shape = CircleShape
                            )
                            .clickable(enabled = !isCloudSyncing) {
                                errorMessage = null
                                if (isRegisterMode) {
                                    if (nameInput.isBlank()) {
                                        errorMessage = "Por favor ingresa tu nombre completo."
                                        return@clickable
                                    }
                                    if (emailInput.isBlank() || !emailInput.contains("@") || !emailInput.contains(".")) {
                                        errorMessage = "Por favor ingresa un correo electrónico válido."
                                        return@clickable
                                    }
                                    if (passwordInput.length < 6) {
                                        errorMessage = "La contraseña debe tener al menos 6 caracteres."
                                        return@clickable
                                    }
                                    if (passwordInput != confirmPasswordInput) {
                                        errorMessage = "Las contraseñas no coinciden."
                                        return@clickable
                                    }

                                    val initResult = authManager.initiateEmailVerification(
                                        name = nameInput,
                                        email = emailInput,
                                        password = passwordInput
                                    )

                                    initResult.fold(
                                        onSuccess = {
                                            verificationCodeInput = ""
                                            verificationError = null
                                            showVerifyEmailDialog = true
                                            Toast.makeText(context, "Código de 6 dígitos enviado a tu correo.", Toast.LENGTH_LONG).show()
                                        },
                                        onFailure = { ex ->
                                            errorMessage = ex.message ?: "Error al enviar el código de confirmación."
                                        }
                                    )
                                } else {
                                    if (emailInput.isBlank()) {
                                        errorMessage = "Por favor ingresa tu correo electrónico."
                                        return@clickable
                                    }
                                    if (passwordInput.isBlank()) {
                                        errorMessage = "Por favor ingresa tu contraseña."
                                        return@clickable
                                    }

                                    when (authManager.login(emailInput, passwordInput)) {
                                        LoginStatus.SUCCESS -> {
                                            onAuthSuccess()
                                        }
                                        LoginStatus.SUCCESS_WITH_TEMP_PASSWORD -> {
                                            showForceChangeDialog = true
                                        }
                                        LoginStatus.INVALID_CREDENTIALS -> {
                                            val account = googleDriveBackupUseCase.getLastSignedInAccount()
                                            if (account != null) {
                                                isCloudSyncing = true
                                                cloudSyncStatusText = "Verificando credenciales en Google Drive..."
                                                coroutineScope.launch {
                                                    val res = googleDriveBackupUseCase.loginAndSyncFromCloud(
                                                        account = account,
                                                        emailInput = emailInput,
                                                        passwordInput = passwordInput,
                                                        repository = repository,
                                                        authManager = authManager
                                                    )
                                                    isCloudSyncing = false
                                                    cloudSyncStatusText = null
                                                    res.fold(
                                                        onSuccess = { summary ->
                                                            Toast.makeText(context, summary.message, Toast.LENGTH_LONG).show()
                                                            onAuthSuccess()
                                                        },
                                                        onFailure = {
                                                            errorMessage = "Correo o contraseña incorrectos."
                                                        }
                                                    )
                                                }
                                            } else {
                                                errorMessage = "Correo o contraseña incorrectos."
                                            }
                                        }
                                        LoginStatus.TEMP_PASSWORD_EXPIRED -> {
                                            errorMessage = "La contraseña temporal ha expirado. Solicita una nueva."
                                        }
                                        LoginStatus.USER_NOT_FOUND -> {
                                            val account = googleDriveBackupUseCase.getLastSignedInAccount()
                                            if (account != null) {
                                                isCloudSyncing = true
                                                cloudSyncStatusText = "Sincronizando cuenta y datos desde Google Drive..."
                                                coroutineScope.launch {
                                                    val res = googleDriveBackupUseCase.loginAndSyncFromCloud(
                                                        account = account,
                                                        emailInput = emailInput,
                                                        passwordInput = passwordInput,
                                                        repository = repository,
                                                        authManager = authManager
                                                    )
                                                    isCloudSyncing = false
                                                    cloudSyncStatusText = null
                                                    res.fold(
                                                        onSuccess = { summary ->
                                                            Toast.makeText(context, summary.message, Toast.LENGTH_LONG).show()
                                                            onAuthSuccess()
                                                        },
                                                        onFailure = { ex ->
                                                            errorMessage = ex.message ?: "No se encontró cuenta en Google Drive con este correo."
                                                        }
                                                    )
                                                }
                                            } else {
                                                pendingAction = "LOGIN"
                                                val signInIntent = googleDriveBackupUseCase.getGoogleSignInClient().signInIntent
                                                googleSignInLauncher.launch(signInIntent)
                                            }
                                        }
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCloudSyncing) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = cloudSyncStatusText ?: "Sincronizando...",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        } else {
                            Text(
                                text = if (isRegisterMode) "Crear Cuenta" else "Iniciar Sesión",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }

                    // Botón para sincronizar directamente desde Google Drive (multi-dispositivo)
                    if (!isRegisterMode) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                errorMessage = null
                                if (emailInput.isBlank() || passwordInput.isBlank()) {
                                    errorMessage = "Ingresa tu correo y contraseña arriba para validar tu identidad al sincronizar desde Google Drive."
                                    return@OutlinedButton
                                }
                                val account = googleDriveBackupUseCase.getLastSignedInAccount()
                                if (account != null) {
                                    isCloudSyncing = true
                                    cloudSyncStatusText = "Sincronizando cuenta y transacciones desde Drive..."
                                    coroutineScope.launch {
                                        val res = googleDriveBackupUseCase.loginAndSyncFromCloud(
                                            account = account,
                                            emailInput = emailInput,
                                            passwordInput = passwordInput,
                                            repository = repository,
                                            authManager = authManager
                                        )
                                        isCloudSyncing = false
                                        cloudSyncStatusText = null
                                        res.fold(
                                            onSuccess = { summary ->
                                                Toast.makeText(context, summary.message, Toast.LENGTH_LONG).show()
                                                onAuthSuccess()
                                            },
                                            onFailure = { ex ->
                                                errorMessage = ex.message ?: "No se encontró cuenta en Google Drive."
                                            }
                                        )
                                    }
                                } else {
                                    pendingAction = "LOGIN"
                                    val signInIntent = googleDriveBackupUseCase.getGoogleSignInClient().signInIntent
                                    googleSignInLauncher.launch(signInIntent)
                                }
                            },
                            enabled = !isCloudSyncing,
                            shape = CircleShape,
                            border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sincronizar cuenta desde Google Drive",
                                color = CyanNeon,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.5.sp
                            )
                        }
                    }

                    // Botón Biometría (si está disponible y en modo login)
                    if (!isRegisterMode && isBiometricAvailable) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = onBiometricRequested,
                            shape = CircleShape,
                            border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Acceder con Huella / Rostro",
                                color = CyanNeon,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Botón para restaurar copia de seguridad si reinstaló la app
                    TextButton(
                        onClick = {
                            restoreLauncher.launch(arrayOf("*/*"))
                        },
                        enabled = !isRestoringBackup && !isCloudSyncing,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRestoringBackup) "Restaurando respaldo..." else "¿Tienes un respaldo de SaldoX? Restaurar datos",
                            color = CyanNeon,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Diálogo post-registro para vincular Google Drive
    if (showCloudRegisterDialog) {
        AlertDialog(
            onDismissRequest = {
                showCloudRegisterDialog = false
                onAuthSuccess()
            },
            title = {
                Text("¡Cuenta Creada Exitosamente!", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Para poder ingresar a SaldoX desde cualquier otro teléfono con tu correo y contraseña, y no perder tus movimientos si desinstalas la app, vincula tu cuenta de Google Drive ahora.",
                    fontSize = 13.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCloudRegisterDialog = false
                        pendingAction = "REGISTER"
                        val signInIntent = googleDriveBackupUseCase.getGoogleSignInClient().signInIntent
                        googleSignInLauncher.launch(signInIntent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Vincular Google Drive", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showCloudRegisterDialog = false
                        Toast.makeText(context, "Cuenta guardada localmente.", Toast.LENGTH_SHORT).show()
                        onAuthSuccess()
                    }
                ) {
                    Text("Continuar sin Nube")
                }
            }
        )
    }

    // Diálogo Olvidó Contraseña
    if (showForgotDialog) {
        AlertDialog(
            onDismissRequest = {
                showForgotDialog = false
                forgotTempResult = null
                forgotError = null
            },
            title = {
                Text(
                    text = if (forgotTempResult == null) "Recuperar Contraseña" else "Contraseña Temporal Generada",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (forgotTempResult == null) {
                        Text(
                            text = "Ingresa tu correo registrado. Te enviaremos una contraseña temporal lista para enviar a tu correo y copiada a tu portapapeles.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = forgotEmailInput,
                            onValueChange = { forgotEmailInput = it },
                            label = { Text("Correo registrado") },
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = null, tint = ThemeBlue)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        forgotError?.let { err ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = err, color = ExpenseRed, fontSize = 12.sp)
                        }
                    } else {
                        Text(
                            text = "Se ha abierto tu aplicación de correo para enviar la contraseña a tu bandeja y también se copió al portapapeles:",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            color = ThemeBlue.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = forgotTempResult ?: "",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = CyanNeon
                                )
                                IconButton(
                                    onClick = {
                                        forgotTempResult?.let {
                                            authManager.generateTemporaryPassword(forgotEmailInput)
                                            Toast.makeText(context, "Copiado al portapapeles", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar",
                                        tint = CyanNeon
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Válida por 24 horas. Úsala para iniciar sesión y luego define tu nueva contraseña.",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                if (forgotTempResult == null) {
                    Button(
                        onClick = {
                            forgotError = null
                            val res = authManager.generateTemporaryPassword(forgotEmailInput)
                            res.onSuccess { tempCode ->
                                forgotTempResult = tempCode
                                Toast.makeText(context, "Contraseña temporal generada y copiada", Toast.LENGTH_LONG).show()
                            }.onFailure { ex ->
                                forgotError = ex.message ?: "No fue posible generar la contraseña temporal."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue)
                    ) {
                        Text("Generar y Enviar", color = Color.White)
                    }
                } else {
                    Button(
                        onClick = {
                            emailInput = forgotEmailInput
                            passwordInput = forgotTempResult ?: ""
                            showForgotDialog = false
                            forgotTempResult = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen)
                    ) {
                        Text("Usar e Iniciar Sesión", color = Color.White)
                    }
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showForgotDialog = false
                        forgotTempResult = null
                        forgotError = null
                    }
                ) {
                    Text("Cerrar")
                }
            }
        )
    }

    // Diálogo Forzar Cambio de Contraseña (cuando ingresa con contraseña temporal)
    if (showForceChangeDialog) {
        AlertDialog(
            onDismissRequest = { /* Bloqueante hasta que defina contraseña */ },
            title = { Text("Establecer Nueva Contraseña", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Has ingresado con una contraseña temporal. Por seguridad, debes definir tu nueva contraseña permanente para SaldoX:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = forceNewPassword,
                        onValueChange = { forceNewPassword = it },
                        label = { Text("Nueva contraseña") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                        },
                        trailingIcon = {
                            IconButton(onClick = { forcePasswordVisible = !forcePasswordVisible }) {
                                Icon(
                                    imageVector = if (forcePasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null
                                )
                            }
                        },
                        visualTransformation = if (forcePasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = forceConfirmPassword,
                        onValueChange = { forceConfirmPassword = it },
                        label = { Text("Confirmar nueva contraseña") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = ThemeBlue)
                        },
                        visualTransformation = if (forcePasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    forceError?.let { err ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = err, color = ExpenseRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        forceError = null
                        if (forceNewPassword != forceConfirmPassword) {
                            forceError = "Las contraseñas no coinciden."
                            return@Button
                        }
                        val res = authManager.setNewPasswordDirectly(forceNewPassword)
                        res.onSuccess {
                            authManager.syncToCloudVault(googleDriveBackupUseCase)
                            Toast.makeText(context, "Contraseña actualizada exitosamente", Toast.LENGTH_SHORT).show()
                            showForceChangeDialog = false
                            onAuthSuccess()
                        }.onFailure { ex ->
                            forceError = ex.message ?: "No se pudo actualizar la contraseña."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen)
                ) {
                    Text("Guardar y Continuar", color = Color.White)
                }
            }
        )
    }

    // Diálogo de Verificación de Correo con Código de 6 Dígitos
    if (showVerifyEmailDialog) {
        AlertDialog(
            onDismissRequest = { /* Bloqueante para asegurar verificación */ },
            shape = RoundedCornerShape(24.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null,
                        tint = ThemeBlue,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Confirma tu Correo",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Hemos enviado un código de 6 dígitos a tu correo:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = emailInput.trim(),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                    Text(
                        text = "Abre tu correo electrónico (revisa también tu bandeja de entrada o carpeta de Spam / No deseados) e ingresa el código de 6 dígitos recibido para activar tu cuenta:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = verificationCodeInput,
                        onValueChange = { input ->
                            if (input.length <= 6 && input.all { it.isDigit() }) {
                                verificationCodeInput = input
                                verificationError = null
                            }
                        },
                        label = { Text("Código de 6 dígitos") },
                        placeholder = { Text("· · · · · ·") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    verificationError?.let { err ->
                        Text(
                            text = err,
                            color = ExpenseRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "¿No lo recibiste?",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Reenviar código",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ThemeBlue,
                            modifier = Modifier
                                .clickable {
                                    authManager.resendVerificationCode().fold(
                                        onSuccess = {
                                            verificationError = null
                                            Toast.makeText(context, "Nuevo código enviado a tu correo.", Toast.LENGTH_SHORT).show()
                                        },
                                        onFailure = {
                                            verificationError = it.message
                                        }
                                    )
                                }
                                .padding(4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val code = verificationCodeInput.trim()
                        if (code.length != 6) {
                            verificationError = "Por favor ingresa los 6 dígitos."
                            return@Button
                        }
                        val verifyResult = authManager.verifyEmailCode(code)
                        verifyResult.fold(
                            onSuccess = {
                                showVerifyEmailDialog = false
                                val account = googleDriveBackupUseCase.getLastSignedInAccount()
                                if (account != null) {
                                    isCloudSyncing = true
                                    cloudSyncStatusText = "Sincronizando cuenta en Google Drive..."
                                    coroutineScope.launch {
                                        val hash = authManager.getPasswordHash() ?: ""
                                        val salt = authManager.getPasswordSalt() ?: ""
                                        if (hash.isNotBlank() && salt.isNotBlank()) {
                                            googleDriveBackupUseCase.uploadCloudVault(account, nameInput, emailInput, hash, salt)
                                        }
                                        googleDriveBackupUseCase.uploadDatabaseBackup(account)
                                        isCloudSyncing = false
                                        cloudSyncStatusText = null
                                        Toast.makeText(context, "¡Cuenta verificada y activada con éxito!", Toast.LENGTH_LONG).show()
                                        onAuthSuccess()
                                    }
                                } else {
                                    showCloudRegisterDialog = true
                                }
                            },
                            onFailure = { ex ->
                                verificationError = ex.message ?: "Código incorrecto."
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Confirmar y Activar", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        authManager.clearPendingVerification()
                        showVerifyEmailDialog = false
                    }
                ) {
                    Text("Cancelar")
                }
            }
        )
    }
}
