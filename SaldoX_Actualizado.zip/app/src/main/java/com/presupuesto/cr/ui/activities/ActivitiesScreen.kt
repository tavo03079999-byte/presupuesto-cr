package com.presupuesto.cr.ui.activities

import android.app.DatePickerDialog
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.presupuesto.cr.data.local.entity.ActivityLogEntity
import com.presupuesto.cr.ui.theme.BackgroundDark
import com.presupuesto.cr.ui.theme.CyanNeon
import com.presupuesto.cr.ui.theme.EmeraldNeon
import com.presupuesto.cr.ui.theme.ExpenseRed
import com.presupuesto.cr.ui.theme.IncomeGreen
import com.presupuesto.cr.ui.theme.SurfaceDark
import com.presupuesto.cr.ui.theme.ThemeBlue
import com.presupuesto.cr.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivitiesScreen(
    viewModel: ActivitiesViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    val activities by viewModel.filteredActivities.collectAsState()
    val distinctNames by viewModel.distinctActivityNames.collectAsState()
    val selectedFilter by viewModel.selectedActivityFilter.collectAsState()
    val startDateFilter by viewModel.startDateFilter.collectAsState()
    val endDateFilter by viewModel.endDateFilter.collectAsState()

    val totalMinutes by viewModel.totalMinutesAll.collectAsState()
    val minutesByActivity by viewModel.minutesByActivity.collectAsState()
    val activitiesThisMonth by viewModel.activitiesThisMonthCount.collectAsState()

    val isExportingPdf by viewModel.isExportingPdf.collectAsState()
    val exportedPdf by viewModel.exportedPdfFile.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var showAddSheet by remember { mutableStateOf(false) }
    var activityToDelete by remember { mutableStateOf<ActivityLogEntity?>(null) }
    var showDateRangeDialog by remember { mutableStateOf(false) }

    // Manejo de compartir PDF una vez generado
    LaunchedEffect(exportedPdf) {
        exportedPdf?.let { file ->
            try {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "Registro de Actividades Personales")
                    putExtra(Intent.EXTRA_TEXT, "Adjunto reporte en PDF del registro de actividades personales.")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Descargar / Compartir PDF"))
            } catch (e: Exception) {
                Toast.makeText(context, "No se pudo abrir el PDF: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            viewModel.clearExportedPdfFile()
        }
    }

    // Manejo de errores en Toast
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearErrorMessage()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Registro de Actividades",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Regresar",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // Botón Descargar PDF en barra superior
                    IconButton(
                        onClick = { viewModel.exportPdf() },
                        enabled = !isExportingPdf
                    ) {
                        if (isExportingPdf) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = CyanNeon,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = "Descargar PDF",
                                tint = CyanNeon
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddSheet = true },
                containerColor = ThemeBlue,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Nueva Actividad"
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Resumen / Dashboard de Actividades
            item {
                ActivityDashboardCard(
                    totalMinutes = totalMinutes,
                    activitiesThisMonth = activitiesThisMonth,
                    minutesByActivity = minutesByActivity,
                    onExportPdfClick = { viewModel.exportPdf() },
                    isExporting = isExportingPdf
                )
            }

            // 2. Barra de Filtros (Tipo de Actividad y Rango de Fechas)
            item {
                ActivityFiltersSection(
                    distinctNames = distinctNames,
                    selectedFilter = selectedFilter,
                    startDateFilter = startDateFilter,
                    endDateFilter = endDateFilter,
                    onSelectFilter = { viewModel.setActivityFilter(it) },
                    onOpenDateRangeDialog = { showDateRangeDialog = true },
                    onClearFilters = { viewModel.clearFilters() }
                )
            }

            // 3. Encabezado de la lista con conteo
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Actividades Registradas (${activities.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    if (selectedFilter != null || startDateFilter != null || endDateFilter != null) {
                        Text(
                            text = "Filtro activo",
                            fontSize = 11.5.sp,
                            color = CyanNeon,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // 4. Lista de Actividades (Ordenada por fecha, más reciente primero)
            if (activities.isEmpty()) {
                item {
                    EmptyActivitiesCard(
                        hasFilters = selectedFilter != null || startDateFilter != null || endDateFilter != null,
                        onAddClick = { showAddSheet = true },
                        onClearFilters = { viewModel.clearFilters() }
                    )
                }
            } else {
                items(activities, key = { it.id }) { activity ->
                    ActivityLogItemCard(
                        activity = activity,
                        onDeleteClick = { activityToDelete = activity }
                    )
                }
            }
        }
    }

    // Modal BottomSheet para Registro de Actividad
    if (showAddSheet) {
        AddActivityBottomSheet(
            onDismiss = { showAddSheet = false },
            onSave = { name, duration, date, notes ->
                viewModel.addActivity(
                    name = name,
                    durationMinutes = duration,
                    date = date,
                    notes = notes,
                    onSuccess = {
                        showAddSheet = false
                        Toast.makeText(context, "Actividad guardada con éxito", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        )
    }

    // Diálogo de Confirmación antes de Eliminar
    activityToDelete?.let { activity ->
        AlertDialog(
            onDismissRequest = { activityToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = null,
                    tint = ExpenseRed,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "Eliminar Actividad",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Text(
                    text = "¿Estás seguro de que deseas eliminar esta actividad?\n\n• ${activity.activityName} (${activity.durationMinutes} min)\n• Fecha: ${DateUtils.formatDate(activity.date)}",
                    fontSize = 13.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteActivity(activity)
                        activityToDelete = null
                        Toast.makeText(context, "Actividad eliminada", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Eliminar", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { activityToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo para Filtro por Rango de Fechas
    if (showDateRangeDialog) {
        DateRangeFilterDialog(
            currentStart = startDateFilter,
            currentEnd = endDateFilter,
            onDismiss = { showDateRangeDialog = false },
            onApply = { start, end ->
                viewModel.setDateFilter(start, end)
                showDateRangeDialog = false
            },
            onCurrentMonth = {
                viewModel.setDateFilterCurrentMonth()
                showDateRangeDialog = false
            },
            onClear = {
                viewModel.setDateFilter(null, null)
                showDateRangeDialog = false
            }
        )
    }
}

// -------------------------------------------------------------
// Componente: Tarjeta de Resumen / Dashboard de Actividades
// -------------------------------------------------------------
@Composable
private fun ActivityDashboardCard(
    totalMinutes: Int,
    activitiesThisMonth: Int,
    minutesByActivity: Map<String, Int>,
    onExportPdfClick: () -> Unit,
    isExporting: Boolean
) {
    val hours = totalMinutes / 60
    val remMin = totalMinutes % 60
    val durationFormatted = if (hours > 0) "${hours}h ${remMin}m" else "$totalMinutes min"

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(ThemeBlue.copy(alpha = 0.16f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Dashboard de Actividades",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Métricas y resumen acumulado",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Botón Exportar PDF
                OutlinedButton(
                    onClick = onExportPdfClick,
                    enabled = !isExporting,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    if (isExporting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = CyanNeon,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "PDF",
                            color = CyanNeon,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tarjetas de estadísticas principales
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = ThemeBlue.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, ThemeBlue.copy(alpha = 0.35f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Tiempo Total",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = durationFormatted,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = CyanNeon
                        )
                        Text(
                            text = "$totalMinutes minutos",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = EmeraldNeon.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, EmeraldNeon.copy(alpha = 0.35f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Este Mes",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$activitiesThisMonth",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = EmeraldNeon
                        )
                        Text(
                            text = "actividades",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Desglose por actividad si hay datos
            if (minutesByActivity.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Minutos por Actividad:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.85f)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    minutesByActivity.forEach { (name, mins) ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = name,
                                    fontSize = 11.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${mins}m",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanNeon
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Componente: Filtros por Tipo de Actividad y Rango de Fechas
// -------------------------------------------------------------
@Composable
private fun ActivityFiltersSection(
    distinctNames: List<String>,
    selectedFilter: String?,
    startDateFilter: Long?,
    endDateFilter: Long?,
    onSelectFilter: (String?) -> Unit,
    onOpenDateRangeDialog: () -> Unit,
    onClearFilters: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd/MM", Locale.getDefault())
    val hasDateFilter = startDateFilter != null || endDateFilter != null
    val dateLabel = if (startDateFilter != null && endDateFilter != null) {
        "${dateFormat.format(Date(startDateFilter))} - ${dateFormat.format(Date(endDateFilter))}"
    } else if (startDateFilter != null) {
        "Desde ${dateFormat.format(Date(startDateFilter))}"
    } else if (endDateFilter != null) {
        "Hasta ${dateFormat.format(Date(endDateFilter))}"
    } else {
        "Todas las fechas"
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Botón de filtro de fechas
            Surface(
                onClick = onOpenDateRangeDialog,
                shape = RoundedCornerShape(12.dp),
                color = if (hasDateFilter) ThemeBlue.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, if (hasDateFilter) ThemeBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = if (hasDateFilter) CyanNeon else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = dateLabel,
                        fontSize = 11.5.sp,
                        fontWeight = if (hasDateFilter) FontWeight.Bold else FontWeight.Normal,
                        color = if (hasDateFilter) CyanNeon else Color.White
                    )
                }
            }

            if (selectedFilter != null || hasDateFilter) {
                TextButton(
                    onClick = onClearFilters,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = null,
                        tint = ExpenseRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Limpiar filtros",
                        color = ExpenseRed,
                        fontSize = 11.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Chips horizontales para filtro por tipo de actividad
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val isAllSelected = selectedFilter == null
            FilterChip(
                selected = isAllSelected,
                onClick = { onSelectFilter(null) },
                label = { Text("Todas", fontSize = 11.5.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ThemeBlue,
                    selectedLabelColor = Color.White
                )
            )

            distinctNames.forEach { name ->
                val isSelected = selectedFilter.equals(name, ignoreCase = true)
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectFilter(if (isSelected) null else name) },
                    label = { Text(name, fontSize = 11.5.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ThemeBlue,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Componente: Tarjeta individual de Actividad Registrada
// -------------------------------------------------------------
@Composable
private fun ActivityLogItemCard(
    activity: ActivityLogEntity,
    onDeleteClick: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val dateStr = dateFormat.format(Date(activity.date))

    val icon = when {
        activity.activityName.contains("gym", ignoreCase = true) ||
        activity.activityName.contains("gimnasio", ignoreCase = true) ||
        activity.activityName.contains("pesa", ignoreCase = true) -> Icons.Default.FitnessCenter
        activity.activityName.contains("lectura", ignoreCase = true) ||
        activity.activityName.contains("libro", ignoreCase = true) ||
        activity.activityName.contains("estudio", ignoreCase = true) -> Icons.Default.MenuBook
        activity.activityName.contains("correr", ignoreCase = true) ||
        activity.activityName.contains("trote", ignoreCase = true) ||
        activity.activityName.contains("caminata", ignoreCase = true) -> Icons.Default.DirectionsRun
        else -> Icons.Default.Schedule
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ThemeBlue.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = CyanNeon,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = activity.activityName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Surface(
                        color = EmeraldNeon.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${activity.durationMinutes} min",
                            color = EmeraldNeon,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = dateStr,
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (activity.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activity.notes,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.78f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(onClick = onDeleteClick) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Eliminar",
                    tint = ExpenseRed.copy(alpha = 0.85f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Componente: Vista cuando no hay actividades
// -------------------------------------------------------------
@Composable
private fun EmptyActivitiesCard(
    hasFilters: Boolean,
    onAddClick: () -> Unit,
    onClearFilters: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.FitnessCenter,
                contentDescription = null,
                tint = CyanNeon.copy(alpha = 0.6f),
                modifier = Modifier.size(46.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (hasFilters) "No se encontraron actividades con estos filtros" else "Aún no has registrado actividades",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (hasFilters) "Prueba seleccionando otro rango de fechas o categoría." else "Registra tus sesiones de ejercicio, lectura, estudio o pasatiempos para llevar un control de tu tiempo.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))

            if (hasFilters) {
                OutlinedButton(onClick = onClearFilters) {
                    Text("Quitar filtros")
                }
            } else {
                Button(
                    onClick = onAddClick,
                    colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Agregar Primera Actividad")
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Componente: Formulario BottomSheet para Agregar Actividad
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddActivityBottomSheet(
    onDismiss: () -> Unit,
    onSave: (name: String, duration: Int, date: Long, notes: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    var activityName by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("30") }
    var selectedDateMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var notesText by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val formattedDate = dateFormat.format(Date(selectedDateMillis))

    val calendar = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val newCal = Calendar.getInstance().apply {
                set(Calendar.YEAR, year)
                set(Calendar.MONTH, month)
                set(Calendar.DAY_OF_MONTH, dayOfMonth)
                set(Calendar.HOUR_OF_DAY, 12)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }
            selectedDateMillis = newCal.timeInMillis
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Registro de Actividad",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Campo Nombre de Actividad
            OutlinedTextField(
                value = activityName,
                onValueChange = {
                    activityName = it
                    validationError = null
                },
                label = { Text("Nombre de la actividad") },
                placeholder = { Text("Ej: Gimnasio, Lectura, Correr") },
                leadingIcon = {
                    Icon(Icons.Default.FitnessCenter, contentDescription = null, tint = ThemeBlue)
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            // Chips rápidos para nombre sugerido
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val suggestions = listOf("Gimnasio", "Lectura", "Correr", "Caminata", "Estudio", "Ciclismo", "Meditación")
                suggestions.forEach { suggestion ->
                    Surface(
                        onClick = {
                            activityName = suggestion
                            validationError = null
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                    ) {
                        Text(
                            text = suggestion,
                            fontSize = 11.5.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Campo Duración en Minutos
            OutlinedTextField(
                value = durationText,
                onValueChange = {
                    durationText = it.filter { char -> char.isDigit() }
                    validationError = null
                },
                label = { Text("Duración (minutos)") },
                leadingIcon = {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = ThemeBlue)
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            // Botones rápidos de duración
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(15, 30, 45, 60, 90).forEach { mins ->
                    Surface(
                        onClick = { durationText = mins.toString() },
                        shape = RoundedCornerShape(8.dp),
                        color = if (durationText == mins.toString()) ThemeBlue.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (durationText == mins.toString()) BorderStroke(1.dp, ThemeBlue) else null,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(
                                text = "${mins}m",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (durationText == mins.toString()) CyanNeon else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Campo Fecha (automática hoy, editable para actividades pasadas)
            OutlinedTextField(
                value = formattedDate,
                onValueChange = {},
                readOnly = true,
                label = { Text("Fecha de la actividad") },
                leadingIcon = {
                    Icon(Icons.Default.CalendarToday, contentDescription = null, tint = ThemeBlue)
                },
                trailingIcon = {
                    IconButton(onClick = { datePickerDialog.show() }) {
                        Icon(
                            imageVector = Icons.Default.EditCalendar,
                            contentDescription = "Cambiar fecha",
                            tint = CyanNeon
                        )
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { datePickerDialog.show() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Campo Notas opcionales
            OutlinedTextField(
                value = notesText,
                onValueChange = { notesText = it },
                label = { Text("Notas / Comentarios (opcional)") },
                placeholder = { Text("Ej: Día de pierna, Capítulo 5 del libro X") },
                leadingIcon = {
                    Icon(Icons.Default.Notes, contentDescription = null, tint = ThemeBlue)
                },
                maxLines = 3,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            validationError?.let { err ->
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = err, color = ExpenseRed, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Botón Agregar Actividad
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(
                        brush = Brush.horizontalGradient(listOf(ThemeBlue, CyanNeon, EmeraldNeon)),
                        shape = CircleShape
                    )
                    .clickable {
                        val duration = durationText.toIntOrNull() ?: 0
                        if (activityName.trim().isBlank()) {
                            validationError = "Por favor escribe el nombre de la actividad."
                            return@clickable
                        }
                        if (duration <= 0) {
                            validationError = "Ingresa una duración válida en minutos."
                            return@clickable
                        }

                        onSave(activityName, duration, selectedDateMillis, notesText)
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Agregar Actividad",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

// -------------------------------------------------------------
// Componente: Diálogo para Selección de Rango de Fechas
// -------------------------------------------------------------
@Composable
private fun DateRangeFilterDialog(
    currentStart: Long?,
    currentEnd: Long?,
    onDismiss: () -> Unit,
    onApply: (start: Long?, end: Long?) -> Unit,
    onCurrentMonth: () -> Unit,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    var startMillis by remember { mutableStateOf(currentStart) }
    var endMillis by remember { mutableStateOf(currentEnd) }

    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    val startPicker = DatePickerDialog(
        context,
        { _, y, m, d ->
            val cal = Calendar.getInstance().apply {
                set(y, m, d, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }
            startMillis = cal.timeInMillis
        },
        Calendar.getInstance().get(Calendar.YEAR),
        Calendar.getInstance().get(Calendar.MONTH),
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
    )

    val endPicker = DatePickerDialog(
        context,
        { _, y, m, d ->
            val cal = Calendar.getInstance().apply {
                set(y, m, d, 23, 59, 59)
                set(Calendar.MILLISECOND, 999)
            }
            endMillis = cal.timeInMillis
        },
        Calendar.getInstance().get(Calendar.YEAR),
        Calendar.getInstance().get(Calendar.MONTH),
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Filtrar por Rango de Fechas", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Selecciona el periodo que deseas visualizar o exportar en PDF:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Presets rápidos
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onCurrentMonth,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Este Mes", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onClear,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Todo el Historial", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Fecha Desde
                Surface(
                    onClick = { startPicker.show() },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Desde", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = startMillis?.let { dateFormat.format(Date(it)) } ?: "Sin fecha inicio",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Fecha Hasta
                Surface(
                    onClick = { endPicker.show() },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Hasta", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = endMillis?.let { dateFormat.format(Date(it)) } ?: "Sin fecha fin",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onApply(startMillis, endMillis) },
                colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue)
            ) {
                Text("Aplicar Rango", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
