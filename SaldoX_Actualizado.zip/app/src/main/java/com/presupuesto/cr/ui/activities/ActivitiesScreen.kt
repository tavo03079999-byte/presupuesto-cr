package com.presupuesto.cr.ui.activities

import android.app.DatePickerDialog
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.presupuesto.cr.data.local.entity.ActivityGoalEntity
import com.presupuesto.cr.data.local.entity.ActivityLogEntity
import com.presupuesto.cr.ui.theme.CyanNeon
import com.presupuesto.cr.ui.theme.EmeraldNeon
import com.presupuesto.cr.ui.theme.ExpenseRed
import com.presupuesto.cr.ui.theme.IncomeGreen
import com.presupuesto.cr.ui.theme.ThemeBlue
import com.presupuesto.cr.ui.theme.WarningOrange
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2

private val PieChartColors = listOf(
    ThemeBlue,
    EmeraldNeon,
    Color(0xFFFF9800),
    Color(0xFFAB47BC),
    Color(0xFFE91E63),
    CyanNeon,
    Color(0xFF009688),
    Color(0xFFFF5722),
    Color(0xFF3F51B5),
    Color(0xFF795548)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivitiesScreen(
    viewModel: ActivitiesViewModel,
    headerSlot: @Composable (() -> Unit)? = null
) {
    val context = LocalContext.current

    val activities by viewModel.filteredActivities.collectAsState()
    val distinctNames by viewModel.distinctActivityNames.collectAsState()
    val selectedFilter by viewModel.selectedActivityFilter.collectAsState()
    val startDateFilter by viewModel.startDateFilter.collectAsState()
    val endDateFilter by viewModel.endDateFilter.collectAsState()

    val totalMinutes by viewModel.totalMinutesAll.collectAsState()
    val minutesByActivity by viewModel.minutesByActivity.collectAsState()
    val activitiesThisMonth by viewModel.activitiesThisMonthCount.collectAsState()

    // Metas Diarias
    val allGoals by viewModel.allGoals.collectAsState()
    val activeGoals by viewModel.activeGoals.collectAsState()
    val todayCompletedIds by viewModel.todayCompletedGoalIds.collectAsState()
    val todayProgress by viewModel.todayProgress.collectAsState()
    val streakStats by viewModel.streakStats.collectAsState()
    val monthComplianceList by viewModel.monthComplianceList.collectAsState()

    val isExportingPdf by viewModel.isExportingPdf.collectAsState()
    val exportedPdf by viewModel.exportedPdfFile.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var showAddOrEditSheet by remember { mutableStateOf(false) }
    var editingActivity by remember { mutableStateOf<ActivityLogEntity?>(null) }
    var activityToDelete by remember { mutableStateOf<ActivityLogEntity?>(null) }
    var showDateRangeDialog by remember { mutableStateOf(false) }

    var showManageGoalsSheet by remember { mutableStateOf(false) }
    var goalToDelete by remember { mutableStateOf<ActivityGoalEntity?>(null) }

    // Compartir PDF generado
    LaunchedEffect(exportedPdf) {
        exportedPdf?.let { file ->
            try {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "Registro de Actividades Personales - SaldoX")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Compartir Reporte PDF"))
            } catch (e: Exception) {
                Toast.makeText(context, "Error al abrir PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                viewModel.clearExportedPdfFile()
            }
        }
    }

    // Mensajes de error
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearErrorMessage()
        }
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Actividades Personales",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.exportPdf() },
                            enabled = !isExportingPdf
                        ) {
                            if (isExportingPdf) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = ThemeBlue
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = "Descargar PDF",
                                    tint = ThemeBlue
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )

                // Slot opcional para el selector de modo Finanzas / Actividades
                if (headerSlot != null) {
                    headerSlot()
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), thickness = 1.dp)
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingActivity = null
                    showAddOrEditSheet = true
                },
                containerColor = ThemeBlue,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "Registrar actividad")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Gráfico de Pastel / Dona (Distribución del Tiempo)
            item {
                ActivityPieChartCard(
                    minutesByActivity = minutesByActivity,
                    totalMinutes = totalMinutes
                )
            }

            // 2. Metas de Actividades Diarias (Daily Goals) 🎯
            item {
                DailyGoalsCard(
                    activeGoals = activeGoals,
                    todayCompletedIds = todayCompletedIds,
                    progress = todayProgress,
                    streakStats = streakStats,
                    monthCompliance = monthComplianceList,
                    onToggleGoal = { goalId, isCompleted, minutes ->
                        viewModel.toggleGoalCompletionToday(goalId, isCompleted, minutes)
                    },
                    onManageGoalsClick = { showManageGoalsSheet = true }
                )
            }

            // 3. Mini Dashboard / Resumen General
            item {
                ActivitySummaryDashboard(
                    totalMinutes = totalMinutes,
                    monthCount = activitiesThisMonth,
                    hasActiveFilters = selectedFilter != null || startDateFilter != null || endDateFilter != null,
                    onClearFilters = { viewModel.clearFilters() },
                    onOpenDateFilter = { showDateRangeDialog = true }
                )
            }

            // 4. Barra de Filtro de Actividades
            item {
                ActivityFilterBar(
                    distinctNames = distinctNames,
                    selectedFilter = selectedFilter,
                    onSelectFilter = { viewModel.setActivityFilter(it) }
                )
            }

            // 5. Encabezado de Lista
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Historial de Registros",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${activities.size} registros",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 6. Lista de Actividades
            if (activities.isEmpty()) {
                item {
                    EmptyActivitiesCard()
                }
            } else {
                items(activities, key = { it.id }) { activity ->
                    ActivityLogItemCard(
                        activity = activity,
                        onEdit = {
                            editingActivity = activity
                            showAddOrEditSheet = true
                        },
                        onDelete = { activityToDelete = activity }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Modal para Registrar / Editar Actividad
    if (showAddOrEditSheet) {
        AddOrEditActivityBottomSheet(
            activityToEdit = editingActivity,
            existingNames = distinctNames,
            onDismiss = {
                showAddOrEditSheet = false
                editingActivity = null
            },
            onSave = { name, duration, date, notes ->
                if (editingActivity == null) {
                    viewModel.addActivity(name, duration, date, notes) {
                        showAddOrEditSheet = false
                    }
                } else {
                    viewModel.updateActivity(editingActivity!!.id, name, duration, date, notes) {
                        showAddOrEditSheet = false
                        editingActivity = null
                    }
                }
            }
        )
    }

    // Modal para Administrar Metas (Crear, Editar, Activar/Desactivar, Borrar)
    if (showManageGoalsSheet) {
        ManageGoalsBottomSheet(
            allGoals = allGoals,
            onDismiss = { showManageGoalsSheet = false },
            onAddGoal = { name, target ->
                viewModel.addGoal(name, target)
            },
            onUpdateGoal = { id, name, target, isActive ->
                viewModel.updateGoal(id, name, target, isActive)
            },
            onToggleActive = { goal ->
                viewModel.toggleGoalActive(goal)
            },
            onDeleteGoal = { goal ->
                goalToDelete = goal
            }
        )
    }

    // Diálogo de Confirmación para Eliminar Registro de Actividad
    if (activityToDelete != null) {
        AlertDialog(
            onDismissRequest = { activityToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = ExpenseRed) },
            title = { Text("¿Eliminar actividad?", fontWeight = FontWeight.Bold) },
            text = { Text("¿Estás seguro de que deseas eliminar este registro de \"${activityToDelete!!.activityName}\"? Esta acción no se puede deshacer.") },
            confirmButton = {
                Button(
                    onClick = {
                        activityToDelete?.let { viewModel.deleteActivity(it) }
                        activityToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Eliminar", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { activityToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo de Confirmación para Eliminar Meta
    if (goalToDelete != null) {
        AlertDialog(
            onDismissRequest = { goalToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = ExpenseRed) },
            title = { Text("¿Eliminar meta?", fontWeight = FontWeight.Bold) },
            text = { Text("¿Estás seguro de que deseas eliminar la meta diaria \"${goalToDelete!!.name}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        goalToDelete?.let { viewModel.deleteGoal(it) }
                        goalToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Eliminar", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { goalToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo de Filtro de Fechas
    if (showDateRangeDialog) {
        DateRangeFilterDialog(
            currentStart = startDateFilter,
            currentEnd = endDateFilter,
            onDismiss = { showDateRangeDialog = false },
            onApply = { start, end ->
                viewModel.setDateFilter(start, end)
                showDateRangeDialog = false
            },
            onSelectThisMonth = {
                viewModel.setDateFilterCurrentMonth()
                showDateRangeDialog = false
            }
        )
    }
}

// -------------------------------------------------------------
// 1. Gráfico de Pastel / Dona (Distribución del Tiempo)
// -------------------------------------------------------------
@Composable
fun ActivityPieChartCard(
    minutesByActivity: Map<String, Int>,
    totalMinutes: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Distribución del Tiempo",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                val hours = totalMinutes / 60
                val remainingMin = totalMinutes % 60
                Text(
                    text = if (hours > 0) "${hours}h ${remainingMin}m total" else "$totalMinutes min total",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ThemeBlue
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (totalMinutes <= 0 || minutesByActivity.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Sin actividades registradas para este período",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                val sortedEntries = minutesByActivity.entries.sortedByDescending { it.value }
                var selectedSliceIndex by remember { mutableIntStateOf(-1) }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Dona interactiva con Canvas
                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(sortedEntries, totalMinutes) {
                                    detectTapGestures { offset ->
                                        val center = Offset(size.width / 2f, size.height / 2f)
                                        val angleRad = atan2(offset.y - center.y, offset.x - center.x)
                                        var angleDeg = Math.toDegrees(angleRad.toDouble()).toFloat()
                                        if (angleDeg < 0) angleDeg += 360f

                                        var currentAngle = -90f
                                        if (currentAngle < 0) currentAngle += 360f

                                        var accumulated = 0f
                                        var tappedIdx = -1
                                        for (i in sortedEntries.indices) {
                                            val sweep = (sortedEntries[i].value.toFloat() / totalMinutes.toFloat()) * 360f
                                            val start = (accumulated - 90f + 360f) % 360f
                                            val end = (start + sweep) % 360f

                                            val isInSweep = if (start <= end) {
                                                angleDeg in start..end
                                            } else {
                                                angleDeg >= start || angleDeg <= end
                                            }

                                            if (isInSweep) {
                                                tappedIdx = i
                                                break
                                            }
                                            accumulated += sweep
                                        }
                                        selectedSliceIndex = if (selectedSliceIndex == tappedIdx) -1 else tappedIdx
                                    }
                                }
                        ) {
                            val strokeWidth = 26f
                            var startAngle = -90f
                            val canvasSize = size.minDimension - strokeWidth
                            val arcOffset = Offset(strokeWidth / 2f, strokeWidth / 2f)

                            sortedEntries.forEachIndexed { index, entry ->
                                val sweepAngle = (entry.value.toFloat() / totalMinutes.toFloat()) * 360f
                                val color = PieChartColors[index % PieChartColors.size]
                                val isSelected = selectedSliceIndex == index

                                drawArc(
                                    color = if (isSelected) color else color.copy(alpha = 0.9f),
                                    startAngle = startAngle,
                                    sweepAngle = sweepAngle - 1.5f,
                                    useCenter = false,
                                    topLeft = arcOffset,
                                    size = Size(canvasSize, canvasSize),
                                    style = Stroke(width = if (isSelected) strokeWidth + 8f else strokeWidth, cap = StrokeCap.Round)
                                )
                                startAngle += sweepAngle
                            }
                        }

                        // Texto central informativo
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            if (selectedSliceIndex in sortedEntries.indices) {
                                val item = sortedEntries[selectedSliceIndex]
                                val percent = ((item.value.toFloat() / totalMinutes.toFloat()) * 100f).toInt()
                                Text(
                                    text = "$percent%",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PieChartColors[selectedSliceIndex % PieChartColors.size]
                                )
                                Text(
                                    text = item.key,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            } else {
                                Text(
                                    text = "${sortedEntries.size}",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "tipos",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Leyenda
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        sortedEntries.take(4).forEachIndexed { index, entry ->
                            val percent = ((entry.value.toFloat() / totalMinutes.toFloat()) * 100f).toInt()
                            val color = PieChartColors[index % PieChartColors.size]
                            val isSelected = selectedSliceIndex == index

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { selectedSliceIndex = if (isSelected) -1 else index }
                                    .background(if (isSelected) color.copy(alpha = 0.15f) else Color.Transparent)
                                    .padding(horizontal = 4.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(color, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = entry.key,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "$percent% (${entry.value}m)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (sortedEntries.size > 4) {
                            Text(
                                text = "+ ${sortedEntries.size - 4} más",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. Metas de Actividades Diarias (Daily Goals) 🎯
// -------------------------------------------------------------
@Composable
fun DailyGoalsCard(
    activeGoals: List<ActivityGoalEntity>,
    todayCompletedIds: Set<Long>,
    progress: GoalProgress,
    streakStats: StreakData,
    monthCompliance: List<DayCompliance>,
    onToggleGoal: (Long, Boolean, Int) -> Unit,
    onManageGoalsClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Encabezado de la Sección de Metas
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Metas Diarias 🎯",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                TextButton(
                    onClick = onManageGoalsClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp), tint = ThemeBlue)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Administrar", fontSize = 12.sp, color = ThemeBlue)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Barra de Progreso Diario
            val progressColor = when {
                progress.percentage >= 100 -> EmeraldNeon
                progress.percentage >= 50 -> WarningOrange
                else -> ExpenseRed
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (progress.totalActive == 0) {
                            "Sin metas activas hoy"
                        } else {
                            "${progress.completedCount} de ${progress.totalActive} metas completadas hoy (${progress.percentage}%)"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = when {
                            progress.totalActive == 0 -> "Crea una meta"
                            progress.percentage >= 100 -> "¡Logrado! 🟢"
                            progress.percentage >= 50 -> "En camino 🟡"
                            else -> "Pendiente 🔴"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = progressColor
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { if (progress.totalActive > 0) progress.completedCount.toFloat() / progress.totalActive.toFloat() else 0f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = progressColor,
                    trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Badges de Racha y Estadísticas del Mes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    color = WarningOrange.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text("Racha", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${streakStats.currentStreak} días al 100%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WarningOrange)
                        }
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    color = EmeraldNeon.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text("Mejor racha", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${streakStats.bestStreak} días", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldNeon)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Mini Calendario de Cumplimiento del Mes
            Text(
                text = "Cumplimiento del mes (${streakStats.days100PercentMonth} días al 100% | ${streakStats.avgComplianceMonth}% promedio)",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(monthCompliance) { item ->
                    val dotColor = when {
                        item.totalGoals == 0 -> Color.Gray.copy(alpha = 0.3f)
                        item.percentage >= 100 -> EmeraldNeon
                        item.percentage >= 50 -> WarningOrange
                        else -> ExpenseRed
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(22.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = "${item.dayOfMonth}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(dotColor, CircleShape)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Checklist Diario de Metas Activas
            Text(
                text = "Checklist de Hoy",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (activeGoals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No tienes metas diarias activas. Toca en \"Administrar\" para agregar una.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    activeGoals.forEach { goal ->
                        val isDone = todayCompletedIds.contains(goal.id)

                        Surface(
                            onClick = {
                                onToggleGoal(goal.id, !isDone, goal.targetMinutes)
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isDone) EmeraldNeon.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = BorderStroke(1.dp, if (isDone) EmeraldNeon.copy(alpha = 0.3f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (isDone) EmeraldNeon else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = goal.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        textDecoration = if (isDone) TextDecoration.LineThrough else TextDecoration.None,
                                        color = if (isDone) EmeraldNeon else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (goal.targetMinutes > 0) {
                                        Text(
                                            text = "Objetivo: ${goal.targetMinutes} min",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                if (isDone) {
                                    Text(
                                        text = "✅ Hecho",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldNeon
                                    )
                                } else {
                                    Text(
                                        text = "Pendiente",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 3. Mini Dashboard / Resumen General
// -------------------------------------------------------------
@Composable
fun ActivitySummaryDashboard(
    totalMinutes: Int,
    monthCount: Int,
    hasActiveFilters: Boolean,
    onClearFilters: () -> Unit,
    onOpenDateFilter: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Resumen de Actividades",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onOpenDateFilter, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.CalendarToday, contentDescription = "Filtro de fechas", tint = ThemeBlue, modifier = Modifier.size(18.dp))
                    }
                    if (hasActiveFilters) {
                        TextButton(
                            onClick = onClearFilters,
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                        ) {
                            Text("Limpiar", fontSize = 11.sp, color = ExpenseRed)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Minutos Totales
                Surface(
                    modifier = Modifier.weight(1f),
                    color = ThemeBlue.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Minutos Registrados", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$totalMinutes min",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = ThemeBlue
                        )
                        val hours = totalMinutes / 60
                        val remainingMin = totalMinutes % 60
                        Text(
                            text = if (hours > 0) "(${hours}h ${remainingMin}m)" else "Total en filtro",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Actividades del Mes
                Surface(
                    modifier = Modifier.weight(1f),
                    color = EmeraldNeon.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Actividades Este Mes", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$monthCount",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldNeon
                        )
                        Text(
                            text = "Sesiones registradas",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. Barra de Filtro de Actividades
// -------------------------------------------------------------
@Composable
fun ActivityFilterBar(
    distinctNames: List<String>,
    selectedFilter: String?,
    onSelectFilter: (String?) -> Unit
) {
    val scrollState = rememberScrollState()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilterChip(
            selected = selectedFilter == null,
            onClick = { onSelectFilter(null) },
            label = { Text("Todas") },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = ThemeBlue,
                selectedLabelColor = Color.White
            )
        )

        distinctNames.forEach { name ->
            FilterChip(
                selected = selectedFilter.equals(name, ignoreCase = true),
                onClick = {
                    if (selectedFilter.equals(name, ignoreCase = true)) {
                        onSelectFilter(null)
                    } else {
                        onSelectFilter(name)
                    }
                },
                label = { Text(name) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ThemeBlue,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

// -------------------------------------------------------------
// 5. Item de Registro de Actividad (con Editar y Eliminar)
// -------------------------------------------------------------
@Composable
fun ActivityLogItemCard(
    activity: ActivityLogEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val formattedDate = remember(activity.date) { dateFormat.format(Date(activity.date)) }

    val icon = when {
        activity.activityName.contains("gym", ignoreCase = true) || activity.activityName.contains("gimnasio", ignoreCase = true) || activity.activityName.contains("pesa", ignoreCase = true) -> Icons.Default.FitnessCenter
        activity.activityName.contains("corr", ignoreCase = true) || activity.activityName.contains("trot", ignoreCase = true) -> Icons.Default.DirectionsRun
        activity.activityName.contains("lect", ignoreCase = true) || activity.activityName.contains("leer", ignoreCase = true) || activity.activityName.contains("libro", ignoreCase = true) -> Icons.Default.MenuBook
        activity.activityName.contains("medit", ignoreCase = true) || activity.activityName.contains("yoga", ignoreCase = true) -> Icons.Default.SelfImprovement
        else -> Icons.Default.Timer
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(ThemeBlue.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ThemeBlue,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = activity.activityName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${activity.durationMinutes} min",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CyanNeon
                    )
                    Text(
                        text = " • $formattedDate",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (activity.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activity.notes,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Botón Editar ✏️
            IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Editar",
                    tint = ThemeBlue,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Botón Eliminar 🗑️
            IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Eliminar",
                    tint = ExpenseRed,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun EmptyActivitiesCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.FitnessCenter,
                contentDescription = null,
                modifier = Modifier.size(44.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "No hay actividades registradas",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Toca el botón + para registrar tu primer entrenamiento o hábito.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

// -------------------------------------------------------------
// 6. ModalBottomSheet para Registrar / Editar Actividad
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrEditActivityBottomSheet(
    activityToEdit: ActivityLogEntity?,
    existingNames: List<String>,
    onDismiss: () -> Unit,
    onSave: (String, Int, Long, String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    var name by remember { mutableStateOf(activityToEdit?.activityName ?: "") }
    var durationText by remember { mutableStateOf(activityToEdit?.durationMinutes?.toString() ?: "") }
    var selectedDateMillis by remember { mutableLongStateOf(activityToEdit?.date ?: System.currentTimeMillis()) }
    var notes by remember { mutableStateOf(activityToEdit?.notes ?: "") }
    var errorText by remember { mutableStateOf<String?>(null) }

    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    val calendar = remember { Calendar.getInstance().apply { timeInMillis = selectedDateMillis } }
    val datePickerDialog = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val newCal = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth, 12, 0, 0)
                }
                selectedDateMillis = newCal.timeInMillis
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (activityToEdit == null) "Registrar Actividad" else "Editar Actividad",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Chips de Sugerencia Rápida
            if (existingNames.isNotEmpty()) {
                val scroll = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scroll),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    existingNames.take(6).forEach { suggestion ->
                        Surface(
                            onClick = { name = suggestion },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = suggestion,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Campo Nombre de la Actividad
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    errorText = null
                },
                label = { Text("Nombre de la actividad *") },
                placeholder = { Text("Ej: Gimnasio, Lectura, Correr") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Campo Duración en Minutos
            OutlinedTextField(
                value = durationText,
                onValueChange = {
                    if (it.all { char -> char.isDigit() }) {
                        durationText = it
                        errorText = null
                    }
                },
                label = { Text("Duración (minutos) *") },
                placeholder = { Text("Ej: 40") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Campo Fecha (Editable)
            Surface(
                onClick = { datePickerDialog.show() },
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Fecha", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = dateFormat.format(Date(selectedDateMillis)),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = "Cambiar fecha",
                        tint = CyanNeon,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Campo Notas / Comentarios
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notas / Comentarios (opcional)") },
                placeholder = { Text("Ej: Día de pierna, Capítulo 5 del libro X") },
                maxLines = 3,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            if (errorText != null) {
                Text(
                    text = errorText!!,
                    color = ExpenseRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = {
                    val trimmed = name.trim()
                    val duration = durationText.toIntOrNull() ?: 0
                    if (trimmed.isBlank()) {
                        errorText = "Ingresa el nombre de la actividad."
                        return@Button
                    }
                    if (duration <= 0) {
                        errorText = "La duración debe ser mayor a 0 minutos."
                        return@Button
                    }
                    onSave(trimmed, duration, selectedDateMillis, notes)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue)
            ) {
                Text(
                    text = if (activityToEdit == null) "Agregar Actividad" else "Guardar Cambios",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }
    }
}

// -------------------------------------------------------------
// 7. ModalBottomSheet para Administrar Metas Diarias
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageGoalsBottomSheet(
    allGoals: List<ActivityGoalEntity>,
    onDismiss: () -> Unit,
    onAddGoal: (String, Int) -> Unit,
    onUpdateGoal: (Long, String, Int, Boolean) -> Unit,
    onToggleActive: (ActivityGoalEntity) -> Unit,
    onDeleteGoal: (ActivityGoalEntity) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var newGoalName by remember { mutableStateOf("") }
    var newGoalMinutesText by remember { mutableStateOf("") }
    var editingGoal by remember { mutableStateOf<ActivityGoalEntity?>(null) }
    var editName by remember { mutableStateOf("") }
    var editMinutesText by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Metas Diarias Recurrentes",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = null)
                }
            }

            // Sección para crear o editar meta
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (editingGoal == null) "Agregar Nueva Meta Diaria" else "Editar Meta: ${editingGoal!!.name}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ThemeBlue
                    )

                    OutlinedTextField(
                        value = if (editingGoal == null) newGoalName else editName,
                        onValueChange = {
                            if (editingGoal == null) newGoalName = it else editName = it
                        },
                        label = { Text("Nombre de la meta *") },
                        placeholder = { Text("Ej: Ir al gimnasio, Leer, Meditar") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = if (editingGoal == null) newGoalMinutesText else editMinutesText,
                        onValueChange = {
                            if (it.all { char -> char.isDigit() }) {
                                if (editingGoal == null) newGoalMinutesText = it else editMinutesText = it
                            }
                        },
                        label = { Text("Duración objetivo en minutos (opcional)") },
                        placeholder = { Text("Ej: 40") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        if (editingGoal != null) {
                            TextButton(onClick = { editingGoal = null }) {
                                Text("Cancelar")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        Button(
                            onClick = {
                                if (editingGoal == null) {
                                    val name = newGoalName.trim()
                                    val min = newGoalMinutesText.toIntOrNull() ?: 0
                                    if (name.isNotBlank()) {
                                        onAddGoal(name, min)
                                        newGoalName = ""
                                        newGoalMinutesText = ""
                                    }
                                } else {
                                    val name = editName.trim()
                                    val min = editMinutesText.toIntOrNull() ?: 0
                                    if (name.isNotBlank()) {
                                        onUpdateGoal(editingGoal!!.id, name, min, editingGoal!!.isActive)
                                        editingGoal = null
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (editingGoal == null) "Guardar Meta" else "Actualizar", color = Color.White)
                        }
                    }
                }
            }

            Text(
                text = "Tus Metas Configuradas",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (allGoals.isEmpty()) {
                Text(
                    text = "Aún no tienes metas registradas.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    allGoals.forEach { goal ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = goal.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (goal.isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (goal.targetMinutes > 0) "${goal.targetMinutes} min diarios" else "Meta de hábito",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Switch Activa/Inactiva
                                Switch(
                                    checked = goal.isActive,
                                    onCheckedChange = { onToggleActive(goal) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ThemeBlue,
                                        checkedTrackColor = ThemeBlue.copy(alpha = 0.5f)
                                    )
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                // Editar
                                IconButton(
                                    onClick = {
                                        editingGoal = goal
                                        editName = goal.name
                                        editMinutesText = if (goal.targetMinutes > 0) goal.targetMinutes.toString() else ""
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, tint = ThemeBlue, modifier = Modifier.size(16.dp))
                                }

                                // Eliminar
                                IconButton(
                                    onClick = { onDeleteGoal(goal) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = ExpenseRed, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 8. Diálogo de Filtro de Fechas
// -------------------------------------------------------------
@Composable
fun DateRangeFilterDialog(
    currentStart: Long?,
    currentEnd: Long?,
    onDismiss: () -> Unit,
    onApply: (Long?, Long?) -> Unit,
    onSelectThisMonth: () -> Unit
) {
    val context = LocalContext.current
    var startMillis by remember { mutableStateOf(currentStart) }
    var endMillis by remember { mutableStateOf(currentEnd) }

    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    val startCal = remember { Calendar.getInstance().apply { startMillis?.let { timeInMillis = it } } }
    val startPicker = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val c = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth, 0, 0, 0)
                }
                startMillis = c.timeInMillis
            },
            startCal.get(Calendar.YEAR),
            startCal.get(Calendar.MONTH),
            startCal.get(Calendar.DAY_OF_MONTH)
        )
    }

    val endCal = remember { Calendar.getInstance().apply { endMillis?.let { timeInMillis = it } } }
    val endPicker = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val c = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth, 23, 59, 59)
                }
                endMillis = c.timeInMillis
            },
            endCal.get(Calendar.YEAR),
            endCal.get(Calendar.MONTH),
            endCal.get(Calendar.DAY_OF_MONTH)
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Filtrar por Fecha", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onSelectThisMonth,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Seleccionar Mes Actual")
                }

                // Fecha Desde
                Surface(
                    onClick = { startPicker.show() },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Desde", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = startMillis?.let { dateFormat.format(Date(it)) } ?: "Sin fecha inicio",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp))
                    }
                }

                // Fecha Hasta
                Surface(
                    onClick = { endPicker.show() },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Hasta", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = endMillis?.let { dateFormat.format(Date(it)) } ?: "Sin fecha fin",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onApply(startMillis, endMillis) },
                colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue)
            ) {
                Text("Aplicar", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
