package com.presupuesto.cr.ui.activities

import android.app.DatePickerDialog
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.presupuesto.cr.data.local.entity.ActivityGoalEntity
import com.presupuesto.cr.data.local.entity.ActivityLogEntity
import com.presupuesto.cr.ui.theme.CyberAmber
import com.presupuesto.cr.ui.theme.CyberCardBorder
import com.presupuesto.cr.ui.theme.CyberCyan
import com.presupuesto.cr.ui.theme.CyberObsidian
import com.presupuesto.cr.ui.theme.CyberPink
import com.presupuesto.cr.ui.theme.CyberSurface
import com.presupuesto.cr.ui.theme.CyberSurfaceCard
import com.presupuesto.cr.ui.theme.CyberViolet
import com.presupuesto.cr.ui.theme.CyberVioletDark
import com.presupuesto.cr.ui.theme.CyberVioletLight
import com.presupuesto.cr.ui.theme.ExpenseRed
import com.presupuesto.cr.ui.theme.KineticLime
import com.presupuesto.cr.ui.theme.KineticLimeDark
import com.presupuesto.cr.ui.theme.KineticLimeLight
import com.presupuesto.cr.ui.theme.WarningOrange
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.sqrt

// Paleta Cyber Kinetic para sectores del Donut
private val CyberDonutColors = listOf(
    KineticLime,
    CyberViolet,
    CyberCyan,
    CyberPink,
    CyberAmber,
    Color(0xFF3B82F6),
    Color(0xFF10B981),
    Color(0xFFF43F5E)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivitiesScreen(
    viewModel: ActivitiesViewModel,
    headerSlot: @Composable (() -> Unit)? = null
) {
    val context = LocalContext.current

    val activities by viewModel.filteredActivities.collectAsState()
    val distinctNames by viewModel.distinctActivityNames.collectAsState()
    val selectedFilter by viewModel.selectedActivityFilter.collectAsState()
    val startDateFilter by viewModel.startDateFilter.collectAsState()
    val endDateFilter by viewModel.endDateFilter.collectAsState()

    val totalMinutes by viewModel.totalMinutesAll.collectAsState()
    val minutesByActivity by viewModel.minutesByActivity.collectAsState()
    val activitiesThisMonth by viewModel.activitiesThisMonthCount.collectAsState()

    // Metas Diarias
    val allGoals by viewModel.allGoals.collectAsState()
    val activeGoals by viewModel.activeGoals.collectAsState()
    val todayCompletedIds by viewModel.todayCompletedGoalIds.collectAsState()
    val todayProgress by viewModel.todayProgress.collectAsState()
    val streakStats by viewModel.streakStats.collectAsState()
    val monthComplianceList by viewModel.monthComplianceList.collectAsState()

    // Sistema de Niveles XP Cyber Kinetic
    val levelInfo by viewModel.levelInfo.collectAsState()

    // Modo Cronómetro en Vivo
    val stopwatchSeconds by viewModel.stopwatchSeconds.collectAsState()
    val isStopwatchRunning by viewModel.isStopwatchRunning.collectAsState()

    val isExportingPdf by viewModel.isExportingPdf.collectAsState()
    val exportedPdf by viewModel.exportedPdfFile.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var showAddOrEditSheet by remember { mutableStateOf(false) }
    var editingActivity by remember { mutableStateOf<ActivityLogEntity?>(null) }
    var activityToDelete by remember { mutableStateOf<ActivityLogEntity?>(null) }
    var showDateRangeDialog by remember { mutableStateOf(false) }

    var showManageGoalsSheet by remember { mutableStateOf(false) }
    var goalToDelete by remember { mutableStateOf<ActivityGoalEntity?>(null) }

    // Compartir PDF generado
    LaunchedEffect(exportedPdf) {
        exportedPdf?.let { file ->
            try {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "Registro de Actividades Personales - SaldoX Cyber Kinetic")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Compartir Reporte PDF"))
            } catch (e: Exception) {
                Toast.makeText(context, "Error al abrir PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            } finally {
                viewModel.clearExportedPdfFile()
            }
        }
    }

    // Mensajes de error
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearErrorMessage()
        }
    }

    Scaffold(
        containerColor = CyberObsidian,
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().background(CyberObsidian)) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Actividades Personales",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = KineticLime.copy(alpha = 0.15f),
                                border = BorderStroke(1.dp, KineticLime.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "KINETIC",
                                    color = KineticLime,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.exportPdf() },
                            enabled = !isExportingPdf
                        ) {
                            if (isExportingPdf) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = KineticLime
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = "Descargar PDF",
                                    tint = CyberVioletLight
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = CyberObsidian
                    )
                )

                // Slot opcional para el selector de modo Finanzas / Actividades
                if (headerSlot != null) {
                    headerSlot()
                }

                HorizontalDivider(color = CyberCardBorder.copy(alpha = 0.7f), thickness = 1.dp)
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingActivity = null
                    showAddOrEditSheet = true
                },
                containerColor = KineticLime,
                contentColor = CyberObsidian,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "Registrar actividad")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberObsidian)
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Tarjeta de Sistema de Niveles XP Cyber Kinetic ⚡
            item {
                CyberLevelCard(levelInfo = levelInfo)
            }

            // 2. Modo Cronómetro en Vivo ⏱️
            item {
                CyberLiveStopwatchCard(
                    stopwatchSeconds = stopwatchSeconds,
                    isRunning = isStopwatchRunning,
                    activeGoals = activeGoals,
                    onStart = { viewModel.startStopwatch() },
                    onPause = { viewModel.pauseStopwatch() },
                    onReset = { viewModel.resetStopwatch() },
                    onSave = { name, notes ->
                        viewModel.saveStopwatchAsActivity(name, notes) {
                            Toast.makeText(context, "¡Sesión guardada! +XP sumado", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            // 3. Gráfico Donut Interactivo (Cyber Kinetic Donut Chart) 🍩
            item {
                CyberDonutChartCard(
                    minutesByActivity = minutesByActivity,
                    totalMinutes = totalMinutes
                )
            }

            // 4. Heatmap de Cumplimiento Mensual (Cyber Heatmap Calendar) 📅
            item {
                CyberHeatmapCard(
                    monthCompliance = monthComplianceList,
                    firstDayOffset = viewModel.currentMonthFirstDayOffset,
                    streakStats = streakStats
                )
            }

            // 5. Metas Diarias (Daily Goals Checklist) 🎯
            item {
                CyberDailyGoalsCard(
                    activeGoals = activeGoals,
                    todayCompletedIds = todayCompletedIds,
                    progress = todayProgress,
                    streakStats = streakStats,
                    onToggleGoal = { goalId, isCompleted, minutes ->
                        viewModel.toggleGoalCompletionToday(goalId, isCompleted, minutes)
                    },
                    onManageGoalsClick = { showManageGoalsSheet = true }
                )
            }

            // 6. Mini Dashboard / Resumen General
            item {
                CyberSummaryDashboard(
                    totalMinutes = totalMinutes,
                    monthCount = activitiesThisMonth,
                    hasActiveFilters = selectedFilter != null || startDateFilter != null || endDateFilter != null,
                    onClearFilters = { viewModel.clearFilters() },
                    onOpenDateFilter = { showDateRangeDialog = true }
                )
            }

            // 7. Barra de Filtro de Actividades
            item {
                CyberActivityFilterBar(
                    distinctNames = distinctNames,
                    selectedFilter = selectedFilter,
                    onSelectFilter = { viewModel.setActivityFilter(it) }
                )
            }

            // 8. Encabezado de Lista
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Historial de Registros",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                    Text(
                        text = "${activities.size} registros",
                        fontSize = 12.sp,
                        color = CyberVioletLight
                    )
                }
            }

            // 9. Lista de Actividades
            if (activities.isEmpty()) {
                item {
                    CyberEmptyActivitiesCard()
                }
            } else {
                items(activities, key = { it.id }) { activity ->
                    CyberActivityLogItemCard(
                        activity = activity,
                        onEdit = {
                            editingActivity = activity
                            showAddOrEditSheet = true
                        },
                        onDelete = { activityToDelete = activity }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Modal para Registrar / Editar Actividad
    if (showAddOrEditSheet) {
        CyberAddOrEditActivityBottomSheet(
            activityToEdit = editingActivity,
            existingNames = distinctNames,
            onDismiss = {
                showAddOrEditSheet = false
                editingActivity = null
            },
            onSave = { name, duration, date, notes ->
                if (editingActivity == null) {
                    viewModel.addActivity(name, duration, date, notes) {
                        showAddOrEditSheet = false
                    }
                } else {
                    viewModel.updateActivity(editingActivity!!.id, name, duration, date, notes) {
                        showAddOrEditSheet = false
                        editingActivity = null
                    }
                }
            }
        )
    }

    // Modal para Administrar Metas Diarias
    if (showManageGoalsSheet) {
        CyberManageGoalsBottomSheet(
            allGoals = allGoals,
            onDismiss = { showManageGoalsSheet = false },
            onAddGoal = { name, target ->
                viewModel.addGoal(name, target)
            },
            onUpdateGoal = { id, name, target, isActive ->
                viewModel.updateGoal(id, name, target, isActive)
            },
            onToggleActive = { goal ->
                viewModel.toggleGoalActive(goal)
            },
            onDeleteGoal = { goal ->
                goalToDelete = goal
            }
        )
    }

    // Diálogo de Confirmación para Eliminar Registro de Actividad
    if (activityToDelete != null) {
        AlertDialog(
            containerColor = CyberSurfaceCard,
            onDismissRequest = { activityToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = ExpenseRed) },
            title = { Text("¿Eliminar actividad?", fontWeight = FontWeight.Bold, color = Color.White) },
            text = { Text("¿Estás seguro de que deseas eliminar este registro de \"${activityToDelete!!.activityName}\"? Esta acción no se puede deshacer.", color = Color.White.copy(alpha = 0.8f)) },
            confirmButton = {
                Button(
                    onClick = {
                        activityToDelete?.let { viewModel.deleteActivity(it) }
                        activityToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Eliminar", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { activityToDelete = null }) {
                    Text("Cancelar", color = CyberVioletLight)
                }
            }
        )
    }

    // Diálogo de Confirmación para Eliminar Meta
    if (goalToDelete != null) {
        AlertDialog(
            containerColor = CyberSurfaceCard,
            onDismissRequest = { goalToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = ExpenseRed) },
            title = { Text("¿Eliminar meta?", fontWeight = FontWeight.Bold, color = Color.White) },
            text = { Text("¿Estás seguro de que deseas eliminar la meta diaria \"${goalToDelete!!.name}\"?", color = Color.White.copy(alpha = 0.8f)) },
            confirmButton = {
                Button(
                    onClick = {
                        goalToDelete?.let { viewModel.deleteGoal(it) }
                        goalToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Eliminar", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { goalToDelete = null }) {
                    Text("Cancelar", color = CyberVioletLight)
                }
            }
        )
    }

    // Diálogo Selector de Rango de Fechas
    if (showDateRangeDialog) {
        CyberDateRangePickerDialog(
            initialStart = startDateFilter,
            initialEnd = endDateFilter,
            onDismiss = { showDateRangeDialog = false },
            onApply = { start, end ->
                viewModel.setDateFilter(start, end)
                showDateRangeDialog = false
            },
            onSelectCurrentMonth = {
                viewModel.setDateFilterCurrentMonth()
                showDateRangeDialog = false
            }
        )
    }
}

// -------------------------------------------------------------
// 1. Tarjeta de Sistema de Niveles XP Cyber Kinetic ⚡
// -------------------------------------------------------------
@Composable
fun CyberLevelCard(levelInfo: CyberLevelInfo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyberCardBorder),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            CyberVioletDark.copy(alpha = 0.35f),
                            CyberSurfaceCard,
                            KineticLimeDark.copy(alpha = 0.18f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = CyberViolet.copy(alpha = 0.22f),
                            border = BorderStroke(1.5.dp, CyberViolet),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "L${levelInfo.level}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = KineticLime
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "NIVEL ${levelInfo.level} • ${levelInfo.title.uppercase()}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = CyberVioletLight,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "${levelInfo.currentXp} XP Kinetic",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = KineticLime.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, KineticLime.copy(alpha = 0.45f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = KineticLime, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "+${levelInfo.xpRemaining} XP prox",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = KineticLime
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Barra de Progreso XP con gradiente Kinetic
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Progreso del Nivel",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                        Text(
                            text = "${(levelInfo.progressInLevel * 100).toInt()}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = KineticLime
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(CyberObsidian)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(fraction = levelInfo.progressInLevel.coerceIn(0.02f, 1f))
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(CyberViolet, KineticLime)
                                    )
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Reglas de bonificación
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "⚡ +10 XP/min",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                    Text(text = "•", fontSize = 10.sp, color = CyberCardBorder)
                    Text(
                        text = "🎯 +50 XP/meta",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                    Text(text = "•", fontSize = 10.sp, color = CyberCardBorder)
                    Text(
                        text = "👑 +150 XP 100% día",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. Modo Cronómetro en Vivo (Live Stopwatch) ⏱️
// -------------------------------------------------------------
@Composable
fun CyberLiveStopwatchCard(
    stopwatchSeconds: Long,
    isRunning: Boolean,
    activeGoals: List<ActivityGoalEntity>,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onReset: () -> Unit,
    onSave: (activityName: String, notes: String) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    var selectedActivityName by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }

    val hours = stopwatchSeconds / 3600
    val minutes = (stopwatchSeconds % 3600) / 60
    val seconds = stopwatchSeconds % 60
    val timeFormatted = String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(
            1.dp,
            if (isRunning) KineticLime.copy(alpha = 0.7f) else CyberCardBorder
        ),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = if (isRunning) KineticLime else CyberVioletLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Cronómetro Kinetic en Vivo",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isRunning) {
                        Surface(
                            shape = CircleShape,
                            color = KineticLime,
                            modifier = Modifier.size(8.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "LIVE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = KineticLime
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                    }

                    Text(
                        text = if (isExpanded) "Ocultar" else "Abrir",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberVioletLight,
                        modifier = Modifier
                            .clickable { isExpanded = !isExpanded }
                            .padding(4.dp)
                    )
                }
            }

            // Vista previa pequeña cuando está colapsado
            if (!isExpanded && stopwatchSeconds > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = timeFormatted,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = KineticLime
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { if (isRunning) onPause() else onStart() },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isRunning) WarningOrange else KineticLime
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Spacer(modifier = Modifier.height(14.dp))

                    // Pantalla Digital de Tiempo
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(CyberObsidian)
                            .border(1.dp, if (isRunning) KineticLime.copy(alpha = 0.4f) else CyberCardBorder, RoundedCornerShape(14.dp))
                            .padding(vertical = 18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = timeFormatted,
                                fontSize = 34.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                color = if (isRunning) KineticLime else Color.White,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (selectedActivityName.isBlank()) "Selecciona o escribe la actividad abajo" else "Actividad: $selectedActivityName",
                                fontSize = 11.sp,
                                color = CyberVioletLight,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Chips de Metas Activas para selección rápida
                    if (activeGoals.isNotEmpty()) {
                        Text(
                            text = "Actividad a cronometrar:",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(activeGoals) { goal ->
                                val isSelected = selectedActivityName.equals(goal.name, ignoreCase = true)
                                Surface(
                                    onClick = { selectedActivityName = goal.name },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) KineticLime.copy(alpha = 0.22f) else CyberSurface,
                                    border = BorderStroke(1.dp, if (isSelected) KineticLime else CyberCardBorder)
                                ) {
                                    Text(
                                        text = goal.name,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) KineticLime else Color.White.copy(alpha = 0.8f),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Campo de Nombre Personalizado
                    OutlinedTextField(
                        value = selectedActivityName,
                        onValueChange = { selectedActivityName = it },
                        label = { Text("Nombre de la actividad") },
                        placeholder = { Text("Ej. Correr, Gimnasio, Lectura") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = KineticLime,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedLabelColor = KineticLime,
                            unfocusedLabelColor = Color.White.copy(alpha = 0.6f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Botonera de Controles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play / Pause
                        Button(
                            onClick = { if (isRunning) onPause() else onStart() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRunning) WarningOrange else KineticLime
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = CyberObsidian
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isRunning) "Pausar" else "Iniciar",
                                fontWeight = FontWeight.Bold,
                                color = CyberObsidian
                            )
                        }

                        // Reset
                        OutlinedButton(
                            onClick = onReset,
                            enabled = stopwatchSeconds > 0 && !isRunning,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, CyberCardBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reiniciar", modifier = Modifier.size(18.dp))
                        }

                        // Guardar como Actividad
                        Button(
                            onClick = {
                                onSave(selectedActivityName, notesText)
                                notesText = ""
                            },
                            enabled = stopwatchSeconds >= 10 && !isRunning,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberViolet,
                                disabledContainerColor = CyberCardBorder
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.3f)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Guardar (+XP)", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 3. Gráfico Donut Interactivo (Cyber Donut Chart) 🍩
// -------------------------------------------------------------
@Composable
fun CyberDonutChartCard(
    minutesByActivity: Map<String, Int>,
    totalMinutes: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyberCardBorder),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Distribución del Tiempo",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }
                val hours = totalMinutes / 60
                val remainingMin = totalMinutes % 60
                Text(
                    text = if (hours > 0) "${hours}h ${remainingMin}m total" else "$totalMinutes min total",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = KineticLime
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (totalMinutes <= 0 || minutesByActivity.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Sin actividades registradas para este período",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.5f),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                val sortedEntries = minutesByActivity.entries.sortedByDescending { it.value }
                var selectedSliceIndex by remember { mutableIntStateOf(-1) }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Donut Canvas Interactivo con agujero central
                    Box(
                        modifier = Modifier
                            .size(148.dp)
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(sortedEntries, totalMinutes) {
                                    detectTapGestures { offset ->
                                        val center = Offset(size.width / 2f, size.height / 2f)
                                        val dx = offset.x - center.x
                                        val dy = offset.y - center.y
                                        val dist = sqrt(dx * dx + dy * dy)
                                        val minDim = size.width.coerceAtMost(size.height).toFloat()
                                        val outerRadius = minDim / 2f
                                        val innerRadius = outerRadius - 32f

                                        // Si toca dentro de la corona del donut
                                        if (dist in (innerRadius * 0.5f)..outerRadius) {
                                            val angleRad = atan2(dy, dx)
                                            var angleDeg = Math.toDegrees(angleRad.toDouble()).toFloat()
                                            if (angleDeg < 0) angleDeg += 360f

                                            var accumulated = 0f
                                            var tappedIdx = -1
                                            for (i in sortedEntries.indices) {
                                                val sweep = (sortedEntries[i].value.toFloat() / totalMinutes.toFloat()) * 360f
                                                val start = (accumulated - 90f + 360f) % 360f
                                                val end = (start + sweep) % 360f

                                                val isInSweep = if (start <= end) {
                                                    angleDeg in start..end
                                                } else {
                                                    angleDeg >= start || angleDeg <= end
                                                }

                                                if (isInSweep) {
                                                    tappedIdx = i
                                                    break
                                                }
                                                accumulated += sweep
                                            }
                                            selectedSliceIndex = if (selectedSliceIndex == tappedIdx) -1 else tappedIdx
                                        } else {
                                            selectedSliceIndex = -1
                                        }
                                    }
                                }
                        ) {
                            val strokeWidthNormal = 28f
                            var startAngle = -90f
                            val canvasSize = size.minDimension - (strokeWidthNormal + 8f)
                            val arcOffset = Offset((size.width - canvasSize) / 2f, (size.height - canvasSize) / 2f)

                            sortedEntries.forEachIndexed { index, entry ->
                                val sweepAngle = (entry.value.toFloat() / totalMinutes.toFloat()) * 360f
                                val color = CyberDonutColors[index % CyberDonutColors.size]
                                val isSelected = selectedSliceIndex == index

                                drawArc(
                                    color = if (isSelected) color else color.copy(alpha = 0.85f),
                                    startAngle = startAngle,
                                    sweepAngle = (sweepAngle - 2f).coerceAtLeast(1f),
                                    useCenter = false,
                                    topLeft = arcOffset,
                                    size = Size(canvasSize, canvasSize),
                                    style = Stroke(
                                        width = if (isSelected) strokeWidthNormal + 10f else strokeWidthNormal,
                                        cap = StrokeCap.Round
                                    )
                                )
                                startAngle += sweepAngle
                            }
                        }

                        // Agujero Central del Donut con información interactiva
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            if (selectedSliceIndex in sortedEntries.indices) {
                                val item = sortedEntries[selectedSliceIndex]
                                val percent = ((item.value.toFloat() / totalMinutes.toFloat()) * 100f).toInt()
                                val color = CyberDonutColors[selectedSliceIndex % CyberDonutColors.size]
                                Text(
                                    text = "$percent%",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    color = color
                                )
                                Text(
                                    text = item.key,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${item.value}m",
                                    fontSize = 9.5.sp,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                            } else {
                                Text(
                                    text = "$totalMinutes",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = KineticLime
                                )
                                Text(
                                    text = "minutos",
                                    fontSize = 9.sp,
                                    color = CyberVioletLight,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${sortedEntries.size} tipos",
                                    fontSize = 9.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    // Leyenda Cyber Donut
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        sortedEntries.take(5).forEachIndexed { index, entry ->
                            val percent = ((entry.value.toFloat() / totalMinutes.toFloat()) * 100f).toInt()
                            val color = CyberDonutColors[index % CyberDonutColors.size]
                            val isSelected = selectedSliceIndex == index

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) color.copy(alpha = 0.18f) else Color.Transparent)
                                    .clickable { selectedSliceIndex = if (isSelected) -1 else index }
                                    .padding(horizontal = 4.dp, vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = entry.key,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) color else Color.White.copy(alpha = 0.85f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = "${entry.value}m ($percent%)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) color else CyberVioletLight
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. Heatmap de Cumplimiento Mensual (Cyber Heatmap Calendar) 📅
// -------------------------------------------------------------
@Composable
fun CyberHeatmapCard(
    monthCompliance: List<DayCompliance>,
    firstDayOffset: Int,
    streakStats: StreakData
) {
    var selectedDay by remember { mutableStateOf<DayCompliance?>(null) }
    val daysOfWeek = listOf("L", "M", "M", "J", "V", "S", "D")

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyberCardBorder),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = KineticLime, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Heatmap de Cumplimiento",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }

                Text(
                    text = "${streakStats.avgComplianceMonth}% promedio",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = KineticLime
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Cabecera días de la semana
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                daysOfWeek.forEach { dayName ->
                    Text(
                        text = dayName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberVioletLight,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Grid Heatmap por semanas
            val totalCells = firstDayOffset + monthCompliance.size
            val numRows = (totalCells + 6) / 7

            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                for (row in 0 until numRows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        for (col in 0 until 7) {
                            val cellIndex = row * 7 + col
                            val dayIndex = cellIndex - firstDayOffset

                            if (cellIndex < firstDayOffset || dayIndex >= monthCompliance.size) {
                                // Espacio vacío antes del día 1 o después del último día
                                Box(modifier = Modifier.weight(1f).height(30.dp))
                            } else {
                                val item = monthCompliance[dayIndex]
                                val isSelected = selectedDay?.dayOfMonth == item.dayOfMonth

                                val cellColor = when {
                                    item.totalGoals == 0 -> CyberObsidian
                                    item.percentage >= 100 -> KineticLime
                                    item.percentage >= 50 -> CyberViolet
                                    item.percentage > 0 -> CyberVioletDark.copy(alpha = 0.6f)
                                    else -> CyberObsidian
                                }

                                val textColor = when {
                                    item.percentage >= 100 -> CyberObsidian
                                    item.percentage >= 50 -> Color.White
                                    else -> Color.White.copy(alpha = 0.7f)
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(cellColor)
                                        .border(
                                            1.dp,
                                            if (isSelected) Color.White else if (item.percentage >= 100) KineticLimeLight else CyberCardBorder,
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable {
                                            selectedDay = if (isSelected) null else item
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${item.dayOfMonth}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = textColor
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Leyenda de intensidades
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Menos", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                    Box(modifier = Modifier.size(10.dp).background(CyberObsidian, RoundedCornerShape(2.dp)).border(0.5.dp, CyberCardBorder, RoundedCornerShape(2.dp)))
                    Box(modifier = Modifier.size(10.dp).background(CyberVioletDark.copy(alpha = 0.6f), RoundedCornerShape(2.dp)))
                    Box(modifier = Modifier.size(10.dp).background(CyberViolet, RoundedCornerShape(2.dp)))
                    Box(modifier = Modifier.size(10.dp).background(KineticLime, RoundedCornerShape(2.dp)))
                    Text("100%", fontSize = 10.sp, color = KineticLime, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "${streakStats.days100PercentMonth} días perfectos",
                    fontSize = 10.sp,
                    color = KineticLime,
                    fontWeight = FontWeight.Bold
                )
            }

            // Detalle interactivo del día seleccionado
            selectedDay?.let { day ->
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = CyberObsidian,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (day.percentage >= 100) KineticLime else CyberViolet),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Día ${day.dayOfMonth}: ${day.completedGoals} de ${day.totalGoals} metas (${day.percentage}%)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (day.percentage >= 100) "¡Objetivo 100% completado! +150 XP" else if (day.completedGoals > 0) "Progreso parcial" else "Sin metas completadas",
                                fontSize = 10.sp,
                                color = if (day.percentage >= 100) KineticLime else CyberVioletLight
                            )
                        }

                        IconButton(onClick = { selectedDay = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 5. Metas Diarias (Cyber Kinetic Daily Goals) 🎯
// -------------------------------------------------------------
@Composable
fun CyberDailyGoalsCard(
    activeGoals: List<ActivityGoalEntity>,
    todayCompletedIds: Set<Long>,
    progress: GoalProgress,
    streakStats: StreakData,
    onToggleGoal: (goalId: Long, isCompleted: Boolean, minutes: Int) -> Unit,
    onManageGoalsClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyberCardBorder),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Metas Diarias 🎯",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }

                TextButton(
                    onClick = onManageGoalsClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = KineticLime, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Gestionar", fontSize = 11.sp, color = KineticLime, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Barra de progreso de metas
            val progressColor = when {
                progress.percentage >= 100 -> KineticLime
                progress.percentage >= 50 -> CyberViolet
                else -> WarningOrange
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberObsidian)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (progress.totalActive == 0) "Sin metas activas hoy" else "${progress.completedCount} de ${progress.totalActive} completadas (${progress.percentage}%)",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (progress.percentage >= 100) "¡Logrado! ⚡" else if (progress.percentage >= 50) "En camino 🟣" else "Pendiente 🟡",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = progressColor
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { if (progress.totalActive > 0) progress.completedCount.toFloat() / progress.totalActive.toFloat() else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = progressColor,
                        trackColor = CyberCardBorder
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Racha y Mejor Racha Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, WarningOrange.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text("Racha activa", fontSize = 9.sp, color = Color.White.copy(alpha = 0.6f))
                            Text("${streakStats.currentStreak} días al 100%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WarningOrange)
                        }
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, KineticLime.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = KineticLime, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text("Mejor racha", fontSize = 9.sp, color = Color.White.copy(alpha = 0.6f))
                            Text("${streakStats.bestStreak} días", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = KineticLime)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Checklist de Hoy",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (activeGoals.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, CyberCardBorder)
                ) {
                    Text(
                        text = "No tienes metas activas. Toca 'Gestionar' para agregar tus objetivos diarios.",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.5f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    activeGoals.forEach { goal ->
                        val isChecked = todayCompletedIds.contains(goal.id)

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onToggleGoal(goal.id, !isChecked, goal.targetMinutes)
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isChecked) KineticLime.copy(alpha = 0.12f) else CyberObsidian,
                            border = BorderStroke(1.dp, if (isChecked) KineticLime.copy(alpha = 0.6f) else CyberCardBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = if (isChecked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = if (isChecked) KineticLime else CyberVioletLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = goal.name,
                                            fontSize = 13.sp,
                                            fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isChecked) KineticLimeLight else Color.White,
                                            textDecoration = if (isChecked) TextDecoration.LineThrough else TextDecoration.None
                                        )
                                        if (goal.targetMinutes > 0) {
                                            Text(
                                                text = "Meta: ${goal.targetMinutes} min • +50 XP",
                                                fontSize = 10.sp,
                                                color = Color.White.copy(alpha = 0.5f)
                                            )
                                        }
                                    }
                                }

                                if (isChecked) {
                                    Text(
                                        text = "¡Listo! ⚡",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = KineticLime
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 6. Mini Dashboard / Resumen General
// -------------------------------------------------------------
@Composable
fun CyberSummaryDashboard(
    totalMinutes: Int,
    monthCount: Int,
    hasActiveFilters: Boolean,
    onClearFilters: () -> Unit,
    onOpenDateFilter: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyberCardBorder),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Resumen de Actividades",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (hasActiveFilters) {
                        Text(
                            text = "Limpiar",
                            color = WarningOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { onClearFilters() }
                                .padding(4.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    IconButton(onClick = onOpenDateFilter, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.FilterAlt,
                            contentDescription = "Filtro de fechas",
                            tint = if (hasActiveFilters) KineticLime else CyberVioletLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Total minutos
                Surface(
                    modifier = Modifier.weight(1f),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.35f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Tiempo Total", fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${totalMinutes}m",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = CyberCyan
                        )
                    }
                }

                // Cantidad de actividades mes actual
                Surface(
                    modifier = Modifier.weight(1f),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, KineticLime.copy(alpha = 0.35f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Este Mes", fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$monthCount",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = KineticLime
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 7. Filtro por Chips de Actividad
// -------------------------------------------------------------
@Composable
fun CyberActivityFilterBar(
    distinctNames: List<String>,
    selectedFilter: String?,
    onSelectFilter: (String?) -> Unit
) {
    if (distinctNames.isNotEmpty()) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                val isAllSelected = selectedFilter == null
                Surface(
                    onClick = { onSelectFilter(null) },
                    shape = RoundedCornerShape(8.dp),
                    color = if (isAllSelected) KineticLime.copy(alpha = 0.2f) else CyberSurfaceCard,
                    border = BorderStroke(1.dp, if (isAllSelected) KineticLime else CyberCardBorder)
                ) {
                    Text(
                        text = "Todas",
                        fontSize = 11.sp,
                        fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isAllSelected) KineticLime else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            items(distinctNames) { name ->
                val isSelected = selectedFilter.equals(name, ignoreCase = true)
                Surface(
                    onClick = { onSelectFilter(name) },
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) CyberViolet.copy(alpha = 0.25f) else CyberSurfaceCard,
                    border = BorderStroke(1.dp, if (isSelected) CyberViolet else CyberCardBorder)
                ) {
                    Text(
                        text = name,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CyberVioletLight else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 8. Tarjeta de Elemento de Actividad en Lista
// -------------------------------------------------------------
@Composable
fun CyberActivityLogItemCard(
    activity: ActivityLogEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CyberCardBorder),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, CyberCardBorder),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = when {
                                activity.activityName.contains("Gym", ignoreCase = true) || activity.activityName.contains("Gimnasio", ignoreCase = true) -> Icons.Default.FitnessCenter
                                activity.activityName.contains("Correr", ignoreCase = true) || activity.activityName.contains("Caminar", ignoreCase = true) -> Icons.Default.DirectionsRun
                                activity.activityName.contains("Leer", ignoreCase = true) || activity.activityName.contains("Lectura", ignoreCase = true) -> Icons.Default.MenuBook
                                else -> Icons.Default.SelfImprovement
                            },
                            contentDescription = null,
                            tint = KineticLime,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = activity.activityName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${dateFormat.format(Date(activity.date))} • ${activity.durationMinutes} min",
                        fontSize = 11.sp,
                        color = CyberVioletLight,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (activity.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = activity.notes,
                            fontSize = 10.5.sp,
                            color = Color.White.copy(alpha = 0.5f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Editar",
                        tint = CyberVioletLight,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Eliminar",
                        tint = ExpenseRed,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 9. Estado Vacío de Actividades
// -------------------------------------------------------------
@Composable
fun CyberEmptyActivitiesCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CyberCardBorder),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.DirectionsRun,
                contentDescription = null,
                tint = KineticLime.copy(alpha = 0.6f),
                modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Sin actividades aún",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Pulsa '+' o usa el Cronómetro en Vivo para registrar tu primera actividad Kinetic.",
                fontSize = 11.5.sp,
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )
        }
    }
}

// -------------------------------------------------------------
// 10. BottomSheet Registrar / Editar Actividad
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CyberAddOrEditActivityBottomSheet(
    activityToEdit: ActivityLogEntity?,
    existingNames: List<String>,
    onDismiss: () -> Unit,
    onSave: (name: String, duration: Int, date: Long, notes: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    var nameInput by remember { mutableStateOf(activityToEdit?.activityName ?: "") }
    var durationInput by remember { mutableStateOf(activityToEdit?.durationMinutes?.toString() ?: "30") }
    var notesInput by remember { mutableStateOf(activityToEdit?.notes ?: "") }
    var selectedDateMillis by remember { mutableLongStateOf(activityToEdit?.date ?: System.currentTimeMillis()) }
    var errorText by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CyberSurfaceCard,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Text(
                text = if (activityToEdit == null) "Registrar Actividad Kinetic" else "Editar Actividad",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Nombre
            OutlinedTextField(
                value = nameInput,
                onValueChange = { nameInput = it; errorText = null },
                label = { Text("Nombre de la actividad") },
                placeholder = { Text("Ej. Gimnasio, Correr, Lectura") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = KineticLime,
                    unfocusedBorderColor = CyberCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Duración en minutos
            OutlinedTextField(
                value = durationInput,
                onValueChange = { durationInput = it; errorText = null },
                label = { Text("Duración (minutos)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = KineticLime,
                    unfocusedBorderColor = CyberCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Selector de Fecha
            Surface(
                onClick = {
                    val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                    DatePickerDialog(
                        context,
                        { _, year, month, dayOfMonth ->
                            cal.set(year, month, dayOfMonth)
                            selectedDateMillis = cal.timeInMillis
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                },
                shape = RoundedCornerShape(12.dp),
                color = CyberObsidian,
                border = BorderStroke(1.dp, CyberCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Fecha: ${dateFormat.format(Date(selectedDateMillis))}",
                        fontSize = 13.sp,
                        color = Color.White
                    )
                    Icon(Icons.Default.CalendarToday, contentDescription = null, tint = KineticLime, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Notas
            OutlinedTextField(
                value = notesInput,
                onValueChange = { notesInput = it },
                label = { Text("Notas / Comentarios (opcional)") },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = KineticLime,
                    unfocusedBorderColor = CyberCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            errorText?.let {
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = it, color = ExpenseRed, fontSize = 11.5.sp)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = {
                    val name = nameInput.trim()
                    val duration = durationInput.toIntOrNull() ?: 0
                    if (name.isBlank()) {
                        errorText = "Ingresa el nombre de la actividad."
                        return@Button
                    }
                    if (duration <= 0) {
                        errorText = "La duración debe ser mayor a 0 minutos."
                        return@Button
                    }
                    onSave(name, duration, selectedDateMillis, notesInput)
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = KineticLime)
            ) {
                Text(
                    text = if (activityToEdit == null) "Agregar Actividad (+XP)" else "Guardar Cambios",
                    fontWeight = FontWeight.Bold,
                    color = CyberObsidian,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// -------------------------------------------------------------
// 11. BottomSheet Gestionar Metas Diarias
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CyberManageGoalsBottomSheet(
    allGoals: List<ActivityGoalEntity>,
    onDismiss: () -> Unit,
    onAddGoal: (name: String, targetMinutes: Int) -> Unit,
    onUpdateGoal: (id: Long, name: String, targetMinutes: Int, isActive: Boolean) -> Unit,
    onToggleActive: (goal: ActivityGoalEntity) -> Unit,
    onDeleteGoal: (goal: ActivityGoalEntity) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showNewGoalForm by remember { mutableStateOf(false) }
    var newGoalName by remember { mutableStateOf("") }
    var newGoalMinutes by remember { mutableStateOf("30") }
    var goalError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CyberSurfaceCard,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Gestionar Metas Diarias",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )

                TextButton(onClick = { showNewGoalForm = !showNewGoalForm }) {
                    Icon(
                        imageVector = if (showNewGoalForm) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = null,
                        tint = KineticLime,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (showNewGoalForm) "Cancelar" else "Nueva",
                        color = KineticLime,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            AnimatedVisibility(visible = showNewGoalForm) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .background(CyberObsidian, RoundedCornerShape(12.dp))
                        .border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text("Crear Nueva Meta Diaria", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newGoalName,
                        onValueChange = { newGoalName = it; goalError = null },
                        label = { Text("Nombre de la meta") },
                        placeholder = { Text("Ej. Gimnasio, 30m Lectura") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = KineticLime,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = newGoalMinutes,
                        onValueChange = { newGoalMinutes = it; goalError = null },
                        label = { Text("Objetivo minutos (opcional)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = KineticLime,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    goalError?.let {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = it, color = ExpenseRed, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val name = newGoalName.trim()
                            val minutes = newGoalMinutes.toIntOrNull() ?: 0
                            if (name.isBlank()) {
                                goalError = "Ingresa el nombre de la meta."
                                return@Button
                            }
                            onAddGoal(name, minutes)
                            newGoalName = ""
                            newGoalMinutes = "30"
                            showNewGoalForm = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KineticLime),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Crear Meta (+50 XP)", fontWeight = FontWeight.Bold, color = CyberObsidian)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (allGoals.isEmpty()) {
                Text(
                    text = "No tienes metas creadas. Agrega una arriba.",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    allGoals.forEach { goal ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = CyberObsidian,
                            border = BorderStroke(1.dp, CyberCardBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = goal.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (goal.isActive) Color.White else Color.White.copy(alpha = 0.4f)
                                    )
                                    Text(
                                        text = if (goal.targetMinutes > 0) "${goal.targetMinutes} min diarios" else "Checklist simple",
                                        fontSize = 11.sp,
                                        color = CyberVioletLight
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = goal.isActive,
                                        onCheckedChange = { onToggleActive(goal) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = CyberObsidian,
                                            checkedTrackColor = KineticLime,
                                            uncheckedThumbColor = Color.Gray,
                                            uncheckedTrackColor = CyberCardBorder
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(onClick = { onDeleteGoal(goal) }, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = ExpenseRed, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 12. Diálogo Selector de Rango de Fechas
// -------------------------------------------------------------
@Composable
fun CyberDateRangePickerDialog(
    initialStart: Long?,
    initialEnd: Long?,
    onDismiss: () -> Unit,
    onApply: (start: Long?, end: Long?) -> Unit,
    onSelectCurrentMonth: () -> Unit
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    var startMillis by remember { mutableStateOf(initialStart) }
    var endMillis by remember { mutableStateOf(initialEnd) }

    AlertDialog(
        containerColor = CyberSurfaceCard,
        onDismissRequest = onDismiss,
        title = { Text("Filtrar por Rango de Fechas", fontWeight = FontWeight.Bold, color = Color.White) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Botón Mes Actual
                Surface(
                    onClick = onSelectCurrentMonth,
                    shape = RoundedCornerShape(8.dp),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, KineticLime.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Seleccionar Mes Actual",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = KineticLime,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                // Desde
                Surface(
                    onClick = {
                        val cal = Calendar.getInstance().apply {
                            timeInMillis = startMillis ?: System.currentTimeMillis()
                        }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                cal.set(y, m, d, 0, 0, 0)
                                startMillis = cal.timeInMillis
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, CyberCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (startMillis != null) "Desde: ${dateFormat.format(Date(startMillis!!))}" else "Desde: Cualquier fecha",
                            fontSize = 12.sp,
                            color = Color.White
                        )
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CyberVioletLight, modifier = Modifier.size(16.dp))
                    }
                }

                // Hasta
                Surface(
                    onClick = {
                        val cal = Calendar.getInstance().apply {
                            timeInMillis = endMillis ?: System.currentTimeMillis()
                        }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                cal.set(y, m, d, 23, 59, 59)
                                endMillis = cal.timeInMillis
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    color = CyberObsidian,
                    border = BorderStroke(1.dp, CyberCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (endMillis != null) "Hasta: ${dateFormat.format(Date(endMillis!!))}" else "Hasta: Cualquier fecha",
                            fontSize = 12.sp,
                            color = Color.White
                        )
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CyberVioletLight, modifier = Modifier.size(16.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onApply(startMillis, endMillis) },
                colors = ButtonDefaults.buttonColors(containerColor = KineticLime)
            ) {
                Text("Aplicar", color = CyberObsidian, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = CyberVioletLight)
            }
        }
    )
}
