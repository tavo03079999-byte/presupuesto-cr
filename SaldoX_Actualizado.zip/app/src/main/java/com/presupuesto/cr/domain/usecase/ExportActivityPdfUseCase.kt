package com.presupuesto.cr.domain.usecase

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.presupuesto.cr.data.local.entity.ActivityLogEntity
import com.presupuesto.cr.data.repository.FinanceRepository
import com.presupuesto.cr.ui.auth.UserAuthManager
import com.presupuesto.cr.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExportActivityPdfUseCase(
    private val context: Context,
    private val repository: FinanceRepository
) {

    suspend fun exportPdf(
        activities: List<ActivityLogEntity>,
        dateRangeLabel: String? = null,
        activityFilterLabel: String? = null
    ): File = withContext(Dispatchers.IO) {
        val authManager = UserAuthManager(context)
        val userName = authManager.getRegisteredName() ?: "Usuario SaldoX"
        val generationDateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        val totalActivities = activities.size
        val totalMinutes = activities.sumOf { it.durationMinutes }
        val avgMinutes = if (totalActivities > 0) totalMinutes.toDouble() / totalActivities else 0.0

        // Pinceles de dibujo
        val titlePaint = Paint().apply {
            color = Color.parseColor("#0D162C")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subtitlePaint = Paint().apply {
            color = Color.parseColor("#555555")
            textSize = 9.5f
            isAntiAlias = true
        }

        val filterPaint = Paint().apply {
            color = Color.parseColor("#1976D2")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val tableHeaderBoxPaint = Paint().apply {
            color = Color.parseColor("#E3F2FD")
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.parseColor("#0D162C")
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.parseColor("#212121")
            textSize = 9f
            isAntiAlias = true
        }

        val linePaint = Paint().apply {
            color = Color.parseColor("#E0E0E0")
            strokeWidth = 0.8f
        }

        val summaryBoxPaint = Paint().apply {
            color = Color.parseColor("#F5F9FF")
        }

        val summaryBorderPaint = Paint().apply {
            color = Color.parseColor("#BBDEFB")
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }

        val summaryTitlePaint = Paint().apply {
            color = Color.parseColor("#1565C0")
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val footerPaint = Paint().apply {
            color = Color.GRAY
            textSize = 8f
            isAntiAlias = true
        }

        val pdfDocument = PdfDocument()
        var pageNumber = 1
        var currentPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
        var canvas: Canvas = currentPage.canvas
        var y = 40f

        fun drawHeaderAndTitle() {
            canvas.drawText("Registro de Actividades Personales", 40f, y, titlePaint)
            y += 18f
            canvas.drawText("Usuario: $userName  |  Fecha de generación: $generationDateStr", 40f, y, subtitlePaint)
            y += 14f

            val filterParts = mutableListOf<String>()
            if (!dateRangeLabel.isNullOrBlank()) {
                filterParts.add("Periodo: $dateRangeLabel")
            }
            if (!activityFilterLabel.isNullOrBlank()) {
                filterParts.add("Actividad: $activityFilterLabel")
            }
            if (filterParts.isNotEmpty()) {
                canvas.drawText("Filtros aplicados: ${filterParts.joinToString("  •  ")}", 40f, y, filterPaint)
                y += 14f
            }

            canvas.drawLine(40f, y, 555f, y, linePaint)
            y += 16f
        }

        fun drawTableHeader() {
            canvas.drawRect(40f, y - 11f, 555f, y + 8f, tableHeaderBoxPaint)
            canvas.drawText("Fecha", 46f, y, tableHeaderPaint)
            canvas.drawText("Actividad", 130f, y, tableHeaderPaint)
            canvas.drawText("Duración", 280f, y, tableHeaderPaint)
            canvas.drawText("Notas / Comentarios", 360f, y, tableHeaderPaint)
            y += 14f
            canvas.drawLine(40f, y - 6f, 555f, y - 6f, linePaint)
        }

        fun drawFooter() {
            canvas.drawText(
                "Generado por SaldoX — Registro de Actividades  |  Página $pageNumber",
                40f,
                825f,
                footerPaint
            )
        }

        drawHeaderAndTitle()
        drawTableHeader()

        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

        for (item in activities) {
            if (y > 770f) {
                drawFooter()
                pdfDocument.finishPage(currentPage)
                pageNumber++
                currentPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
                canvas = currentPage.canvas
                y = 40f
                drawTableHeader()
            }

            val fechaStr = dateFormat.format(Date(item.date))
            val duracionStr = "${item.durationMinutes} min"
            val activityStr = if (item.activityName.length > 24) item.activityName.take(22) + "..." else item.activityName
            val notesStr = if (item.notes.length > 34) item.notes.take(32) + "..." else item.notes.ifBlank { "-" }

            canvas.drawText(fechaStr, 46f, y, textPaint)
            canvas.drawText(activityStr, 130f, y, textPaint)
            canvas.drawText(duracionStr, 280f, y, textPaint)
            canvas.drawText(notesStr, 360f, y, textPaint)

            y += 8f
            canvas.drawLine(40f, y, 555f, y, linePaint)
            y += 14f
        }

        // Resumen al final
        if (y > 700f) {
            drawFooter()
            pdfDocument.finishPage(currentPage)
            pageNumber++
            currentPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
            canvas = currentPage.canvas
            y = 40f
        } else {
            y += 10f
        }

        // Caja de resumen estadístico
        canvas.drawRoundRect(40f, y, 555f, y + 80f, 8f, 8f, summaryBoxPaint)
        canvas.drawRoundRect(40f, y, 555f, y + 80f, 8f, 8f, summaryBorderPaint)

        val boxY = y + 18f
        canvas.drawText("RESUMEN ESTADÍSTICO DE ACTIVIDADES", 55f, boxY, summaryTitlePaint)

        val hours = totalMinutes / 60
        val remainingMin = totalMinutes % 60
        val totalTimeFormatted = if (hours > 0) "$totalMinutes min (${hours}h ${remainingMin}m)" else "$totalMinutes min"

        canvas.drawText("• Total de actividades registradas: $totalActivities", 55f, boxY + 18f, textPaint)
        canvas.drawText("• Total de minutos acumulados: $totalTimeFormatted", 55f, boxY + 34f, textPaint)
        canvas.drawText("• Promedio de minutos por actividad: ${String.format(Locale.US, "%.1f", avgMinutes)} min", 55f, boxY + 50f, textPaint)

        drawFooter()
        pdfDocument.finishPage(currentPage)

        val reportsDir = File(context.getExternalFilesDir(null), "reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val pdfFile = File(reportsDir, "Registro_Actividades_${timeStamp}.pdf")

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        pdfFile
    }
}
