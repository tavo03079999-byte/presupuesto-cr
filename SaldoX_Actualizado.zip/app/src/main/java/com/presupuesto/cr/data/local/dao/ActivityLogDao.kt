package com.presupuesto.cr.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.presupuesto.cr.data.local.entity.ActivityLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(activityLog: ActivityLogEntity): Long

    @Update
    suspend fun update(activityLog: ActivityLogEntity)

    @Delete
    suspend fun delete(activityLog: ActivityLogEntity)

    @Query("DELETE FROM activity_logs WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM activity_logs ORDER BY date DESC, id DESC")
    fun getAll(): Flow<List<ActivityLogEntity>>

    @Query("SELECT * FROM activity_logs ORDER BY date DESC, id DESC")
    suspend fun getAllSync(): List<ActivityLogEntity>

    @Query("SELECT * FROM activity_logs WHERE id = :id")
    suspend fun getById(id: Long): ActivityLogEntity?

    @Query("SELECT * FROM activity_logs WHERE date BETWEEN :startTime AND :endTime ORDER BY date DESC, id DESC")
    fun getBetweenDates(startTime: Long, endTime: Long): Flow<List<ActivityLogEntity>>

    @Query("SELECT * FROM activity_logs WHERE date BETWEEN :startTime AND :endTime ORDER BY date DESC, id DESC")
    suspend fun getBetweenDatesSync(startTime: Long, endTime: Long): List<ActivityLogEntity>

    @Query("SELECT DISTINCT activityName FROM activity_logs ORDER BY activityName ASC")
    fun getDistinctActivityNames(): Flow<List<String>>

    @Query("DELETE FROM activity_logs")
    suspend fun deleteAll()
}
