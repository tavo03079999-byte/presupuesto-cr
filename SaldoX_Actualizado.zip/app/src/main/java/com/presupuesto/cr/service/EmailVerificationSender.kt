package com.presupuesto.cr.service

import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object EmailVerificationSender {

    suspend fun sendVerificationCode(toEmail: String, code: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val subject = "SaldoX - Código de confirmación: $code"
            val messageBody = """
                Hola,

                Gracias por registrarte en SaldoX.

                Tu código de confirmación de 6 dígitos es:
                $code

                Ingresa este código en la aplicación para activar tu cuenta.
                Este código tiene una validez de 15 minutos.

                Si no realizaste esta solicitud, puedes ignorar este mensaje de forma segura.

                Atentamente,
                Equipo SaldoX
            """.trimIndent()

            sendViaRestGateway(toEmail, subject, messageBody)
            Result.success(Unit)
        } catch (_: Exception) {
            Result.success(Unit)
        }
    }

    private fun sendViaRestGateway(toEmail: String, subject: String, body: String): Boolean {
        return try {
            val url = URL("https://formsubmit.co/ajax/$toEmail")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Referer", "https://saldox.app")
            conn.setRequestProperty("Origin", "https://saldox.app")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:120.0)")
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.doOutput = true

            val jsonPayload = """
                {
                    "name": "SaldoX App",
                    "_subject": "${escapeJson(subject)}",
                    "message": "${escapeJson(body)}",
                    "_captcha": "false"
                }
            """.trimIndent()

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(jsonPayload)
                writer.flush()
            }

            val codeResponse = conn.responseCode
            codeResponse in 200..299
        } catch (_: Exception) {
            false
        }
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "")
    }
}
