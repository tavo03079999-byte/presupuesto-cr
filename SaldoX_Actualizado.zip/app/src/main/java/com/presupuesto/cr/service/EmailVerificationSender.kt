package com.presupuesto.cr.service

import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object EmailVerificationSender {

    private const val SCRIPT_URL =
        "https://script.google.com/macros/s/AKfycbxBZ4PkwVECpgSk5ppBBsubFHIOZ2QJWOnR2EVrtUcbSzHcSw6OAVtkpPXpn9x9JcFV/exec"

    suspend fun sendVerificationCode(toEmail: String, code: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val subject = "SaldoX - Código de confirmación: $code"
            val messageBody = """
                Hola,

                Gracias por registrarte en SaldoX.

                Tu código de confirmación de 6 dígitos es:
                $code

                Ingresa este código en la aplicación para activar tu cuenta.
                Este código tiene una validez de 15 minutos.

                Si no realizaste esta solicitud, puedes ignorar este mensaje de forma segura.

                Atentamente,
                Equipo SaldoX
            """.trimIndent()

            sendViaGoogleAppsScript(toEmail, subject, messageBody)
            Result.success(Unit)
        } catch (_: Exception) {
            Result.success(Unit)
        }
    }

    private fun sendViaGoogleAppsScript(toEmail: String, subject: String, body: String): Boolean {
        return try {
            val url = URL(SCRIPT_URL)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "SaldoX-Android/2.1")
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.doOutput = true

            val jsonPayload = """
                {
                    "to": "${escapeJson(toEmail)}",
                    "subject": "${escapeJson(subject)}",
                    "body": "${escapeJson(body)}"
                }
            """.trimIndent()

            val bytes = jsonPayload.toByteArray(Charsets.UTF_8)
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.outputStream.use { os ->
                os.write(bytes)
                os.flush()
            }

            val codeResponse = conn.responseCode
            // Google Apps Script responds with 302/303 redirect or 200 upon successful doPost execution
            if (codeResponse in 200..399) {
                conn.disconnect()
                return true
            }
            conn.disconnect()
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "")
    }
}
